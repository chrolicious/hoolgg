--
-- PostgreSQL database dump
--

\restrict 9ua7a8OXfRT2PvIBtMtE6gVRIUB3eExNjB9GyiWDfz1ZWfe5Bd3Rxwd0ikSifIz

-- Dumped from database version 17.8
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO hool;

--
-- Name: alembic_version_progress; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.alembic_version_progress (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version_progress OWNER TO hool;

--
-- Name: alembic_version_recruitment; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.alembic_version_recruitment (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version_recruitment OWNER TO hool;

--
-- Name: bis_items; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.bis_items (
    id integer NOT NULL,
    character_id integer NOT NULL,
    slot character varying(50) NOT NULL,
    item_name character varying(255) NOT NULL,
    item_id integer,
    target_ilvl integer,
    obtained boolean DEFAULT false,
    synced boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.bis_items OWNER TO hool;

--
-- Name: bis_items_id_seq; Type: SEQUENCE; Schema: public; Owner: hool
--

CREATE SEQUENCE public.bis_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bis_items_id_seq OWNER TO hool;

--
-- Name: bis_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hool
--

ALTER SEQUENCE public.bis_items_id_seq OWNED BY public.bis_items.id;


--
-- Name: character_professions; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.character_professions (
    id integer NOT NULL,
    character_id integer NOT NULL,
    profession_name character varying(100) NOT NULL,
    slot_index integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.character_professions OWNER TO hool;

--
-- Name: character_professions_id_seq; Type: SEQUENCE; Schema: public; Owner: hool
--

CREATE SEQUENCE public.character_professions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.character_professions_id_seq OWNER TO hool;

--
-- Name: character_professions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hool
--

ALTER SEQUENCE public.character_professions_id_seq OWNED BY public.character_professions.id;


--
-- Name: character_progress; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.character_progress (
    id integer NOT NULL,
    character_name character varying(255) NOT NULL,
    realm character varying(255) NOT NULL,
    guild_id integer,
    class_name character varying(50),
    spec character varying(50),
    role character varying(20),
    current_ilvl double precision,
    gear_details json,
    last_updated timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    user_bnet_id integer,
    level integer,
    avatar_url character varying(512),
    display_order integer DEFAULT 0,
    last_gear_sync timestamp with time zone,
    parsed_gear json,
    character_stats json,
    mythic_plus_score double precision,
    raid_progress json,
    last_raiderio_sync timestamp with time zone
);


ALTER TABLE public.character_progress OWNER TO hool;

--
-- Name: character_progress_id_seq; Type: SEQUENCE; Schema: public; Owner: hool
--

CREATE SEQUENCE public.character_progress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.character_progress_id_seq OWNER TO hool;

--
-- Name: character_progress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hool
--

ALTER SEQUENCE public.character_progress_id_seq OWNED BY public.character_progress.id;


--
-- Name: crest_entries; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.crest_entries (
    id integer NOT NULL,
    character_id integer NOT NULL,
    crest_type character varying(50) NOT NULL,
    week_number integer NOT NULL,
    collected integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.crest_entries OWNER TO hool;

--
-- Name: crest_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: hool
--

CREATE SEQUENCE public.crest_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.crest_entries_id_seq OWNER TO hool;

--
-- Name: crest_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hool
--

ALTER SEQUENCE public.crest_entries_id_seq OWNED BY public.crest_entries.id;


--
-- Name: great_vault_entries; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.great_vault_entries (
    id integer NOT NULL,
    character_id integer NOT NULL,
    week_number integer NOT NULL,
    raid_lfr integer DEFAULT 0,
    raid_normal integer DEFAULT 0,
    raid_heroic integer DEFAULT 0,
    raid_mythic integer DEFAULT 0,
    m_plus_runs json,
    highest_delve integer DEFAULT 0,
    world_vault json,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.great_vault_entries OWNER TO hool;

--
-- Name: great_vault_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: hool
--

CREATE SEQUENCE public.great_vault_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.great_vault_entries_id_seq OWNER TO hool;

--
-- Name: great_vault_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hool
--

ALTER SEQUENCE public.great_vault_entries_id_seq OWNED BY public.great_vault_entries.id;


--
-- Name: guild_members; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.guild_members (
    character_name character varying(255) NOT NULL,
    guild_id integer,
    bnet_id integer NOT NULL,
    rank_id integer NOT NULL,
    rank_name character varying(255) NOT NULL,
    last_sync timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.guild_members OWNER TO hool;

--
-- Name: guild_messages; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.guild_messages (
    id integer NOT NULL,
    guild_id integer NOT NULL,
    gm_message text,
    created_by integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.guild_messages OWNER TO hool;

--
-- Name: guild_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: hool
--

CREATE SEQUENCE public.guild_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.guild_messages_id_seq OWNER TO hool;

--
-- Name: guild_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hool
--

ALTER SEQUENCE public.guild_messages_id_seq OWNED BY public.guild_messages.id;


--
-- Name: guild_permissions; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.guild_permissions (
    id integer NOT NULL,
    guild_id integer NOT NULL,
    tool_name character varying(100) NOT NULL,
    min_rank_id integer NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.guild_permissions OWNER TO hool;

--
-- Name: guild_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: hool
--

CREATE SEQUENCE public.guild_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.guild_permissions_id_seq OWNER TO hool;

--
-- Name: guild_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hool
--

ALTER SEQUENCE public.guild_permissions_id_seq OWNED BY public.guild_permissions.id;


--
-- Name: guilds; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.guilds (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    realm character varying(255) NOT NULL,
    gm_bnet_id integer NOT NULL,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    crest_data jsonb,
    crest_updated_at timestamp with time zone
);


ALTER TABLE public.guilds OWNER TO hool;

--
-- Name: guilds_id_seq; Type: SEQUENCE; Schema: public; Owner: hool
--

CREATE SEQUENCE public.guilds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.guilds_id_seq OWNER TO hool;

--
-- Name: guilds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hool
--

ALTER SEQUENCE public.guilds_id_seq OWNED BY public.guilds.id;


--
-- Name: profession_progress; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.profession_progress (
    id integer NOT NULL,
    character_id integer NOT NULL,
    profession_name character varying(100) NOT NULL,
    week_number integer NOT NULL,
    weekly_quest boolean DEFAULT false,
    patron_orders boolean DEFAULT false,
    treatise boolean DEFAULT false,
    knowledge_points integer DEFAULT 0,
    concentration integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.profession_progress OWNER TO hool;

--
-- Name: profession_progress_id_seq; Type: SEQUENCE; Schema: public; Owner: hool
--

CREATE SEQUENCE public.profession_progress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.profession_progress_id_seq OWNER TO hool;

--
-- Name: profession_progress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hool
--

ALTER SEQUENCE public.profession_progress_id_seq OWNED BY public.profession_progress.id;


--
-- Name: recruitment_candidates; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.recruitment_candidates (
    id integer NOT NULL,
    guild_id integer NOT NULL,
    candidate_name character varying(255) NOT NULL,
    realm character varying(255),
    region character varying(10) DEFAULT 'us'::character varying,
    character_class character varying(50),
    role character varying(50),
    spec character varying(50),
    ilvl integer,
    raid_progress character varying(255),
    mythic_plus_rating integer,
    raider_io_score integer,
    source character varying(50) DEFAULT 'manual'::character varying NOT NULL,
    external_url character varying(512),
    rating integer,
    notes text,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    category_id integer,
    contacted integer DEFAULT 0 NOT NULL,
    contacted_date timestamp with time zone,
    avg_parse_percentile double precision,
    best_parse_percentile double precision,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.recruitment_candidates OWNER TO hool;

--
-- Name: recruitment_candidates_id_seq; Type: SEQUENCE; Schema: public; Owner: hool
--

CREATE SEQUENCE public.recruitment_candidates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recruitment_candidates_id_seq OWNER TO hool;

--
-- Name: recruitment_candidates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hool
--

ALTER SEQUENCE public.recruitment_candidates_id_seq OWNED BY public.recruitment_candidates.id;


--
-- Name: recruitment_categories; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.recruitment_categories (
    id integer NOT NULL,
    guild_id integer NOT NULL,
    category_name character varying(100) NOT NULL,
    custom integer DEFAULT 0 NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.recruitment_categories OWNER TO hool;

--
-- Name: recruitment_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: hool
--

CREATE SEQUENCE public.recruitment_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recruitment_categories_id_seq OWNER TO hool;

--
-- Name: recruitment_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hool
--

ALTER SEQUENCE public.recruitment_categories_id_seq OWNED BY public.recruitment_categories.id;


--
-- Name: recruitment_history; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.recruitment_history (
    id integer NOT NULL,
    guild_id integer NOT NULL,
    candidate_id integer NOT NULL,
    contacted_date timestamp with time zone NOT NULL,
    method character varying(50) NOT NULL,
    message text,
    response_received integer DEFAULT 0 NOT NULL,
    logged_by_bnet_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.recruitment_history OWNER TO hool;

--
-- Name: recruitment_history_id_seq; Type: SEQUENCE; Schema: public; Owner: hool
--

CREATE SEQUENCE public.recruitment_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recruitment_history_id_seq OWNER TO hool;

--
-- Name: recruitment_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hool
--

ALTER SEQUENCE public.recruitment_history_id_seq OWNED BY public.recruitment_history.id;


--
-- Name: scan_jobs; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.scan_jobs (
    id integer NOT NULL,
    uuid character varying(36) NOT NULL,
    guild_id integer NOT NULL,
    started_by_bnet_id integer NOT NULL,
    config json NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    progress double precision DEFAULT '0'::double precision NOT NULL,
    current_step character varying(255),
    result_count integer DEFAULT 0 NOT NULL,
    error_message text,
    share_token character varying(64),
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.scan_jobs OWNER TO hool;

--
-- Name: scan_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: hool
--

CREATE SEQUENCE public.scan_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scan_jobs_id_seq OWNER TO hool;

--
-- Name: scan_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hool
--

ALTER SEQUENCE public.scan_jobs_id_seq OWNED BY public.scan_jobs.id;


--
-- Name: scan_results; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.scan_results (
    id integer NOT NULL,
    scan_job_id integer NOT NULL,
    character_name character varying(255) NOT NULL,
    realm character varying(255) NOT NULL,
    region character varying(10) DEFAULT 'us'::character varying NOT NULL,
    character_class character varying(50),
    spec character varying(50),
    item_level integer,
    mythic_plus_score integer,
    raid_progress character varying(255),
    recruitment_score double precision,
    recruitment_signals json,
    profile_url character varying(512),
    guild_name character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.scan_results OWNER TO hool;

--
-- Name: scan_results_id_seq; Type: SEQUENCE; Schema: public; Owner: hool
--

CREATE SEQUENCE public.scan_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scan_results_id_seq OWNER TO hool;

--
-- Name: scan_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hool
--

ALTER SEQUENCE public.scan_results_id_seq OWNED BY public.scan_results.id;


--
-- Name: scheduled_scans; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.scheduled_scans (
    id integer NOT NULL,
    guild_id integer NOT NULL,
    name character varying(255) NOT NULL,
    schedule_expr character varying(100) NOT NULL,
    config json NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    next_run_at timestamp with time zone,
    last_run_at timestamp with time zone,
    last_scan_job_id integer,
    discord_webhook_url character varying(512),
    created_by_bnet_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.scheduled_scans OWNER TO hool;

--
-- Name: scheduled_scans_id_seq; Type: SEQUENCE; Schema: public; Owner: hool
--

CREATE SEQUENCE public.scheduled_scans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scheduled_scans_id_seq OWNER TO hool;

--
-- Name: scheduled_scans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hool
--

ALTER SEQUENCE public.scheduled_scans_id_seq OWNED BY public.scheduled_scans.id;


--
-- Name: season_config; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.season_config (
    id integer NOT NULL,
    expansion_id integer NOT NULL,
    region character varying(10) DEFAULT 'us'::character varying,
    week_number integer NOT NULL,
    start_date timestamp with time zone NOT NULL,
    crest_cap_per_week integer DEFAULT 90,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.season_config OWNER TO hool;

--
-- Name: season_config_id_seq; Type: SEQUENCE; Schema: public; Owner: hool
--

CREATE SEQUENCE public.season_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.season_config_id_seq OWNER TO hool;

--
-- Name: season_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hool
--

ALTER SEQUENCE public.season_config_id_seq OWNED BY public.season_config.id;


--
-- Name: talent_builds; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.talent_builds (
    id integer NOT NULL,
    character_id integer NOT NULL,
    category character varying(50) NOT NULL,
    name character varying(255) NOT NULL,
    talent_string text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.talent_builds OWNER TO hool;

--
-- Name: talent_builds_id_seq; Type: SEQUENCE; Schema: public; Owner: hool
--

CREATE SEQUENCE public.talent_builds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.talent_builds_id_seq OWNER TO hool;

--
-- Name: talent_builds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hool
--

ALTER SEQUENCE public.talent_builds_id_seq OWNED BY public.talent_builds.id;


--
-- Name: user_tracked_characters; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.user_tracked_characters (
    id integer NOT NULL,
    guild_id integer NOT NULL,
    bnet_id integer NOT NULL,
    character_name character varying(50) NOT NULL,
    realm character varying(100) NOT NULL,
    is_main boolean DEFAULT false NOT NULL,
    tracked boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_tracked_characters OWNER TO hool;

--
-- Name: user_tracked_characters_id_seq; Type: SEQUENCE; Schema: public; Owner: hool
--

CREATE SEQUENCE public.user_tracked_characters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_tracked_characters_id_seq OWNER TO hool;

--
-- Name: user_tracked_characters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hool
--

ALTER SEQUENCE public.user_tracked_characters_id_seq OWNED BY public.user_tracked_characters.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.users (
    bnet_id integer NOT NULL,
    bnet_username character varying(255) NOT NULL,
    last_login timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO hool;

--
-- Name: users_bnet_id_seq; Type: SEQUENCE; Schema: public; Owner: hool
--

CREATE SEQUENCE public.users_bnet_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_bnet_id_seq OWNER TO hool;

--
-- Name: users_bnet_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hool
--

ALTER SEQUENCE public.users_bnet_id_seq OWNED BY public.users.bnet_id;


--
-- Name: weekly_targets; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.weekly_targets (
    id integer NOT NULL,
    expansion_id character varying(50) NOT NULL,
    week integer NOT NULL,
    ilvl_target double precision NOT NULL,
    description character varying(500),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.weekly_targets OWNER TO hool;

--
-- Name: weekly_targets_id_seq; Type: SEQUENCE; Schema: public; Owner: hool
--

CREATE SEQUENCE public.weekly_targets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.weekly_targets_id_seq OWNER TO hool;

--
-- Name: weekly_targets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hool
--

ALTER SEQUENCE public.weekly_targets_id_seq OWNED BY public.weekly_targets.id;


--
-- Name: weekly_task_completions; Type: TABLE; Schema: public; Owner: hool
--

CREATE TABLE public.weekly_task_completions (
    id integer NOT NULL,
    character_id integer NOT NULL,
    week_number integer NOT NULL,
    task_type character varying(20) NOT NULL,
    task_id character varying(100) NOT NULL,
    completed boolean DEFAULT false,
    completed_at timestamp with time zone
);


ALTER TABLE public.weekly_task_completions OWNER TO hool;

--
-- Name: weekly_task_completions_id_seq; Type: SEQUENCE; Schema: public; Owner: hool
--

CREATE SEQUENCE public.weekly_task_completions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.weekly_task_completions_id_seq OWNER TO hool;

--
-- Name: weekly_task_completions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hool
--

ALTER SEQUENCE public.weekly_task_completions_id_seq OWNED BY public.weekly_task_completions.id;


--
-- Name: bis_items id; Type: DEFAULT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.bis_items ALTER COLUMN id SET DEFAULT nextval('public.bis_items_id_seq'::regclass);


--
-- Name: character_professions id; Type: DEFAULT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.character_professions ALTER COLUMN id SET DEFAULT nextval('public.character_professions_id_seq'::regclass);


--
-- Name: character_progress id; Type: DEFAULT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.character_progress ALTER COLUMN id SET DEFAULT nextval('public.character_progress_id_seq'::regclass);


--
-- Name: crest_entries id; Type: DEFAULT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.crest_entries ALTER COLUMN id SET DEFAULT nextval('public.crest_entries_id_seq'::regclass);


--
-- Name: great_vault_entries id; Type: DEFAULT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.great_vault_entries ALTER COLUMN id SET DEFAULT nextval('public.great_vault_entries_id_seq'::regclass);


--
-- Name: guild_messages id; Type: DEFAULT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.guild_messages ALTER COLUMN id SET DEFAULT nextval('public.guild_messages_id_seq'::regclass);


--
-- Name: guild_permissions id; Type: DEFAULT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.guild_permissions ALTER COLUMN id SET DEFAULT nextval('public.guild_permissions_id_seq'::regclass);


--
-- Name: guilds id; Type: DEFAULT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.guilds ALTER COLUMN id SET DEFAULT nextval('public.guilds_id_seq'::regclass);


--
-- Name: profession_progress id; Type: DEFAULT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.profession_progress ALTER COLUMN id SET DEFAULT nextval('public.profession_progress_id_seq'::regclass);


--
-- Name: recruitment_candidates id; Type: DEFAULT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.recruitment_candidates ALTER COLUMN id SET DEFAULT nextval('public.recruitment_candidates_id_seq'::regclass);


--
-- Name: recruitment_categories id; Type: DEFAULT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.recruitment_categories ALTER COLUMN id SET DEFAULT nextval('public.recruitment_categories_id_seq'::regclass);


--
-- Name: recruitment_history id; Type: DEFAULT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.recruitment_history ALTER COLUMN id SET DEFAULT nextval('public.recruitment_history_id_seq'::regclass);


--
-- Name: scan_jobs id; Type: DEFAULT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.scan_jobs ALTER COLUMN id SET DEFAULT nextval('public.scan_jobs_id_seq'::regclass);


--
-- Name: scan_results id; Type: DEFAULT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.scan_results ALTER COLUMN id SET DEFAULT nextval('public.scan_results_id_seq'::regclass);


--
-- Name: scheduled_scans id; Type: DEFAULT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.scheduled_scans ALTER COLUMN id SET DEFAULT nextval('public.scheduled_scans_id_seq'::regclass);


--
-- Name: season_config id; Type: DEFAULT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.season_config ALTER COLUMN id SET DEFAULT nextval('public.season_config_id_seq'::regclass);


--
-- Name: talent_builds id; Type: DEFAULT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.talent_builds ALTER COLUMN id SET DEFAULT nextval('public.talent_builds_id_seq'::regclass);


--
-- Name: user_tracked_characters id; Type: DEFAULT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.user_tracked_characters ALTER COLUMN id SET DEFAULT nextval('public.user_tracked_characters_id_seq'::regclass);


--
-- Name: users bnet_id; Type: DEFAULT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.users ALTER COLUMN bnet_id SET DEFAULT nextval('public.users_bnet_id_seq'::regclass);


--
-- Name: weekly_targets id; Type: DEFAULT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.weekly_targets ALTER COLUMN id SET DEFAULT nextval('public.weekly_targets_id_seq'::regclass);


--
-- Name: weekly_task_completions id; Type: DEFAULT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.weekly_task_completions ALTER COLUMN id SET DEFAULT nextval('public.weekly_task_completions_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.alembic_version (version_num) FROM stdin;
110e4988dec4
\.


--
-- Data for Name: alembic_version_progress; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.alembic_version_progress (version_num) FROM stdin;
003
\.


--
-- Data for Name: alembic_version_recruitment; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.alembic_version_recruitment (version_num) FROM stdin;
002
\.


--
-- Data for Name: bis_items; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.bis_items (id, character_id, slot, item_name, item_id, target_ilvl, obtained, synced, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: character_professions; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.character_professions (id, character_id, profession_name, slot_index, created_at) FROM stdin;
\.


--
-- Data for Name: character_progress; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.character_progress (id, character_name, realm, guild_id, class_name, spec, role, current_ilvl, gear_details, last_updated, created_at, user_bnet_id, level, avatar_url, display_order, last_gear_sync, parsed_gear, character_stats, mythic_plus_score, raid_progress, last_raiderio_sync) FROM stdin;
14	Chromosexual	Ravencrest	\N	Death Knight	Blood	Tank	102	{"_links": {"self": {"href": "https://eu.api.blizzard.com/profile/wow/character/ravencrest/chromosexual/equipment?namespace=profile-eu"}}, "character": {"key": {"href": "https://eu.api.blizzard.com/profile/wow/character/ravencrest/chromosexual?namespace=profile-eu"}, "name": "Chromosexual", "id": 176557337, "realm": {"key": {"href": "https://eu.api.blizzard.com/data/wow/realm/554?namespace=dynamic-eu"}, "name": "Ravencrest", "id": 554, "slug": "ravencrest"}}, "equipped_items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/153737?namespace=static-12.0.1_65617-eu"}, "id": 153737}, "slot": {"type": "HEAD", "name": "Head"}, "quantity": 1, "context": 62, "bonus_list": [13638], "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Heart-Lesion Faceguard", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/153737?namespace=static-12.0.1_65617-eu"}, "id": 153737}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/4?namespace=static-12.0.1_65617-eu"}, "name": "Plate", "id": 4}, "inventory_type": {"type": "HEAD", "name": "Head"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 50, "display": {"display_string": "50 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 22, "display": {"display_string": "+22 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 22, "is_negated": true, "display": {"display_string": "+22 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 91, "display": {"display_string": "+91 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 23, "is_equip_bonus": true, "display": {"display_string": "+23 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 21, "is_equip_bonus": true, "display": {"display_string": "+21 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "0", "copper": "1"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/6?namespace=static-12.0.1_65617-eu"}, "name": "Death Knight", "id": 6}], "display_string": "Classes: Death Knight"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/210390?namespace=static-12.0.1_65617-eu"}, "name": "Arctic Warden's Warhelm", "id": 210390}, "display_string": "Transmogrified to:\\nArctic Warden's Warhelm", "item_modified_appearance_id": 193006}, "durability": {"value": 70, "display_string": "Durability 70 / 70"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/153739?namespace=static-12.0.1_65617-eu"}, "id": 153739}, "slot": {"type": "NECK", "name": "Neck"}, "quantity": 1, "context": 62, "bonus_list": [13638], "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Heart-Lesion Amulet", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/153739?namespace=static-12.0.1_65617-eu"}, "id": 153739}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "NECK", "name": "Neck"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "stats": [{"type": {"type": "STAMINA", "name": "Stamina"}, "value": 51, "display": {"display_string": "+51 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 36, "is_equip_bonus": true, "display": {"display_string": "+36 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 38, "is_equip_bonus": true, "display": {"display_string": "+38 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/6?namespace=static-12.0.1_65617-eu"}, "name": "Death Knight", "id": 6}], "display_string": "Classes: Death Knight"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "is_subclass_hidden": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/153744?namespace=static-12.0.1_65617-eu"}, "id": 153744}, "slot": {"type": "SHOULDER", "name": "Shoulders"}, "quantity": 1, "context": 62, "bonus_list": [13638], "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Heart-Lesion Shoulderguards", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/153744?namespace=static-12.0.1_65617-eu"}, "id": 153744}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/4?namespace=static-12.0.1_65617-eu"}, "name": "Plate", "id": 4}, "inventory_type": {"type": "SHOULDER", "name": "Shoulder"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 46, "display": {"display_string": "46 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 16, "display": {"display_string": "+16 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 16, "is_negated": true, "display": {"display_string": "+16 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 69, "display": {"display_string": "+69 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 16, "is_equip_bonus": true, "display": {"display_string": "+16 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 17, "is_equip_bonus": true, "display": {"display_string": "+17 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "0", "copper": "1"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/6?namespace=static-12.0.1_65617-eu"}, "name": "Death Knight", "id": 6}], "display_string": "Classes: Death Knight"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/202459?namespace=static-12.0.1_65617-eu"}, "name": "Lingering Phantom's Shoulderplates", "id": 202459}, "display_string": "Transmogrified to:\\nLingering Phantom's Shoulderplates\\nLingering Phantom's Shoulderplates", "item_modified_appearance_id": 184433, "second_item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/202459?namespace=static-12.0.1_65617-eu"}, "name": "Lingering Phantom's Shoulderplates", "id": 202459}, "second_item_modified_appearance_id": 184433}, "durability": {"value": 69, "display_string": "Durability 69 / 70"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/153733?namespace=static-12.0.1_65617-eu"}, "id": 153733}, "slot": {"type": "CHEST", "name": "Chest"}, "quantity": 1, "context": 62, "bonus_list": [13638], "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Heart-Lesion Chestguard", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/153733?namespace=static-12.0.1_65617-eu"}, "id": 153733}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/4?namespace=static-12.0.1_65617-eu"}, "name": "Plate", "id": 4}, "inventory_type": {"type": "CHEST", "name": "Chest"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 66, "display": {"display_string": "66 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 22, "display": {"display_string": "+22 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 22, "is_negated": true, "display": {"display_string": "+22 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 91, "display": {"display_string": "+91 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 21, "is_equip_bonus": true, "display": {"display_string": "+21 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 23, "is_equip_bonus": true, "display": {"display_string": "+23 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "0", "copper": "1"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/6?namespace=static-12.0.1_65617-eu"}, "name": "Death Knight", "id": 6}], "display_string": "Classes: Death Knight"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/184966?namespace=static-12.0.1_65617-eu"}, "name": "Pure Sight Vestments", "id": 184966}, "display_string": "Transmogrified to:\\nPure Sight Vestments", "item_modified_appearance_id": 115965}, "durability": {"value": 113, "display_string": "Durability 113 / 115"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/153745?namespace=static-12.0.1_65617-eu"}, "id": 153745}, "slot": {"type": "WAIST", "name": "Waist"}, "quantity": 1, "context": 62, "bonus_list": [13638], "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Heart-Lesion Waistband", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/153745?namespace=static-12.0.1_65617-eu"}, "id": 153745}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/4?namespace=static-12.0.1_65617-eu"}, "name": "Plate", "id": 4}, "inventory_type": {"type": "WAIST", "name": "Waist"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 37, "display": {"display_string": "37 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 16, "display": {"display_string": "+16 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 16, "is_negated": true, "display": {"display_string": "+16 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 69, "display": {"display_string": "+69 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 17, "is_equip_bonus": true, "display": {"display_string": "+17 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 16, "is_equip_bonus": true, "display": {"display_string": "+16 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "0", "copper": "1"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/6?namespace=static-12.0.1_65617-eu"}, "name": "Death Knight", "id": 6}], "display_string": "Classes: Death Knight"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/225157?namespace=static-12.0.1_65617-eu"}, "name": "Pale Rider's Eternal Girdle", "id": 225157}, "display_string": "Transmogrified to:\\nPale Rider's Eternal Girdle", "item_modified_appearance_id": 220911}, "durability": {"value": 40, "display_string": "Durability 40 / 40"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/153738?namespace=static-12.0.1_65617-eu"}, "id": 153738}, "slot": {"type": "LEGS", "name": "Legs"}, "quantity": 1, "context": 62, "bonus_list": [13638], "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Heart-Lesion Legguards", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/153738?namespace=static-12.0.1_65617-eu"}, "id": 153738}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/4?namespace=static-12.0.1_65617-eu"}, "name": "Plate", "id": 4}, "inventory_type": {"type": "LEGS", "name": "Legs"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 58, "display": {"display_string": "58 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 22, "display": {"display_string": "+22 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 22, "is_negated": true, "display": {"display_string": "+22 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 91, "display": {"display_string": "+91 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 21, "is_equip_bonus": true, "display": {"display_string": "+21 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 23, "is_equip_bonus": true, "display": {"display_string": "+23 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "0", "copper": "1"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/6?namespace=static-12.0.1_65617-eu"}, "name": "Death Knight", "id": 6}], "display_string": "Classes: Death Knight"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/235279?namespace=static-12.0.1_65617-eu"}, "name": "Scorched Shorts", "id": 235279}, "display_string": "Transmogrified to:\\nScorched Shorts", "item_modified_appearance_id": 266763}, "durability": {"value": 85, "display_string": "Durability 85 / 85"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/153735?namespace=static-12.0.1_65617-eu"}, "id": 153735}, "slot": {"type": "FEET", "name": "Feet"}, "quantity": 1, "context": 62, "bonus_list": [13638], "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Heart-Lesion Greaves", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/153735?namespace=static-12.0.1_65617-eu"}, "id": 153735}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/4?namespace=static-12.0.1_65617-eu"}, "name": "Plate", "id": 4}, "inventory_type": {"type": "FEET", "name": "Feet"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 41, "display": {"display_string": "41 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 16, "display": {"display_string": "+16 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 16, "is_negated": true, "display": {"display_string": "+16 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 69, "display": {"display_string": "+69 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 17, "is_equip_bonus": true, "display": {"display_string": "+17 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 16, "is_equip_bonus": true, "display": {"display_string": "+16 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "0", "copper": "1"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/6?namespace=static-12.0.1_65617-eu"}, "name": "Death Knight", "id": 6}], "display_string": "Classes: Death Knight"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/199435?namespace=static-12.0.1_65617-eu"}, "name": "Sabatons of Raging Tempests", "id": 199435}, "display_string": "Transmogrified to:\\nSabatons of Raging Tempests", "item_modified_appearance_id": 182026}, "durability": {"value": 54, "display_string": "Durability 54 / 55"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/153746?namespace=static-12.0.1_65617-eu"}, "id": 153746}, "slot": {"type": "WRIST", "name": "Wrist"}, "quantity": 1, "context": 62, "bonus_list": [13638], "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Heart-Lesion Armguards", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/153746?namespace=static-12.0.1_65617-eu"}, "id": 153746}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/4?namespace=static-12.0.1_65617-eu"}, "name": "Plate", "id": 4}, "inventory_type": {"type": "WRIST", "name": "Wrist"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 33, "display": {"display_string": "33 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 12, "display": {"display_string": "+12 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 12, "is_negated": true, "display": {"display_string": "+12 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 51, "display": {"display_string": "+51 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 12, "is_equip_bonus": true, "display": {"display_string": "+12 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 13, "is_equip_bonus": true, "display": {"display_string": "+13 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "0", "copper": "1"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/6?namespace=static-12.0.1_65617-eu"}, "name": "Death Knight", "id": 6}], "display_string": "Classes: Death Knight"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/153746?namespace=static-12.0.1_65617-eu"}, "name": "Heart-Lesion Armguards", "id": 153746}, "display_string": "Transmogrified to:\\nHeart-Lesion Armguards", "item_modified_appearance_id": 91044}, "durability": {"value": 40, "display_string": "Durability 40 / 40"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/153736?namespace=static-12.0.1_65617-eu"}, "id": 153736}, "slot": {"type": "HANDS", "name": "Hands"}, "quantity": 1, "context": 62, "bonus_list": [13638], "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Heart-Lesion Handguards", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/153736?namespace=static-12.0.1_65617-eu"}, "id": 153736}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/4?namespace=static-12.0.1_65617-eu"}, "name": "Plate", "id": 4}, "inventory_type": {"type": "HAND", "name": "Hands"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 37, "display": {"display_string": "37 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 16, "display": {"display_string": "+16 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 16, "is_negated": true, "display": {"display_string": "+16 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 69, "display": {"display_string": "+69 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 16, "is_equip_bonus": true, "display": {"display_string": "+16 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 17, "is_equip_bonus": true, "display": {"display_string": "+17 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "0", "copper": "1"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/6?namespace=static-12.0.1_65617-eu"}, "name": "Death Knight", "id": 6}], "display_string": "Classes: Death Knight"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/200407?namespace=static-12.0.1_65617-eu"}, "name": "Grasps of the Haunted Frostbrood", "id": 200407}, "display_string": "Transmogrified to:\\nGrasps of the Haunted Frostbrood", "item_modified_appearance_id": 182817}, "durability": {"value": 40, "display_string": "Durability 40 / 40"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/153741?namespace=static-12.0.1_65617-eu"}, "id": 153741}, "slot": {"type": "FINGER_1", "name": "Ring 1"}, "quantity": 1, "context": 62, "bonus_list": [13638], "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Heart-Lesion Ring of Stoicism", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/153741?namespace=static-12.0.1_65617-eu"}, "id": 153741}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "FINGER", "name": "Finger"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "stats": [{"type": {"type": "STAMINA", "name": "Stamina"}, "value": 51, "display": {"display_string": "+51 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 40, "is_equip_bonus": true, "display": {"display_string": "+40 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 34, "is_equip_bonus": true, "display": {"display_string": "+34 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/6?namespace=static-12.0.1_65617-eu"}, "name": "Death Knight", "id": 6}], "display_string": "Classes: Death Knight"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "is_subclass_hidden": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/153742?namespace=static-12.0.1_65617-eu"}, "id": 153742}, "slot": {"type": "FINGER_2", "name": "Ring 2"}, "quantity": 1, "context": 62, "bonus_list": [13638], "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Heart-Lesion Band of Stoicism", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/153742?namespace=static-12.0.1_65617-eu"}, "id": 153742}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "FINGER", "name": "Finger"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "stats": [{"type": {"type": "STAMINA", "name": "Stamina"}, "value": 51, "display": {"display_string": "+51 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 34, "is_equip_bonus": true, "display": {"display_string": "+34 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 40, "is_equip_bonus": true, "display": {"display_string": "+40 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/6?namespace=static-12.0.1_65617-eu"}, "name": "Death Knight", "id": 6}], "display_string": "Classes: Death Knight"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "is_subclass_hidden": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/153743?namespace=static-12.0.1_65617-eu"}, "id": 153743}, "slot": {"type": "TRINKET_1", "name": "Trinket 1"}, "quantity": 1, "context": 62, "bonus_list": [13638], "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Heart-Lesion Defender Stone", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/153743?namespace=static-12.0.1_65617-eu"}, "id": 153743}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "TRINKET", "name": "Trinket"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 21, "display": {"display_string": "+21 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "AGILITY", "name": "Agility"}, "value": 21, "is_negated": true, "display": {"display_string": "+21 Agility", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 21, "is_negated": true, "display": {"display_string": "+21 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 31, "is_equip_bonus": true, "display": {"display_string": "+31 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/6?namespace=static-12.0.1_65617-eu"}, "name": "Death Knight", "id": 6}], "display_string": "Classes: Death Knight"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "is_subclass_hidden": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/153740?namespace=static-12.0.1_65617-eu"}, "id": 153740}, "slot": {"type": "TRINKET_2", "name": "Trinket 2"}, "quantity": 1, "context": 62, "bonus_list": [13638], "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Heart-Lesion Defender Idol", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/153740?namespace=static-12.0.1_65617-eu"}, "id": 153740}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "TRINKET", "name": "Trinket"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 21, "display": {"display_string": "+21 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "AGILITY", "name": "Agility"}, "value": 21, "is_negated": true, "display": {"display_string": "+21 Agility", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 21, "is_negated": true, "display": {"display_string": "+21 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 31, "is_equip_bonus": true, "display": {"display_string": "+31 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/6?namespace=static-12.0.1_65617-eu"}, "name": "Death Knight", "id": 6}], "display_string": "Classes: Death Knight"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "is_subclass_hidden": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/153734?namespace=static-12.0.1_65617-eu"}, "id": 153734}, "slot": {"type": "BACK", "name": "Back"}, "quantity": 1, "context": 62, "bonus_list": [13638], "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Heart-Lesion Cloak of Stoicism", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/153734?namespace=static-12.0.1_65617-eu"}, "id": 153734}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/1?namespace=static-12.0.1_65617-eu"}, "name": "Cloth", "id": 1}, "inventory_type": {"type": "CLOAK", "name": "Back"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 12, "display": {"display_string": "12 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 12, "display": {"display_string": "+12 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "AGILITY", "name": "Agility"}, "value": 12, "is_negated": true, "display": {"display_string": "+12 Agility", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 12, "is_negated": true, "display": {"display_string": "+12 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 51, "display": {"display_string": "+51 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 12, "is_equip_bonus": true, "display": {"display_string": "+12 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 13, "is_equip_bonus": true, "display": {"display_string": "+13 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "0", "copper": "1"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/6?namespace=static-12.0.1_65617-eu"}, "name": "Death Knight", "id": 6}], "display_string": "Classes: Death Knight"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/225158?namespace=static-12.0.1_65617-eu"}, "name": "Pale Rider's Eternal Cloak", "id": 225158}, "display_string": "Transmogrified to:\\nPale Rider's Eternal Cloak", "item_modified_appearance_id": 220912}, "is_subclass_hidden": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/153717?namespace=static-12.0.1_65617-eu"}, "id": 153717}, "slot": {"type": "MAIN_HAND", "name": "Main Hand"}, "quantity": 1, "context": 62, "bonus_list": [13638], "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Heart-Lesion Greatsword", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/153717?namespace=static-12.0.1_65617-eu"}, "id": 153717}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/2?namespace=static-12.0.1_65617-eu"}, "name": "Weapon", "id": 2}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/2/item-subclass/8?namespace=static-12.0.1_65617-eu"}, "name": "Sword", "id": 8}, "inventory_type": {"type": "TWOHWEAPON", "name": "Two-Hand"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "weapon": {"damage": {"min_value": 44, "max_value": 74, "display_string": "44 - 74 Damage", "damage_class": {"type": "PHYSICAL", "name": "Physical"}}, "attack_speed": {"value": 3600, "display_string": "Speed 3.60"}, "dps": {"value": 16.388887, "display_string": "(16.4 damage per second)"}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 22, "display": {"display_string": "+22 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 91, "display": {"display_string": "+91 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 23, "is_equip_bonus": true, "display": {"display_string": "+23 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 21, "is_equip_bonus": true, "display": {"display_string": "+21 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "0", "copper": "1"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/6?namespace=static-12.0.1_65617-eu"}, "name": "Death Knight", "id": 6}], "display_string": "Classes: Death Knight"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/153717?namespace=static-12.0.1_65617-eu"}, "name": "Heart-Lesion Greatsword", "id": 153717}, "display_string": "Transmogrified to:\\nHeart-Lesion Greatsword", "item_modified_appearance_id": 91025}, "durability": {"value": 84, "display_string": "Durability 84 / 85"}}]}	2026-02-21 23:42:42.221081+00	2026-02-21 23:28:47.931451+00	1	\N	https://render.worldofwarcraft.com/eu/character/ravencrest/25/176557337-avatar.jpg	4	2026-02-21 23:42:44.135518+00	{"head": {"ilvl": 102, "track": "Adventurer", "item_name": "Heart-Lesion Faceguard", "item_id": 153737, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 153737}, "neck": {"ilvl": 102, "track": "Adventurer", "item_name": "Heart-Lesion Amulet", "item_id": 153739, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 153739}, "shoulder": {"ilvl": 102, "track": "Adventurer", "item_name": "Heart-Lesion Shoulderguards", "item_id": 153744, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 153744}, "back": {"ilvl": 102, "track": "Adventurer", "item_name": "Heart-Lesion Cloak of Stoicism", "item_id": 153734, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 153734}, "chest": {"ilvl": 102, "track": "Adventurer", "item_name": "Heart-Lesion Chestguard", "item_id": 153733, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 153733}, "wrist": {"ilvl": 102, "track": "Adventurer", "item_name": "Heart-Lesion Armguards", "item_id": 153746, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 153746}, "hands": {"ilvl": 102, "track": "Adventurer", "item_name": "Heart-Lesion Handguards", "item_id": 153736, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 153736}, "waist": {"ilvl": 102, "track": "Adventurer", "item_name": "Heart-Lesion Waistband", "item_id": 153745, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 153745}, "legs": {"ilvl": 102, "track": "Adventurer", "item_name": "Heart-Lesion Legguards", "item_id": 153738, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 153738}, "feet": {"ilvl": 102, "track": "Adventurer", "item_name": "Heart-Lesion Greaves", "item_id": 153735, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 153735}, "ring1": {"ilvl": 102, "track": "Adventurer", "item_name": "Heart-Lesion Ring of Stoicism", "item_id": 153741, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 153741}, "ring2": {"ilvl": 102, "track": "Adventurer", "item_name": "Heart-Lesion Band of Stoicism", "item_id": 153742, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 153742}, "trinket1": {"ilvl": 102, "track": "Adventurer", "item_name": "Heart-Lesion Defender Stone", "item_id": 153743, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 153743}, "trinket2": {"ilvl": 102, "track": "Adventurer", "item_name": "Heart-Lesion Defender Idol", "item_id": 153740, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 153740}, "main_hand": {"ilvl": 102, "track": "Adventurer", "item_name": "Heart-Lesion Greatsword", "item_id": 153717, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 153717}, "off_hand": {"ilvl": 102, "track": "Adventurer", "item_name": "(2H: Heart-Lesion Greatsword)", "item_id": 153717, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 0}}	\N	0	{"manaforge-omega": {"summary": "", "expansion_id": 10, "total_bosses": 8, "normal_bosses_killed": 0, "heroic_bosses_killed": 0, "mythic_bosses_killed": 0}, "liberation-of-undermine": {"summary": "", "expansion_id": 10, "total_bosses": 8, "normal_bosses_killed": 0, "heroic_bosses_killed": 0, "mythic_bosses_killed": 0}, "blackrock-depths": {"summary": "", "expansion_id": 10, "total_bosses": 8, "normal_bosses_killed": 0, "heroic_bosses_killed": 0, "mythic_bosses_killed": 0}, "nerubar-palace": {"summary": "", "expansion_id": 10, "total_bosses": 8, "normal_bosses_killed": 0, "heroic_bosses_killed": 0, "mythic_bosses_killed": 0}}	2026-02-21 23:28:49.01968+00
15	Chrolicious	Ravencrest	\N	Paladin	Protection	Tank	132.6	{"_links": {"self": {"href": "https://eu.api.blizzard.com/profile/wow/character/ravencrest/chrolicious/equipment?namespace=profile-eu"}}, "character": {"key": {"href": "https://eu.api.blizzard.com/profile/wow/character/ravencrest/chrolicious?namespace=profile-eu"}, "name": "Chrolicious", "id": 164515358, "realm": {"key": {"href": "https://eu.api.blizzard.com/data/wow/realm/554?namespace=dynamic-eu"}, "name": "Ravencrest", "id": 554, "slug": "ravencrest"}}, "equipped_items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237619?namespace=static-12.0.1_65617-eu"}, "id": 237619}, "slot": {"type": "HEAD", "name": "Head"}, "quantity": 1, "context": 152, "bonus_list": [10355, 12231, 6652, 12921, 12676, 12353, 1514, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Lightmane of the Lucent Battalion", "modified_appearance_id": 285692, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237619?namespace=static-12.0.1_65617-eu"}, "id": 237619}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/4?namespace=static-12.0.1_65617-eu"}, "name": "Plate", "id": 4}, "inventory_type": {"type": "HEAD", "name": "Head"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 63, "display": {"display_string": "63 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 32, "display": {"display_string": "+32 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 32, "is_negated": true, "display": {"display_string": "+32 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 304, "display": {"display_string": "+304 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 19, "is_equip_bonus": true, "display": {"display_string": "+19 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 41, "is_equip_bonus": true, "display": {"display_string": "+41 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 413140, "display_strings": {"header": "Sell Price:", "gold": "41", "silver": "31", "copper": "40"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/2?namespace=static-12.0.1_65617-eu"}, "name": "Paladin", "id": 2}], "display_string": "Classes: Paladin"}}, "set": {"item_set": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-set/1926?namespace=static-12.0.1_65617-eu"}, "name": "Vows of the Lucent Battalion", "id": 1926}, "items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237622?namespace=static-12.0.1_65617-eu"}, "name": "Cuirass of the Lucent Battalion", "id": 237622}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237620?namespace=static-12.0.1_65617-eu"}, "name": "Protectors of the Lucent Battalion", "id": 237620}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237619?namespace=static-12.0.1_65617-eu"}, "name": "Lightmane of the Lucent Battalion", "id": 237619}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237618?namespace=static-12.0.1_65617-eu"}, "name": "Cuisses of the Lucent Battalion", "id": 237618}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237617?namespace=static-12.0.1_65617-eu"}, "name": "Chargers of the Lucent Battalion", "id": 237617}}], "effects": [{"display_string": "Set: Damage done increased by 6%.", "required_count": 2, "is_active": true}, {"display_string": "Set: Damage done increased by 10%.\\r\\n", "required_count": 4, "is_active": true}], "display_string": "Vows of the Lucent Battalion (4/5)"}, "level": {"value": 144, "display_string": "Item Level 144"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/190488?namespace=static-12.0.1_65617-eu"}, "name": "Darkmoon Harlequin's Visage", "id": 190488}, "display_string": "Transmogrified to:\\nDarkmoon Harlequin's Visage", "item_modified_appearance_id": 168734}, "durability": {"value": 99, "display_string": "Durability 99 / 100"}, "name_description": {"display_string": "Heroic", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/211063?namespace=static-12.0.1_65617-eu"}, "id": 211063}, "slot": {"type": "NECK", "name": "Neck"}, "quantity": 1, "context": 177, "bonus_list": [12290, 41, 10395, 10392, 11215, 1586, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Long-Lost Choker", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/211063?namespace=static-12.0.1_65617-eu"}, "id": 211063}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "NECK", "name": "Neck"}, "binding": {"type": "TO_ACCOUNT", "name": "Binds to Warband"}, "stats": [{"type": {"type": "STAMINA", "name": "Stamina"}, "value": 97, "display": {"display_string": "+97 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 42, "is_equip_bonus": true, "display": {"display_string": "+42 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 53, "is_equip_bonus": true, "display": {"display_string": "+53 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "COMBAT_RATING_LIFESTEAL", "name": "Leech"}, "value": 16, "is_equip_bonus": true, "display": {"display_string": "+16 Leech", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 234524, "display_strings": {"header": "Sell Price:", "gold": "23", "silver": "45", "copper": "24"}}, "requirements": {"level": {"value": 70, "display_string": "Requires Level 70"}}, "level": {"value": 121, "display_string": "Item Level 121"}, "is_subclass_hidden": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237994?namespace=static-12.0.1_65617-eu"}, "id": 237994}, "slot": {"type": "SHOULDER", "name": "Shoulders"}, "quantity": 1, "context": 137, "bonus_list": [6652, 12239, 12293, 9888, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Void-Scarred Captain's Epaulettes", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237994?namespace=static-12.0.1_65617-eu"}, "id": 237994}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/4?namespace=static-12.0.1_65617-eu"}, "name": "Plate", "id": 4}, "inventory_type": {"type": "SHOULDER", "name": "Shoulder"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 53, "display": {"display_string": "53 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 21, "display": {"display_string": "+21 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 21, "is_negated": true, "display": {"display_string": "+21 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 167, "display": {"display_string": "+167 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 16, "is_equip_bonus": true, "display": {"display_string": "+16 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 25, "is_equip_bonus": true, "display": {"display_string": "+25 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 413251, "display_strings": {"header": "Sell Price:", "gold": "41", "silver": "32", "copper": "51"}}, "requirements": {"level": {"value": 70, "display_string": "Requires Level 70"}}, "level": {"value": 131, "display_string": "Item Level 131"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/113990?namespace=static-12.0.1_65617-eu"}, "name": "Overdriven Spaulders", "id": 113990}, "display_string": "Transmogrified to:\\nOverdriven Spaulders\\nDueler's Rosy Shoulder Cape", "item_modified_appearance_id": 62911, "second_item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/212572?namespace=static-12.0.1_65617-eu"}, "name": "Dueler's Rosy Shoulder Cape", "id": 212572}, "second_item_modified_appearance_id": 194903}, "durability": {"value": 100, "display_string": "Durability 100 / 100"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237622?namespace=static-12.0.1_65617-eu"}, "id": 237622}, "slot": {"type": "CHEST", "name": "Chest"}, "quantity": 1, "context": 110, "bonus_list": [6652, 12229, 12676, 12353, 1514, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Cuirass of the Lucent Battalion", "modified_appearance_id": 285728, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237622?namespace=static-12.0.1_65617-eu"}, "id": 237622}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/4?namespace=static-12.0.1_65617-eu"}, "name": "Plate", "id": 4}, "inventory_type": {"type": "CHEST", "name": "Chest"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 84, "display": {"display_string": "84 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 32, "display": {"display_string": "+32 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 32, "is_negated": true, "display": {"display_string": "+32 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 304, "display": {"display_string": "+304 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 21, "is_equip_bonus": true, "display": {"display_string": "+21 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 40, "is_equip_bonus": true, "display": {"display_string": "+40 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 518074, "display_strings": {"header": "Sell Price:", "gold": "51", "silver": "80", "copper": "74"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/2?namespace=static-12.0.1_65617-eu"}, "name": "Paladin", "id": 2}], "display_string": "Classes: Paladin"}}, "set": {"item_set": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-set/1926?namespace=static-12.0.1_65617-eu"}, "name": "Vows of the Lucent Battalion", "id": 1926}, "items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237622?namespace=static-12.0.1_65617-eu"}, "name": "Cuirass of the Lucent Battalion", "id": 237622}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237620?namespace=static-12.0.1_65617-eu"}, "name": "Protectors of the Lucent Battalion", "id": 237620}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237619?namespace=static-12.0.1_65617-eu"}, "name": "Lightmane of the Lucent Battalion", "id": 237619}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237618?namespace=static-12.0.1_65617-eu"}, "name": "Cuisses of the Lucent Battalion", "id": 237618}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237617?namespace=static-12.0.1_65617-eu"}, "name": "Chargers of the Lucent Battalion", "id": 237617}}], "effects": [{"display_string": "Set: Damage done increased by 6%.", "required_count": 2, "is_active": true}, {"display_string": "Set: Damage done increased by 10%.\\r\\n", "required_count": 4, "is_active": true}], "display_string": "Vows of the Lucent Battalion (4/5)"}, "level": {"value": 144, "display_string": "Item Level 144"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/115566?namespace=static-12.0.1_65617-eu"}, "name": "Battleplate of Guiding Light", "id": 115566}, "display_string": "Transmogrified to:\\nBattleplate of Guiding Light", "item_modified_appearance_id": 64456}, "durability": {"value": 160, "display_string": "Durability 160 / 165"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/243045?namespace=static-12.0.1_65617-eu"}, "id": 243045}, "slot": {"type": "WAIST", "name": "Waist"}, "quantity": 1, "context": 81, "bonus_list": [6652, 12921, 12239, 10354, 12293, 1501, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Bygone Wastelander's Girdle", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/243045?namespace=static-12.0.1_65617-eu"}, "id": 243045}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/4?namespace=static-12.0.1_65617-eu"}, "name": "Plate", "id": 4}, "inventory_type": {"type": "WAIST", "name": "Waist"}, "binding": {"type": "TO_ACCOUNT", "name": "Binds to Warband"}, "armor": {"value": 44, "display": {"display_string": "44 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 21, "display": {"display_string": "+21 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 21, "is_negated": true, "display": {"display_string": "+21 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 167, "display": {"display_string": "+167 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 16, "is_equip_bonus": true, "display": {"display_string": "+16 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 25, "is_equip_bonus": true, "display": {"display_string": "+25 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 263766, "display_strings": {"header": "Sell Price:", "gold": "26", "silver": "37", "copper": "66"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 131, "display_string": "Item Level 131"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/114736?namespace=static-12.0.1_65617-eu"}, "name": "Cragplate Girdle", "id": 114736}, "display_string": "Transmogrified to:\\nCragplate Girdle", "item_modified_appearance_id": 63618}, "durability": {"value": 53, "display_string": "Durability 53 / 55"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237618?namespace=static-12.0.1_65617-eu"}, "id": 237618}, "slot": {"type": "LEGS", "name": "Legs"}, "quantity": 1, "context": 109, "bonus_list": [6652, 12293, 12232, 12676, 1501], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Cuisses of the Lucent Battalion", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237618?namespace=static-12.0.1_65617-eu"}, "id": 237618}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/4?namespace=static-12.0.1_65617-eu"}, "name": "Plate", "id": 4}, "inventory_type": {"type": "LEGS", "name": "Legs"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 68, "display": {"display_string": "68 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 28, "display": {"display_string": "+28 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 28, "is_negated": true, "display": {"display_string": "+28 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 223, "display": {"display_string": "+223 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 19, "is_equip_bonus": true, "display": {"display_string": "+19 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 36, "is_equip_bonus": true, "display": {"display_string": "+36 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 543915, "display_strings": {"header": "Sell Price:", "gold": "54", "silver": "39", "copper": "15"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/2?namespace=static-12.0.1_65617-eu"}, "name": "Paladin", "id": 2}], "display_string": "Classes: Paladin"}}, "set": {"item_set": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-set/1926?namespace=static-12.0.1_65617-eu"}, "name": "Vows of the Lucent Battalion", "id": 1926}, "items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237622?namespace=static-12.0.1_65617-eu"}, "name": "Cuirass of the Lucent Battalion", "id": 237622}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237620?namespace=static-12.0.1_65617-eu"}, "name": "Protectors of the Lucent Battalion", "id": 237620}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237619?namespace=static-12.0.1_65617-eu"}, "name": "Lightmane of the Lucent Battalion", "id": 237619}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237618?namespace=static-12.0.1_65617-eu"}, "name": "Cuisses of the Lucent Battalion", "id": 237618}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237617?namespace=static-12.0.1_65617-eu"}, "name": "Chargers of the Lucent Battalion", "id": 237617}}], "effects": [{"display_string": "Set: Damage done increased by 6%.", "required_count": 2, "is_active": true}, {"display_string": "Set: Damage done increased by 10%.\\r\\n", "required_count": 4, "is_active": true}], "display_string": "Vows of the Lucent Battalion (4/5)"}, "level": {"value": 131, "display_string": "Item Level 131"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/113648?namespace=static-12.0.1_65617-eu"}, "name": "Legplates of Fractured Crystal", "id": 113648}, "display_string": "Transmogrified to:\\nLegplates of Fractured Crystal", "item_modified_appearance_id": 67290}, "durability": {"value": 117, "display_string": "Durability 117 / 120"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237990?namespace=static-12.0.1_65617-eu"}, "id": 237990}, "slot": {"type": "FEET", "name": "Feet"}, "quantity": 1, "context": 109, "bonus_list": [6652, 12239, 12293, 9888, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Void-Scarred Captain's Sollerets", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237990?namespace=static-12.0.1_65617-eu"}, "id": 237990}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/4?namespace=static-12.0.1_65617-eu"}, "name": "Plate", "id": 4}, "inventory_type": {"type": "FEET", "name": "Feet"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 49, "display": {"display_string": "49 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 21, "display": {"display_string": "+21 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 21, "is_negated": true, "display": {"display_string": "+21 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 167, "display": {"display_string": "+167 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 16, "is_equip_bonus": true, "display": {"display_string": "+16 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 25, "is_equip_bonus": true, "display": {"display_string": "+25 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 407360, "display_strings": {"header": "Sell Price:", "gold": "40", "silver": "73", "copper": "60"}}, "requirements": {"level": {"value": 70, "display_string": "Requires Level 70"}}, "level": {"value": 131, "display_string": "Item Level 131"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/113660?namespace=static-12.0.1_65617-eu"}, "name": "Mosscrusher Sabatons", "id": 113660}, "display_string": "Transmogrified to:\\nMosscrusher Sabatons", "item_modified_appearance_id": 62453}, "durability": {"value": 78, "display_string": "Durability 78 / 80"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/246660?namespace=static-12.0.1_65617-eu"}, "id": 246660}, "slot": {"type": "WRIST", "name": "Wrist"}, "quantity": 1, "context": 177, "bonus_list": [12239, 11215, 12290, 6652, 12921, 3210, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Ascension Arrestor's Bracers", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/246660?namespace=static-12.0.1_65617-eu"}, "id": 246660}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/4?namespace=static-12.0.1_65617-eu"}, "name": "Plate", "id": 4}, "inventory_type": {"type": "WRIST", "name": "Wrist"}, "binding": {"type": "TO_ACCOUNT", "name": "Binds to Warband"}, "armor": {"value": 37, "display": {"display_string": "37 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 15, "display": {"display_string": "+15 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 15, "is_negated": true, "display": {"display_string": "+15 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 97, "display": {"display_string": "+97 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 13, "is_equip_bonus": true, "display": {"display_string": "+13 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 16, "is_equip_bonus": true, "display": {"display_string": "+16 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 267621, "display_strings": {"header": "Sell Price:", "gold": "26", "silver": "76", "copper": "21"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 121, "display_string": "Item Level 121"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/113871?namespace=static-12.0.1_65617-eu"}, "name": "Bracers of Martial Perfection", "id": 113871}, "display_string": "Transmogrified to:\\nBracers of Martial Perfection", "item_modified_appearance_id": 67293}, "durability": {"value": 55, "display_string": "Durability 55 / 55"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237620?namespace=static-12.0.1_65617-eu"}, "id": 237620}, "slot": {"type": "HANDS", "name": "Hands"}, "quantity": 1, "context": 177, "bonus_list": [6652, 12292, 12230, 12675, 1498], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Protectors of the Lucent Battalion", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237620?namespace=static-12.0.1_65617-eu"}, "id": 237620}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/4?namespace=static-12.0.1_65617-eu"}, "name": "Plate", "id": 4}, "inventory_type": {"type": "HAND", "name": "Hands"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 43, "display": {"display_string": "43 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 21, "display": {"display_string": "+21 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 21, "is_negated": true, "display": {"display_string": "+21 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 155, "display": {"display_string": "+155 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 28, "is_equip_bonus": true, "display": {"display_string": "+28 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 13, "is_equip_bonus": true, "display": {"display_string": "+13 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 281891, "display_strings": {"header": "Sell Price:", "gold": "28", "silver": "18", "copper": "91"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/2?namespace=static-12.0.1_65617-eu"}, "name": "Paladin", "id": 2}], "display_string": "Classes: Paladin"}}, "set": {"item_set": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-set/1926?namespace=static-12.0.1_65617-eu"}, "name": "Vows of the Lucent Battalion", "id": 1926}, "items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237622?namespace=static-12.0.1_65617-eu"}, "name": "Cuirass of the Lucent Battalion", "id": 237622}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237620?namespace=static-12.0.1_65617-eu"}, "name": "Protectors of the Lucent Battalion", "id": 237620}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237619?namespace=static-12.0.1_65617-eu"}, "name": "Lightmane of the Lucent Battalion", "id": 237619}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237618?namespace=static-12.0.1_65617-eu"}, "name": "Cuisses of the Lucent Battalion", "id": 237618}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237617?namespace=static-12.0.1_65617-eu"}, "name": "Chargers of the Lucent Battalion", "id": 237617}}], "effects": [{"display_string": "Set: Damage done increased by 6%.", "required_count": 2, "is_active": true}, {"display_string": "Set: Damage done increased by 10%.\\r\\n", "required_count": 4, "is_active": true}], "display_string": "Vows of the Lucent Battalion (4/5)"}, "level": {"value": 128, "display_string": "Item Level 128"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/113632?namespace=static-12.0.1_65617-eu"}, "name": "Gauntlets of the Heavy Hand", "id": 113632}, "display_string": "Transmogrified to:\\nGauntlets of the Heavy Hand", "item_modified_appearance_id": 62402}, "durability": {"value": 55, "display_string": "Durability 55 / 55"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237957?namespace=static-12.0.1_65617-eu"}, "id": 237957}, "slot": {"type": "FINGER_1", "name": "Ring 1"}, "quantity": 1, "context": 177, "bonus_list": [12290, 42, 10394, 10393, 11215, 9878, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Void-Scarred Hoop", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237957?namespace=static-12.0.1_65617-eu"}, "id": 237957}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "FINGER", "name": "Finger"}, "binding": {"type": "TO_ACCOUNT", "name": "Binds to Warband"}, "unique_equipped": "Unique-Equipped", "stats": [{"type": {"type": "STAMINA", "name": "Stamina"}, "value": 97, "display": {"display_string": "+97 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 30, "is_equip_bonus": true, "display": {"display_string": "+30 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 65, "is_equip_bonus": true, "display": {"display_string": "+65 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "COMBAT_RATING_SPEED", "name": "Speed"}, "value": 16, "is_equip_bonus": true, "display": {"display_string": "+16 Speed", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 347839, "display_strings": {"header": "Sell Price:", "gold": "34", "silver": "78", "copper": "39"}}, "requirements": {"level": {"value": 70, "display_string": "Requires Level 70"}}, "level": {"value": 121, "display_string": "Item Level 121"}, "is_subclass_hidden": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237956?namespace=static-12.0.1_65617-eu"}, "id": 237956}, "slot": {"type": "FINGER_2", "name": "Ring 2"}, "quantity": 1, "context": 109, "bonus_list": [6652, 10394, 10392, 12292, 9885, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Void-Scarred Band", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237956?namespace=static-12.0.1_65617-eu"}, "id": 237956}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "FINGER", "name": "Finger"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "unique_equipped": "Unique-Equipped", "stats": [{"type": {"type": "STAMINA", "name": "Stamina"}, "value": 116, "display": {"display_string": "+116 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 32, "is_equip_bonus": true, "display": {"display_string": "+32 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 70, "is_equip_bonus": true, "display": {"display_string": "+70 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 339777, "display_strings": {"header": "Sell Price:", "gold": "33", "silver": "97", "copper": "77"}}, "requirements": {"level": {"value": 70, "display_string": "Requires Level 70"}}, "level": {"value": 128, "display_string": "Item Level 128"}, "is_subclass_hidden": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/246825?namespace=static-12.0.1_65617-eu"}, "id": 246825}, "slot": {"type": "TRINKET_1", "name": "Trinket 1"}, "quantity": 1, "context": 138, "bonus_list": [12350, 6652, 1556, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Chaotic Nethergate", "modified_appearance_id": 0, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/246825?namespace=static-12.0.1_65617-eu"}, "id": 246825}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "TRINKET", "name": "Trinket"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "unique_equipped": "Unique-Equipped", "stats": [{"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 40, "is_equip_bonus": true, "display": {"display_string": "+40 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "spells": [{"spell": {"key": {"href": "https://eu.api.blizzard.com/data/wow/spell/1244008?namespace=static-12.0.1_65617-eu"}, "name": "Chaotic Nethergate", "id": 1244008}, "description": "Use: Release the Nethergate, flooding your location with corrupted mana dealing 2,504 damage every 1 sec to enemies inside for 10 sec and Heal for 365 per target hit up to 8 targets.\\r\\n (2 Min Cooldown)"}], "sell_price": {"value": 447575, "display_strings": {"header": "Sell Price:", "gold": "44", "silver": "75", "copper": "75"}}, "requirements": {"level": {"value": 68, "display_string": "Requires Level 68"}}, "level": {"value": 134, "display_string": "Item Level 134"}, "is_subclass_hidden": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/246941?namespace=static-12.0.1_65617-eu"}, "id": 246941}, "slot": {"type": "TRINKET_2", "name": "Trinket 2"}, "quantity": 1, "context": 137, "bonus_list": [12290, 6652, 1543, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Symbiotic Ethergauze", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/246941?namespace=static-12.0.1_65617-eu"}, "id": 246941}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "TRINKET", "name": "Trinket"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "unique_equipped": "Unique-Equipped", "stats": [{"type": {"type": "STAMINA", "name": "Stamina"}, "value": 164, "display": {"display_string": "+164 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}], "spells": [{"spell": {"key": {"href": "https://eu.api.blizzard.com/data/wow/spell/1244406?namespace=static-12.0.1_65617-eu"}, "name": "Symbiotic Ethergauze", "id": 1244406}, "description": "Equip: Blocking, parrying, or dodging has a chance to awaken the Gauze causing it to lash out dealing 2,615 Arcane damage split between nearby enemies while shielding you for 15,151 damage for 15 sec.\\r\\n"}], "sell_price": {"value": 447664, "display_strings": {"header": "Sell Price:", "gold": "44", "silver": "76", "copper": "64"}}, "requirements": {"level": {"value": 68, "display_string": "Requires Level 68"}}, "level": {"value": 121, "display_string": "Item Level 121"}, "is_subclass_hidden": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/235499?namespace=static-12.0.1_65617-eu"}, "id": 235499}, "sockets": [{"socket_type": {"type": "FIBER", "name": "Fiber Socket"}, "item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/238041?namespace=static-12.0.1_65617-eu"}, "name": "Dexterous Fiber", "id": 238041}, "context": 11, "display_string": "Dexterous Fiber", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/238041?namespace=static-12.0.1_65617-eu"}, "id": 238041}}], "slot": {"type": "BACK", "name": "Back"}, "quantity": 1, "context": 11, "bonus_list": [12401, 9893, 12260], "quality": {"type": "ARTIFACT", "name": "Artifact"}, "name": "Reshii Wraps", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/235499?namespace=static-12.0.1_65617-eu"}, "id": 235499}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/1?namespace=static-12.0.1_65617-eu"}, "name": "Cloth", "id": 1}, "inventory_type": {"type": "CLOAK", "name": "Back"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 23, "display": {"display_string": "23 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 23, "display": {"display_string": "+23 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "AGILITY", "name": "Agility"}, "value": 23, "is_negated": true, "display": {"display_string": "+23 Agility", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 23, "is_negated": true, "display": {"display_string": "+23 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 281, "display": {"display_string": "+281 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 64, "is_equip_bonus": true, "display": {"display_string": "+64 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "spells": [{"spell": {"key": {"href": "https://eu.api.blizzard.com/data/wow/spell/1217091?namespace=static-12.0.1_65617-eu"}, "name": "Ethereal Energy", "id": 1217091}, "description": "Equip: The wraps attune to your specialization granting you Ethereal Protection:\\r\\n\\r\\nYour spells and abilities have a high chance to coalesce the energy around you, granting you a shield that reduces damage taken by 20% up to 18,125 total damage.\\r\\n\\r\\nUpon falling below 40% health, gain this effect at  500% effectiveness. This effect may only occur once every 6 min.", "display_color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}], "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 170, "display_string": "Item Level 170"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/202166?namespace=static-12.0.1_65617-eu"}, "name": "Wanderer's Rosy Cloak", "id": 202166}, "display_string": "Transmogrified to:\\nWanderer's Rosy Cloak", "item_modified_appearance_id": 184180}, "is_subclass_hidden": true, "name_description": {"display_string": "Rank 6", "color": {"r": 0, "g": 255, "b": 255, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237997?namespace=static-12.0.1_65617-eu"}, "id": 237997}, "slot": {"type": "MAIN_HAND", "name": "Main Hand"}, "quantity": 1, "context": 108, "bonus_list": [12350, 6652, 9891, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Ethereal Handchopper", "modified_appearance_id": 287245, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237997?namespace=static-12.0.1_65617-eu"}, "id": 237997}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/2?namespace=static-12.0.1_65617-eu"}, "name": "Weapon", "id": 2}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/2/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Axe", "id": 0}, "inventory_type": {"type": "WEAPON", "name": "One-Hand"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "weapon": {"damage": {"min_value": 28, "max_value": 58, "display_string": "28 - 58 Damage", "damage_class": {"type": "PHYSICAL", "name": "Physical"}}, "attack_speed": {"value": 2600, "display_string": "Speed 2.60"}, "dps": {"value": 16.53846, "display_string": "(16.5 damage per second)"}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 15, "display": {"display_string": "+15 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 122, "display": {"display_string": "+122 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 12, "is_equip_bonus": true, "display": {"display_string": "+12 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 17, "is_equip_bonus": true, "display": {"display_string": "+17 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 799094, "display_strings": {"header": "Sell Price:", "gold": "79", "silver": "90", "copper": "94"}}, "requirements": {"level": {"value": 70, "display_string": "Requires Level 70"}}, "level": {"value": 134, "display_string": "Item Level 134"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237997?namespace=static-12.0.1_65617-eu"}, "name": "Ethereal Handchopper", "id": 237997}, "display_string": "Transmogrified to:\\nEthereal Handchopper", "item_modified_appearance_id": 287245}, "durability": {"value": 107, "display_string": "Durability 107 / 110"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/218125?namespace=static-12.0.1_65617-eu"}, "id": 218125}, "slot": {"type": "OFF_HAND", "name": "Off Hand"}, "quantity": 1, "context": 109, "bonus_list": [6652, 12293, 3270, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Reactive Webbed Escutcheon", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/218125?namespace=static-12.0.1_65617-eu"}, "id": 218125}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/6?namespace=static-12.0.1_65617-eu"}, "name": "Shield", "id": 6}, "inventory_type": {"type": "SHIELD", "name": "Off Hand"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "unique_equipped": "Unique-Equipped", "armor": {"value": 228, "display": {"display_string": "228 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "shield_block": {"value": 570, "display": {"display_string": "570 Block", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 14, "display": {"display_string": "+14 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 44, "is_negated": true, "display": {"display_string": "+44 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "EXTRA_ARMOR", "name": "Bonus Armor"}, "value": 21, "is_equip_bonus": true, "display": {"display_string": "+21 Bonus Armor", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "spells": [{"spell": {"key": {"href": "https://eu.api.blizzard.com/data/wow/spell/442208?namespace=static-12.0.1_65617-eu"}, "name": "Reactive Webbing", "id": 442208}, "description": "Equip: Taking magic damage has a chance for the webbing to react and adapt, spinning Warding Threads around you for 30 sec. While active, Warding Threads absorb all damage you would take from that source's spell school, up to 30,992. (2 min Cooldown)"}], "sell_price": {"value": 487113, "display_strings": {"header": "Sell Price:", "gold": "48", "silver": "71", "copper": "13"}}, "requirements": {"level": {"value": 70, "display_string": "Requires Level 70"}}, "level": {"value": 131, "display_string": "Item Level 131"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/218125?namespace=static-12.0.1_65617-eu"}, "name": "Reactive Webbed Escutcheon", "id": 218125}, "display_string": "Transmogrified to:\\nReactive Webbed Escutcheon", "item_modified_appearance_id": 200654}, "durability": {"value": 120, "display_string": "Durability 120 / 120"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/190611?namespace=static-12.0.1_65617-eu"}, "id": 190611}, "slot": {"type": "TABARD", "name": "Tabard"}, "quantity": 1, "context": 14, "quality": {"type": "EPIC", "name": "Epic"}, "name": "Tabard of the Enlightened", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/190611?namespace=static-12.0.1_65617-eu"}, "id": 190611}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "TABARD", "name": "Tabard"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "sell_price": {"value": 1000000, "display_strings": {"header": "Sell Price:", "gold": "100", "silver": "0", "copper": "0"}}, "requirements": {"level": {"value": 60, "display_string": "Requires Level 60"}, "reputation": {"faction": {"key": {"href": "https://eu.api.blizzard.com/data/wow/reputation-faction/2478?namespace=static-12.0.1_65617-eu"}, "name": "The Enlightened", "id": 2478}, "min_reputation_level": 7, "display_string": "Requires The Enlightened - Exalted"}}, "level": {"value": 1, "display_string": "Item Level 1"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/43157?namespace=static-12.0.1_65617-eu"}, "name": "Tabard of the Kirin Tor", "id": 43157}, "display_string": "Transmogrified to:\\nTabard of the Kirin Tor", "item_modified_appearance_id": 20874}, "is_subclass_hidden": true}], "equipped_item_sets": [{"item_set": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-set/1926?namespace=static-12.0.1_65617-eu"}, "name": "Vows of the Lucent Battalion", "id": 1926}, "items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237622?namespace=static-12.0.1_65617-eu"}, "name": "Cuirass of the Lucent Battalion", "id": 237622}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237620?namespace=static-12.0.1_65617-eu"}, "name": "Protectors of the Lucent Battalion", "id": 237620}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237619?namespace=static-12.0.1_65617-eu"}, "name": "Lightmane of the Lucent Battalion", "id": 237619}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237618?namespace=static-12.0.1_65617-eu"}, "name": "Cuisses of the Lucent Battalion", "id": 237618}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237617?namespace=static-12.0.1_65617-eu"}, "name": "Chargers of the Lucent Battalion", "id": 237617}}], "effects": [{"display_string": "Set: Damage done increased by 6%.", "required_count": 2, "is_active": true}, {"display_string": "Set: Damage done increased by 10%.\\r\\n", "required_count": 4, "is_active": true}], "display_string": "Vows of the Lucent Battalion (4/5)"}]}	2026-02-21 23:42:42.221081+00	2026-02-21 23:29:08.950535+00	1	\N	https://render.worldofwarcraft.com/eu/character/ravencrest/30/164515358-avatar.jpg	5	2026-02-21 23:42:45.865669+00	{"head": {"ilvl": 144, "track": "Adventurer", "item_name": "Lightmane of the Lucent Battalion", "item_id": 237619, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 237619}, "neck": {"ilvl": 121, "track": "Adventurer", "item_name": "Long-Lost Choker", "item_id": 211063, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 211063}, "shoulder": {"ilvl": 131, "track": "Adventurer", "item_name": "Void-Scarred Captain's Epaulettes", "item_id": 237994, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 237994}, "back": {"ilvl": 170, "track": "Adventurer", "item_name": "Reshii Wraps", "item_id": 235499, "quality": "ARTIFACT", "sockets": 1, "enchanted": false, "icon_id": 235499}, "chest": {"ilvl": 144, "track": "Adventurer", "item_name": "Cuirass of the Lucent Battalion", "item_id": 237622, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 237622}, "wrist": {"ilvl": 121, "track": "Adventurer", "item_name": "Ascension Arrestor's Bracers", "item_id": 246660, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 246660}, "hands": {"ilvl": 128, "track": "Adventurer", "item_name": "Protectors of the Lucent Battalion", "item_id": 237620, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 237620}, "waist": {"ilvl": 131, "track": "Adventurer", "item_name": "Bygone Wastelander's Girdle", "item_id": 243045, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 243045}, "legs": {"ilvl": 131, "track": "Adventurer", "item_name": "Cuisses of the Lucent Battalion", "item_id": 237618, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 237618}, "feet": {"ilvl": 131, "track": "Adventurer", "item_name": "Void-Scarred Captain's Sollerets", "item_id": 237990, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 237990}, "ring1": {"ilvl": 121, "track": "Adventurer", "item_name": "Void-Scarred Hoop", "item_id": 237957, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 237957}, "ring2": {"ilvl": 128, "track": "Adventurer", "item_name": "Void-Scarred Band", "item_id": 237956, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 237956}, "trinket1": {"ilvl": 134, "track": "Adventurer", "item_name": "Chaotic Nethergate", "item_id": 246825, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 246825}, "trinket2": {"ilvl": 121, "track": "Adventurer", "item_name": "Symbiotic Ethergauze", "item_id": 246941, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 246941}, "main_hand": {"ilvl": 134, "track": "Adventurer", "item_name": "Ethereal Handchopper", "item_id": 237997, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 237997}, "off_hand": {"ilvl": 131, "track": "Adventurer", "item_name": "Reactive Webbed Escutcheon", "item_id": 218125, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 218125}}	\N	0	{"manaforge-omega": {"summary": "", "expansion_id": 10, "total_bosses": 8, "normal_bosses_killed": 0, "heroic_bosses_killed": 0, "mythic_bosses_killed": 0}, "liberation-of-undermine": {"summary": "", "expansion_id": 10, "total_bosses": 8, "normal_bosses_killed": 0, "heroic_bosses_killed": 0, "mythic_bosses_killed": 0}, "blackrock-depths": {"summary": "", "expansion_id": 10, "total_bosses": 8, "normal_bosses_killed": 0, "heroic_bosses_killed": 0, "mythic_bosses_killed": 0}, "nerubar-palace": {"summary": "", "expansion_id": 10, "total_bosses": 8, "normal_bosses_killed": 0, "heroic_bosses_killed": 0, "mythic_bosses_killed": 0}}	2026-02-21 23:29:10.083311+00
13	Chroblade	RAvencrest	\N	Demon Hunter	Vengeance	Tank	106	{"_links": {"self": {"href": "https://eu.api.blizzard.com/profile/wow/character/ravencrest/chroblade/equipment?namespace=profile-eu"}}, "character": {"key": {"href": "https://eu.api.blizzard.com/profile/wow/character/ravencrest/chroblade?namespace=profile-eu"}, "name": "Chroblade", "id": 175755731, "realm": {"key": {"href": "https://eu.api.blizzard.com/data/wow/realm/554?namespace=dynamic-eu"}, "name": "Ravencrest", "id": 554, "slug": "ravencrest"}}, "equipped_items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/154737?namespace=static-12.0.1_65617-eu"}, "id": 154737}, "slot": {"type": "HEAD", "name": "Head"}, "quantity": 1, "context": 105, "bonus_list": [13572], "timewalker_level": 80, "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Illidari Blindfold", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/154737?namespace=static-12.0.1_65617-eu"}, "id": 154737}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/2?namespace=static-12.0.1_65617-eu"}, "name": "Leather", "id": 2}, "inventory_type": {"type": "HEAD", "name": "Head"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 22, "display": {"display_string": "22 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 22, "display": {"display_string": "+22 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 22, "is_negated": true, "display": {"display_string": "+22 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 91, "display": {"display_string": "+91 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 21, "is_equip_bonus": true, "display": {"display_string": "+21 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 23, "is_equip_bonus": true, "display": {"display_string": "+23 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "0", "copper": "1"}}, "requirements": {"playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/12?namespace=static-12.0.1_65617-eu"}, "name": "Demon Hunter", "id": 12}], "display_string": "Classes: Demon Hunter"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/217228?namespace=static-12.0.1_65617-eu"}, "name": "Screaming Torchfiend's Burning Scowl", "id": 217228}, "display_string": "Transmogrified to:\\nScreaming Torchfiend's Burning Scowl", "item_modified_appearance_id": 199324}, "durability": {"value": 70, "display_string": "Durability 70 / 70"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/154747?namespace=static-12.0.1_65617-eu"}, "id": 154747}, "slot": {"type": "NECK", "name": "Neck"}, "quantity": 1, "context": 105, "bonus_list": [13572], "timewalker_level": 80, "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Illidari Chain", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/154747?namespace=static-12.0.1_65617-eu"}, "id": 154747}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "NECK", "name": "Neck"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "stats": [{"type": {"type": "STAMINA", "name": "Stamina"}, "value": 51, "display": {"display_string": "+51 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 38, "is_equip_bonus": true, "display": {"display_string": "+38 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 36, "is_equip_bonus": true, "display": {"display_string": "+36 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "0", "copper": "1"}}, "requirements": {"playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/12?namespace=static-12.0.1_65617-eu"}, "name": "Demon Hunter", "id": 12}], "display_string": "Classes: Demon Hunter"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "is_subclass_hidden": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/154735?namespace=static-12.0.1_65617-eu"}, "id": 154735}, "slot": {"type": "SHOULDER", "name": "Shoulders"}, "quantity": 1, "context": 105, "bonus_list": [13572], "timewalker_level": 80, "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Illidari Shoulders", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/154735?namespace=static-12.0.1_65617-eu"}, "id": 154735}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/2?namespace=static-12.0.1_65617-eu"}, "name": "Leather", "id": 2}, "inventory_type": {"type": "SHOULDER", "name": "Shoulder"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 21, "display": {"display_string": "21 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 16, "display": {"display_string": "+16 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 16, "is_negated": true, "display": {"display_string": "+16 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 69, "display": {"display_string": "+69 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 16, "is_equip_bonus": true, "display": {"display_string": "+16 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 17, "is_equip_bonus": true, "display": {"display_string": "+17 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "0", "copper": "1"}}, "requirements": {"playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/12?namespace=static-12.0.1_65617-eu"}, "name": "Demon Hunter", "id": 12}], "display_string": "Classes: Demon Hunter"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/140864?namespace=static-12.0.1_65617-eu"}, "name": "Mantle of the Torn Sky", "id": 140864}, "display_string": "Transmogrified to:\\nMantle of the Torn Sky\\nMantle of the Torn Sky", "item_modified_appearance_id": 81858, "second_item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/140864?namespace=static-12.0.1_65617-eu"}, "name": "Mantle of the Torn Sky", "id": 140864}, "second_item_modified_appearance_id": 81858}, "durability": {"value": 70, "display_string": "Durability 70 / 70"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/154739?namespace=static-12.0.1_65617-eu"}, "id": 154739}, "slot": {"type": "CHEST", "name": "Chest"}, "quantity": 1, "context": 105, "bonus_list": [13572], "timewalker_level": 80, "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Illidari Robe", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/154739?namespace=static-12.0.1_65617-eu"}, "id": 154739}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/2?namespace=static-12.0.1_65617-eu"}, "name": "Leather", "id": 2}, "inventory_type": {"type": "CHEST", "name": "Chest"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 30, "display": {"display_string": "30 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 22, "display": {"display_string": "+22 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 22, "is_negated": true, "display": {"display_string": "+22 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 91, "display": {"display_string": "+91 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 21, "is_equip_bonus": true, "display": {"display_string": "+21 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 23, "is_equip_bonus": true, "display": {"display_string": "+23 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "0", "copper": "1"}}, "requirements": {"playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/12?namespace=static-12.0.1_65617-eu"}, "name": "Demon Hunter", "id": 12}], "display_string": "Classes: Demon Hunter"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/210866?namespace=static-12.0.1_65617-eu"}, "name": "Blademaster's Suntouched Stones", "id": 210866}, "display_string": "Transmogrified to:\\nBlademaster's Suntouched Stones", "item_modified_appearance_id": 193820}, "durability": {"value": 115, "display_string": "Durability 115 / 115"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/154742?namespace=static-12.0.1_65617-eu"}, "id": 154742}, "slot": {"type": "WAIST", "name": "Waist"}, "quantity": 1, "context": 105, "bonus_list": [13572], "timewalker_level": 80, "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Illidari Belt", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/154742?namespace=static-12.0.1_65617-eu"}, "id": 154742}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/2?namespace=static-12.0.1_65617-eu"}, "name": "Leather", "id": 2}, "inventory_type": {"type": "WAIST", "name": "Waist"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 17, "display": {"display_string": "17 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 16, "display": {"display_string": "+16 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 16, "is_negated": true, "display": {"display_string": "+16 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 69, "display": {"display_string": "+69 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 17, "is_equip_bonus": true, "display": {"display_string": "+17 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 16, "is_equip_bonus": true, "display": {"display_string": "+16 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "0", "copper": "1"}}, "requirements": {"playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/12?namespace=static-12.0.1_65617-eu"}, "name": "Demon Hunter", "id": 12}], "display_string": "Classes: Demon Hunter"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/219331?namespace=static-12.0.1_65617-eu"}, "name": "Rune-Branded Waistband", "id": 219331}, "display_string": "Transmogrified to:\\nRune-Branded Waistband", "item_modified_appearance_id": 218270}, "durability": {"value": 40, "display_string": "Durability 40 / 40"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/154736?namespace=static-12.0.1_65617-eu"}, "id": 154736}, "slot": {"type": "LEGS", "name": "Legs"}, "quantity": 1, "context": 105, "bonus_list": [13572], "timewalker_level": 80, "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Illidari Leggings", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/154736?namespace=static-12.0.1_65617-eu"}, "id": 154736}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/2?namespace=static-12.0.1_65617-eu"}, "name": "Leather", "id": 2}, "inventory_type": {"type": "LEGS", "name": "Legs"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 26, "display": {"display_string": "26 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 22, "display": {"display_string": "+22 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 22, "is_negated": true, "display": {"display_string": "+22 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 91, "display": {"display_string": "+91 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 21, "is_equip_bonus": true, "display": {"display_string": "+21 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 23, "is_equip_bonus": true, "display": {"display_string": "+23 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "0", "copper": "1"}}, "requirements": {"playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/12?namespace=static-12.0.1_65617-eu"}, "name": "Demon Hunter", "id": 12}], "display_string": "Classes: Demon Hunter"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/174139?namespace=static-12.0.1_65617-eu"}, "name": "Onyx-Imbued Breeches", "id": 174139}, "display_string": "Transmogrified to:\\nOnyx-Imbued Breeches", "item_modified_appearance_id": 108146}, "durability": {"value": 85, "display_string": "Durability 85 / 85"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/154741?namespace=static-12.0.1_65617-eu"}, "id": 154741}, "slot": {"type": "FEET", "name": "Feet"}, "quantity": 1, "context": 105, "bonus_list": [13572], "timewalker_level": 80, "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Illidari Boots", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/154741?namespace=static-12.0.1_65617-eu"}, "id": 154741}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/2?namespace=static-12.0.1_65617-eu"}, "name": "Leather", "id": 2}, "inventory_type": {"type": "FEET", "name": "Feet"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 19, "display": {"display_string": "19 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 16, "display": {"display_string": "+16 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 16, "is_negated": true, "display": {"display_string": "+16 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 69, "display": {"display_string": "+69 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 17, "is_equip_bonus": true, "display": {"display_string": "+17 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 16, "is_equip_bonus": true, "display": {"display_string": "+16 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "0", "copper": "1"}}, "requirements": {"playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/12?namespace=static-12.0.1_65617-eu"}, "name": "Demon Hunter", "id": 12}], "display_string": "Classes: Demon Hunter"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/253313?namespace=static-12.0.1_65617-eu"}, "name": "Sargerei Commander's Felscorned Sabatons", "id": 253313}, "display_string": "Transmogrified to:\\nSargerei Commander's Felscorned Sabatons", "item_modified_appearance_id": 298793}, "durability": {"value": 55, "display_string": "Durability 55 / 55"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/154740?namespace=static-12.0.1_65617-eu"}, "id": 154740}, "slot": {"type": "WRIST", "name": "Wrist"}, "quantity": 1, "context": 105, "bonus_list": [13572], "timewalker_level": 80, "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Illidari Bracers", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/154740?namespace=static-12.0.1_65617-eu"}, "id": 154740}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/2?namespace=static-12.0.1_65617-eu"}, "name": "Leather", "id": 2}, "inventory_type": {"type": "WRIST", "name": "Wrist"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 15, "display": {"display_string": "15 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 12, "display": {"display_string": "+12 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 12, "is_negated": true, "display": {"display_string": "+12 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 51, "display": {"display_string": "+51 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 12, "is_equip_bonus": true, "display": {"display_string": "+12 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 13, "is_equip_bonus": true, "display": {"display_string": "+13 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "0", "copper": "1"}}, "requirements": {"playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/12?namespace=static-12.0.1_65617-eu"}, "name": "Demon Hunter", "id": 12}], "display_string": "Classes: Demon Hunter"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/240749?namespace=static-12.0.1_65617-eu"}, "name": "Haustvelt Leather Wraps", "id": 240749}, "display_string": "Transmogrified to:\\nHaustvelt Leather Wraps", "item_modified_appearance_id": 289306}, "durability": {"value": 40, "display_string": "Durability 40 / 40"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/154738?namespace=static-12.0.1_65617-eu"}, "id": 154738}, "slot": {"type": "HANDS", "name": "Hands"}, "quantity": 1, "context": 105, "bonus_list": [13572], "timewalker_level": 80, "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Illidari Gloves", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/154738?namespace=static-12.0.1_65617-eu"}, "id": 154738}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/2?namespace=static-12.0.1_65617-eu"}, "name": "Leather", "id": 2}, "inventory_type": {"type": "HAND", "name": "Hands"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 17, "display": {"display_string": "17 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 16, "display": {"display_string": "+16 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 16, "is_negated": true, "display": {"display_string": "+16 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 69, "display": {"display_string": "+69 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 17, "is_equip_bonus": true, "display": {"display_string": "+17 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 16, "is_equip_bonus": true, "display": {"display_string": "+16 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "0", "copper": "1"}}, "requirements": {"playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/12?namespace=static-12.0.1_65617-eu"}, "name": "Demon Hunter", "id": 12}], "display_string": "Classes: Demon Hunter"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/253314?namespace=static-12.0.1_65617-eu"}, "name": "Sargerei Commander's Felscorned Gauntlets", "id": 253314}, "display_string": "Transmogrified to:\\nSargerei Commander's Felscorned Gauntlets", "item_modified_appearance_id": 298794}, "durability": {"value": 40, "display_string": "Durability 40 / 40"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/154745?namespace=static-12.0.1_65617-eu"}, "id": 154745}, "slot": {"type": "FINGER_1", "name": "Ring 1"}, "quantity": 1, "context": 105, "bonus_list": [13572], "timewalker_level": 80, "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Illidari Band", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/154745?namespace=static-12.0.1_65617-eu"}, "id": 154745}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "FINGER", "name": "Finger"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "unique_equipped": "Unique-Equipped", "stats": [{"type": {"type": "STAMINA", "name": "Stamina"}, "value": 51, "display": {"display_string": "+51 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 34, "is_equip_bonus": true, "display": {"display_string": "+34 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 40, "is_equip_bonus": true, "display": {"display_string": "+40 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "0", "copper": "1"}}, "requirements": {"playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/12?namespace=static-12.0.1_65617-eu"}, "name": "Demon Hunter", "id": 12}], "display_string": "Classes: Demon Hunter"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "is_subclass_hidden": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/154746?namespace=static-12.0.1_65617-eu"}, "id": 154746}, "slot": {"type": "FINGER_2", "name": "Ring 2"}, "quantity": 1, "context": 105, "bonus_list": [13572], "timewalker_level": 80, "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Illidari Ring", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/154746?namespace=static-12.0.1_65617-eu"}, "id": 154746}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "FINGER", "name": "Finger"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "unique_equipped": "Unique-Equipped", "stats": [{"type": {"type": "STAMINA", "name": "Stamina"}, "value": 51, "display": {"display_string": "+51 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 40, "is_equip_bonus": true, "display": {"display_string": "+40 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 34, "is_equip_bonus": true, "display": {"display_string": "+34 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "0", "copper": "1"}}, "requirements": {"playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/12?namespace=static-12.0.1_65617-eu"}, "name": "Demon Hunter", "id": 12}], "display_string": "Classes: Demon Hunter"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "is_subclass_hidden": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/154743?namespace=static-12.0.1_65617-eu"}, "id": 154743}, "slot": {"type": "TRINKET_1", "name": "Trinket 1"}, "quantity": 1, "context": 105, "bonus_list": [13572], "timewalker_level": 80, "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Demon Trophy", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/154743?namespace=static-12.0.1_65617-eu"}, "id": 154743}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "TRINKET", "name": "Trinket"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "unique_equipped": "Unique-Equipped", "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 21, "display": {"display_string": "+21 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "STRENGTH", "name": "Strength"}, "value": 21, "is_negated": true, "display": {"display_string": "+21 Strength", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 21, "is_negated": true, "display": {"display_string": "+21 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 31, "is_equip_bonus": true, "display": {"display_string": "+31 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "0", "copper": "1"}}, "requirements": {"playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/12?namespace=static-12.0.1_65617-eu"}, "name": "Demon Hunter", "id": 12}], "display_string": "Classes: Demon Hunter"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "is_subclass_hidden": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/154744?namespace=static-12.0.1_65617-eu"}, "id": 154744}, "slot": {"type": "TRINKET_2", "name": "Trinket 2"}, "quantity": 1, "context": 105, "bonus_list": [13572], "timewalker_level": 80, "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Charm of Demonic Fire", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/154744?namespace=static-12.0.1_65617-eu"}, "id": 154744}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "TRINKET", "name": "Trinket"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "unique_equipped": "Unique-Equipped", "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 21, "display": {"display_string": "+21 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "STRENGTH", "name": "Strength"}, "value": 21, "is_negated": true, "display": {"display_string": "+21 Strength", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 21, "is_negated": true, "display": {"display_string": "+21 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 31, "is_equip_bonus": true, "display": {"display_string": "+31 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "0", "copper": "1"}}, "requirements": {"playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/12?namespace=static-12.0.1_65617-eu"}, "name": "Demon Hunter", "id": 12}], "display_string": "Classes: Demon Hunter"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "is_subclass_hidden": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/154748?namespace=static-12.0.1_65617-eu"}, "id": 154748}, "slot": {"type": "BACK", "name": "Back"}, "quantity": 1, "context": 105, "bonus_list": [13572], "timewalker_level": 80, "quality": {"type": "UNCOMMON", "name": "Uncommon"}, "name": "Illidari Drape", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/154748?namespace=static-12.0.1_65617-eu"}, "id": 154748}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/1?namespace=static-12.0.1_65617-eu"}, "name": "Cloth", "id": 1}, "inventory_type": {"type": "CLOAK", "name": "Back"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 12, "display": {"display_string": "12 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 12, "display": {"display_string": "+12 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "STRENGTH", "name": "Strength"}, "value": 12, "is_negated": true, "display": {"display_string": "+12 Strength", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 12, "is_negated": true, "display": {"display_string": "+12 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 51, "display": {"display_string": "+51 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 12, "is_equip_bonus": true, "display": {"display_string": "+12 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 13, "is_equip_bonus": true, "display": {"display_string": "+13 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "0", "copper": "1"}}, "requirements": {"playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/12?namespace=static-12.0.1_65617-eu"}, "name": "Demon Hunter", "id": 12}], "display_string": "Classes: Demon Hunter"}}, "level": {"value": 102, "display_string": "Item Level 102"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/253315?namespace=static-12.0.1_65617-eu"}, "name": "Sargerei Commander's Felscorned Shroud", "id": 253315}, "display_string": "Transmogrified to:\\nSargerei Commander's Felscorned Shroud", "item_modified_appearance_id": 298795}, "is_subclass_hidden": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/234491?namespace=static-12.0.1_65617-eu"}, "id": 234491}, "slot": {"type": "MAIN_HAND", "name": "Main Hand"}, "quantity": 1, "context": 148, "bonus_list": [12350, 10390, 6652, 10384, 1543, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Sonic Ka-BOOM!-erang", "modified_appearance_id": 248933, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/234491?namespace=static-12.0.1_65617-eu"}, "id": 234491}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/2?namespace=static-12.0.1_65617-eu"}, "name": "Weapon", "id": 2}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/2/item-subclass/9?namespace=static-12.0.1_65617-eu"}, "name": "Warglaives", "id": 9}, "inventory_type": {"type": "WEAPON", "name": "One-Hand"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "weapon": {"damage": {"min_value": 33, "max_value": 53, "display_string": "33 - 53 Damage", "damage_class": {"type": "PHYSICAL", "name": "Physical"}}, "attack_speed": {"value": 2600, "display_string": "Speed 2.60"}, "dps": {"value": 16.53846, "display_string": "(16.5 damage per second)"}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 15, "display": {"display_string": "+15 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 86, "is_negated": true, "display": {"display_string": "+86 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 122, "display": {"display_string": "+122 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 10, "is_equip_bonus": true, "display": {"display_string": "+10 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 18, "is_equip_bonus": true, "display": {"display_string": "+18 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 770342, "display_strings": {"header": "Sell Price:", "gold": "77", "silver": "3", "copper": "42"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 134, "display_string": "Item Level 134"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/234491?namespace=static-12.0.1_65617-eu"}, "name": "Sonic Ka-BOOM!-erang", "id": 234491}, "display_string": "Transmogrified to:\\nSonic Ka-BOOM!-erang", "item_modified_appearance_id": 248933}, "durability": {"value": 120, "display_string": "Durability 120 / 120"}, "name_description": {"display_string": "Mythic+", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/234491?namespace=static-12.0.1_65617-eu"}, "id": 234491}, "slot": {"type": "OFF_HAND", "name": "Off Hand"}, "quantity": 1, "context": 148, "bonus_list": [12350, 10390, 6652, 10384, 1543, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Sonic Ka-BOOM!-erang", "modified_appearance_id": 248933, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/234491?namespace=static-12.0.1_65617-eu"}, "id": 234491}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/2?namespace=static-12.0.1_65617-eu"}, "name": "Weapon", "id": 2}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/2/item-subclass/9?namespace=static-12.0.1_65617-eu"}, "name": "Warglaives", "id": 9}, "inventory_type": {"type": "WEAPON", "name": "One-Hand"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "weapon": {"damage": {"min_value": 33, "max_value": 53, "display_string": "33 - 53 Damage", "damage_class": {"type": "PHYSICAL", "name": "Physical"}}, "attack_speed": {"value": 2600, "display_string": "Speed 2.60"}, "dps": {"value": 16.53846, "display_string": "(16.5 damage per second)"}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 15, "display": {"display_string": "+15 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 86, "is_negated": true, "display": {"display_string": "+86 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 122, "display": {"display_string": "+122 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 10, "is_equip_bonus": true, "display": {"display_string": "+10 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 18, "is_equip_bonus": true, "display": {"display_string": "+18 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 770342, "display_strings": {"header": "Sell Price:", "gold": "77", "silver": "3", "copper": "42"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 134, "display_string": "Item Level 134"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/234491?namespace=static-12.0.1_65617-eu"}, "name": "Sonic Ka-BOOM!-erang", "id": 234491}, "display_string": "Transmogrified to:\\nSonic Ka-BOOM!-erang", "item_modified_appearance_id": 248933}, "durability": {"value": 120, "display_string": "Durability 120 / 120"}, "name_description": {"display_string": "Mythic+", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}]}	2026-02-21 23:42:42.221081+00	2026-02-21 23:28:32.977899+00	1	\N	https://render.worldofwarcraft.com/eu/character/ravencrest/211/175755731-avatar.jpg	3	2026-02-21 23:42:46.759474+00	{"head": {"ilvl": 102, "track": "Adventurer", "item_name": "Illidari Blindfold", "item_id": 154737, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 154737}, "neck": {"ilvl": 102, "track": "Adventurer", "item_name": "Illidari Chain", "item_id": 154747, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 154747}, "shoulder": {"ilvl": 102, "track": "Adventurer", "item_name": "Illidari Shoulders", "item_id": 154735, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 154735}, "back": {"ilvl": 102, "track": "Adventurer", "item_name": "Illidari Drape", "item_id": 154748, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 154748}, "chest": {"ilvl": 102, "track": "Adventurer", "item_name": "Illidari Robe", "item_id": 154739, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 154739}, "wrist": {"ilvl": 102, "track": "Adventurer", "item_name": "Illidari Bracers", "item_id": 154740, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 154740}, "hands": {"ilvl": 102, "track": "Adventurer", "item_name": "Illidari Gloves", "item_id": 154738, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 154738}, "waist": {"ilvl": 102, "track": "Adventurer", "item_name": "Illidari Belt", "item_id": 154742, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 154742}, "legs": {"ilvl": 102, "track": "Adventurer", "item_name": "Illidari Leggings", "item_id": 154736, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 154736}, "feet": {"ilvl": 102, "track": "Adventurer", "item_name": "Illidari Boots", "item_id": 154741, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 154741}, "ring1": {"ilvl": 102, "track": "Adventurer", "item_name": "Illidari Band", "item_id": 154745, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 154745}, "ring2": {"ilvl": 102, "track": "Adventurer", "item_name": "Illidari Ring", "item_id": 154746, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 154746}, "trinket1": {"ilvl": 102, "track": "Adventurer", "item_name": "Demon Trophy", "item_id": 154743, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 154743}, "trinket2": {"ilvl": 102, "track": "Adventurer", "item_name": "Charm of Demonic Fire", "item_id": 154744, "quality": "UNCOMMON", "sockets": 0, "enchanted": false, "icon_id": 154744}, "main_hand": {"ilvl": 134, "track": "Adventurer", "item_name": "Sonic Ka-BOOM!-erang", "item_id": 234491, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 234491}, "off_hand": {"ilvl": 134, "track": "Adventurer", "item_name": "Sonic Ka-BOOM!-erang", "item_id": 234491, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 234491}}	\N	0	{"manaforge-omega": {"summary": "", "expansion_id": 10, "total_bosses": 8, "normal_bosses_killed": 0, "heroic_bosses_killed": 0, "mythic_bosses_killed": 0}, "liberation-of-undermine": {"summary": "", "expansion_id": 10, "total_bosses": 8, "normal_bosses_killed": 0, "heroic_bosses_killed": 0, "mythic_bosses_killed": 0}, "blackrock-depths": {"summary": "", "expansion_id": 10, "total_bosses": 8, "normal_bosses_killed": 0, "heroic_bosses_killed": 0, "mythic_bosses_killed": 0}, "nerubar-palace": {"summary": "", "expansion_id": 10, "total_bosses": 8, "normal_bosses_killed": 0, "heroic_bosses_killed": 0, "mythic_bosses_killed": 0}}	2026-02-21 23:28:34.766566+00
12	Chiruzo	Ravencrest	\N	Monk	Brewmaster	Tank	105.8	{"_links": {"self": {"href": "https://eu.api.blizzard.com/profile/wow/character/ravencrest/chiruzo/equipment?namespace=profile-eu"}}, "character": {"key": {"href": "https://eu.api.blizzard.com/profile/wow/character/ravencrest/chiruzo?namespace=profile-eu"}, "name": "Chiruzo", "id": 173536623, "realm": {"key": {"href": "https://eu.api.blizzard.com/data/wow/realm/554?namespace=dynamic-eu"}, "name": "Ravencrest", "id": 554, "slug": "ravencrest"}}, "equipped_items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/234498?namespace=static-12.0.1_65617-eu"}, "id": 234498}, "slot": {"type": "HEAD", "name": "Head"}, "quantity": 1, "context": 16, "bonus_list": [10390, 6652, 12176, 11964, 10383, 11988, 1507, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Waterworks Filtration Mask", "modified_appearance_id": 248940, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/234498?namespace=static-12.0.1_65617-eu"}, "id": 234498}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/2?namespace=static-12.0.1_65617-eu"}, "name": "Leather", "id": 2}, "inventory_type": {"type": "HEAD", "name": "Head"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 23, "display": {"display_string": "23 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 22, "display": {"display_string": "+22 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 22, "is_negated": true, "display": {"display_string": "+22 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 95, "display": {"display_string": "+95 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 16, "is_equip_bonus": true, "display": {"display_string": "+16 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 28, "is_equip_bonus": true, "display": {"display_string": "+28 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 400831, "display_strings": {"header": "Sell Price:", "gold": "40", "silver": "8", "copper": "31"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 103, "display_string": "Item Level 103"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/229298?namespace=static-12.0.1_65617-eu"}, "name": "Ageless Serpent's Mane", "id": 229298}, "display_string": "Transmogrified to:\\nAgeless Serpent's Mane", "item_modified_appearance_id": 225987}, "durability": {"value": 100, "display_string": "Durability 100 / 100"}, "name_description": {"display_string": "Mythic+", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/221103?namespace=static-12.0.1_65617-eu"}, "id": 221103}, "sockets": [{"socket_type": {"type": "PRISMATIC", "name": "Prismatic Socket"}, "item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/213743?namespace=static-12.0.1_65617-eu"}, "name": "Culminating Blasphemite", "id": 213743}, "display_string": "+12 Primary Stat and +0.15% Critical Effect per unique Algari gem color", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/213743?namespace=static-12.0.1_65617-eu"}, "id": 213743}}, {"socket_type": {"type": "PRISMATIC", "name": "Prismatic Socket"}, "item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/213479?namespace=static-12.0.1_65617-eu"}, "name": "Deadly Emerald", "id": 213479}, "display_string": "+10 Haste and +3 Critical Strike", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/213479?namespace=static-12.0.1_65617-eu"}, "id": 213479}}], "slot": {"type": "NECK", "name": "Neck"}, "quantity": 1, "context": 33, "bonus_list": [10390, 6652, 10383, 10879, 10396, 11988, 3150, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Flickering Glowtorc", "modified_appearance_id": 0, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/221103?namespace=static-12.0.1_65617-eu"}, "id": 221103}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "NECK", "name": "Neck"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "stats": [{"type": {"type": "STAMINA", "name": "Stamina"}, "value": 53, "display": {"display_string": "+53 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 50, "is_equip_bonus": true, "display": {"display_string": "+50 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 25, "is_equip_bonus": true, "display": {"display_string": "+25 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 227479, "display_strings": {"header": "Sell Price:", "gold": "22", "silver": "74", "copper": "79"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 103, "display_string": "Item Level 103"}, "is_subclass_hidden": true, "name_description": {"display_string": "Mythic+", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/229296?namespace=static-12.0.1_65617-eu"}, "id": 229296}, "slot": {"type": "SHOULDER", "name": "Shoulders"}, "quantity": 1, "context": 5, "bonus_list": [10355, 11962, 6652, 12179, 11988, 1507, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Ageless Serpent's Shoulderpads", "modified_appearance_id": 225959, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/229296?namespace=static-12.0.1_65617-eu"}, "id": 229296}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/2?namespace=static-12.0.1_65617-eu"}, "name": "Leather", "id": 2}, "inventory_type": {"type": "SHOULDER", "name": "Shoulder"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 21, "display": {"display_string": "21 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 16, "display": {"display_string": "+16 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 16, "is_negated": true, "display": {"display_string": "+16 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 71, "display": {"display_string": "+71 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 23, "is_equip_bonus": true, "display": {"display_string": "+23 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 10, "is_equip_bonus": true, "display": {"display_string": "+10 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 384843, "display_strings": {"header": "Sell Price:", "gold": "38", "silver": "48", "copper": "43"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/10?namespace=static-12.0.1_65617-eu"}, "name": "Monk", "id": 10}], "display_string": "Classes: Monk"}}, "set": {"item_set": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-set/1873?namespace=static-12.0.1_65617-eu"}, "name": "Ageless Serpent's Foresight", "id": 1873}, "items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/229301?namespace=static-12.0.1_65617-eu"}, "name": "Ageless Serpent's Inked Coils", "id": 229301}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/229299?namespace=static-12.0.1_65617-eu"}, "name": "Ageless Serpent's Handguards", "id": 229299}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/229298?namespace=static-12.0.1_65617-eu"}, "name": "Ageless Serpent's Mane", "id": 229298}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/229297?namespace=static-12.0.1_65617-eu"}, "name": "Ageless Serpent's Leggings", "id": 229297}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/229296?namespace=static-12.0.1_65617-eu"}, "name": "Ageless Serpent's Shoulderpads", "id": 229296}, "is_equipped": true}], "effects": [{"display_string": "Set: Each time you take damage you have a chance to activate Luck of the Draw! causing you to cast Fortifying Brew for 6.0 sec. Your damage done is increased by 15% for 8 sec after Luck of the Draw! activates.", "required_count": 2, "is_active": true}, {"display_string": "(4) Set: When you gain  Luck of the Draw!, your next 2 casts of Blackout Kick deal 250% increased damage and incur a 2.0 sec reduced cooldown.", "required_count": 4}], "display_string": "Ageless Serpent's Foresight (2/5)"}, "level": {"value": 103, "display_string": "Item Level 103"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/229296?namespace=static-12.0.1_65617-eu"}, "name": "Ageless Serpent's Shoulderpads", "id": 229296}, "display_string": "Transmogrified to:\\nAgeless Serpent's Shoulderpads\\nAgeless Serpent's Shoulderpads", "item_modified_appearance_id": 225963, "second_item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/229296?namespace=static-12.0.1_65617-eu"}, "name": "Ageless Serpent's Shoulderpads", "id": 229296}, "second_item_modified_appearance_id": 225963}, "durability": {"value": 99, "display_string": "Durability 99 / 100"}, "name_description": {"display_string": "Heroic", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237130?namespace=static-12.0.1_65617-eu"}, "id": 237130}, "slot": {"type": "SHIRT", "name": "Shirt"}, "quantity": 1, "quality": {"type": "COMMON", "name": "Common"}, "name": "Undermine Undershirt", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237130?namespace=static-12.0.1_65617-eu"}, "id": 237130}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "BODY", "name": "Shirt"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "sell_price": {"value": 361, "display_strings": {"header": "Sell Price:", "gold": "0", "silver": "3", "copper": "61"}}, "description": "Dated? Try retro.", "level": {"value": 1, "display_string": "Item Level 1"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/142503?namespace=static-12.0.1_65617-eu"}, "name": "Hidden Shirt", "id": 142503}, "display_string": "Transmogrified to:\\nHidden Shirt", "item_modified_appearance_id": 83202}, "is_subclass_hidden": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/246637?namespace=static-12.0.1_65617-eu"}, "id": 246637}, "slot": {"type": "CHEST", "name": "Chest"}, "quantity": 1, "context": 177, "bonus_list": [12239, 13671, 12290, 6652, 3210, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Ascension Arrestor's Doublet", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/246637?namespace=static-12.0.1_65617-eu"}, "id": 246637}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/2?namespace=static-12.0.1_65617-eu"}, "name": "Leather", "id": 2}, "inventory_type": {"type": "CHEST", "name": "Chest"}, "binding": {"type": "TO_ACCOUNT", "name": "Binds to Warband"}, "armor": {"value": 33, "display": {"display_string": "33 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 26, "display": {"display_string": "+26 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 26, "is_negated": true, "display": {"display_string": "+26 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 173, "display": {"display_string": "+173 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 28, "is_equip_bonus": true, "display": {"display_string": "+28 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 23, "is_equip_bonus": true, "display": {"display_string": "+23 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 526415, "display_strings": {"header": "Sell Price:", "gold": "52", "silver": "64", "copper": "15"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 121, "display_string": "Item Level 121"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/210352?namespace=static-12.0.1_65617-eu"}, "name": "Crystalline Tender's Vest", "id": 210352}, "display_string": "Transmogrified to:\\nCrystalline Tender's Vest", "item_modified_appearance_id": 192973}, "durability": {"value": 163, "display_string": "Durability 163 / 165"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/246643?namespace=static-12.0.1_65617-eu"}, "id": 246643}, "slot": {"type": "WAIST", "name": "Waist"}, "quantity": 1, "context": 177, "bonus_list": [12239, 11215, 12290, 6652, 12921, 3210, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Ascension Arrestor's Clasp", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/246643?namespace=static-12.0.1_65617-eu"}, "id": 246643}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/2?namespace=static-12.0.1_65617-eu"}, "name": "Leather", "id": 2}, "inventory_type": {"type": "WAIST", "name": "Waist"}, "binding": {"type": "TO_ACCOUNT", "name": "Binds to Warband"}, "armor": {"value": 19, "display": {"display_string": "19 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 19, "display": {"display_string": "+19 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 19, "is_negated": true, "display": {"display_string": "+19 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 130, "display": {"display_string": "+130 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 18, "is_equip_bonus": true, "display": {"display_string": "+18 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 21, "is_equip_bonus": true, "display": {"display_string": "+21 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 270610, "display_strings": {"header": "Sell Price:", "gold": "27", "silver": "6", "copper": "10"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 121, "display_string": "Item Level 121"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/210371?namespace=static-12.0.1_65617-eu"}, "name": "Crystalline Tender's Belt", "id": 210371}, "display_string": "Transmogrified to:\\nCrystalline Tender's Belt", "item_modified_appearance_id": 192992}, "durability": {"value": 53, "display_string": "Durability 53 / 55"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/229297?namespace=static-12.0.1_65617-eu"}, "id": 229297}, "enchantments": [{"display_string": "Enchanted: +8 Intellect & +8 Stamina |A:Professions-ChatIcon-Quality-Tier3:20:20|a", "source_item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/222893?namespace=static-12.0.1_65617-eu"}, "name": "Sunset Spellthread", "id": 222893}, "enchantment_id": 7534, "enchantment_slot": {"id": 0, "type": "PERMANENT"}}], "slot": {"type": "LEGS", "name": "Legs"}, "quantity": 1, "context": 16, "bonus_list": [6652, 10390, 11988, 12178, 11961, 1507], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Ageless Serpent's Leggings", "modified_appearance_id": 225971, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/229297?namespace=static-12.0.1_65617-eu"}, "id": 229297}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/2?namespace=static-12.0.1_65617-eu"}, "name": "Leather", "id": 2}, "inventory_type": {"type": "LEGS", "name": "Legs"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 26, "display": {"display_string": "26 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 22, "display": {"display_string": "+22 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 22, "is_negated": true, "display": {"display_string": "+22 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 95, "display": {"display_string": "+95 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 13, "is_equip_bonus": true, "display": {"display_string": "+13 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 31, "is_equip_bonus": true, "display": {"display_string": "+31 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 516026, "display_strings": {"header": "Sell Price:", "gold": "51", "silver": "60", "copper": "26"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/10?namespace=static-12.0.1_65617-eu"}, "name": "Monk", "id": 10}], "display_string": "Classes: Monk"}}, "set": {"item_set": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-set/1873?namespace=static-12.0.1_65617-eu"}, "name": "Ageless Serpent's Foresight", "id": 1873}, "items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/229301?namespace=static-12.0.1_65617-eu"}, "name": "Ageless Serpent's Inked Coils", "id": 229301}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/229299?namespace=static-12.0.1_65617-eu"}, "name": "Ageless Serpent's Handguards", "id": 229299}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/229298?namespace=static-12.0.1_65617-eu"}, "name": "Ageless Serpent's Mane", "id": 229298}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/229297?namespace=static-12.0.1_65617-eu"}, "name": "Ageless Serpent's Leggings", "id": 229297}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/229296?namespace=static-12.0.1_65617-eu"}, "name": "Ageless Serpent's Shoulderpads", "id": 229296}, "is_equipped": true}], "effects": [{"display_string": "Set: Each time you take damage you have a chance to activate Luck of the Draw! causing you to cast Fortifying Brew for 6.0 sec. Your damage done is increased by 15% for 8 sec after Luck of the Draw! activates.", "required_count": 2, "is_active": true}, {"display_string": "(4) Set: When you gain  Luck of the Draw!, your next 2 casts of Blackout Kick deal 250% increased damage and incur a 2.0 sec reduced cooldown.", "required_count": 4}], "display_string": "Ageless Serpent's Foresight (2/5)"}, "level": {"value": 103, "display_string": "Item Level 103"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/229297?namespace=static-12.0.1_65617-eu"}, "name": "Ageless Serpent's Leggings", "id": 229297}, "display_string": "Transmogrified to:\\nAgeless Serpent's Leggings", "item_modified_appearance_id": 225971}, "durability": {"value": 120, "display_string": "Durability 120 / 120"}, "name_description": {"display_string": "Mythic+", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/246638?namespace=static-12.0.1_65617-eu"}, "id": 246638}, "slot": {"type": "FEET", "name": "Feet"}, "quantity": 1, "context": 177, "bonus_list": [12239, 13671, 12290, 6652, 3210, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Ascension Arrestor's Shoes", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/246638?namespace=static-12.0.1_65617-eu"}, "id": 246638}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/2?namespace=static-12.0.1_65617-eu"}, "name": "Leather", "id": 2}, "inventory_type": {"type": "FEET", "name": "Feet"}, "binding": {"type": "TO_ACCOUNT", "name": "Binds to Warband"}, "armor": {"value": 21, "display": {"display_string": "21 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 19, "display": {"display_string": "+19 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 19, "is_negated": true, "display": {"display_string": "+19 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 130, "display": {"display_string": "+130 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 17, "is_equip_bonus": true, "display": {"display_string": "+17 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 22, "is_equip_bonus": true, "display": {"display_string": "+22 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 395529, "display_strings": {"header": "Sell Price:", "gold": "39", "silver": "55", "copper": "29"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 121, "display_string": "Item Level 121"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/228888?namespace=static-12.0.1_65617-eu"}, "name": "Rushed Beta Launchers", "id": 228888}, "display_string": "Transmogrified to:\\nRushed Beta Launchers", "item_modified_appearance_id": 224973}, "durability": {"value": 80, "display_string": "Durability 80 / 80"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/246644?namespace=static-12.0.1_65617-eu"}, "id": 246644}, "slot": {"type": "WRIST", "name": "Wrist"}, "quantity": 1, "context": 177, "bonus_list": [12239, 11215, 12290, 6652, 12921, 3210, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Ascension Arrestor's Bindings", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/246644?namespace=static-12.0.1_65617-eu"}, "id": 246644}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/2?namespace=static-12.0.1_65617-eu"}, "name": "Leather", "id": 2}, "inventory_type": {"type": "WRIST", "name": "Wrist"}, "binding": {"type": "TO_ACCOUNT", "name": "Binds to Warband"}, "armor": {"value": 17, "display": {"display_string": "17 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 15, "display": {"display_string": "+15 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 15, "is_negated": true, "display": {"display_string": "+15 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 97, "display": {"display_string": "+97 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 13, "is_equip_bonus": true, "display": {"display_string": "+13 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 16, "is_equip_bonus": true, "display": {"display_string": "+16 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 271598, "display_strings": {"header": "Sell Price:", "gold": "27", "silver": "15", "copper": "98"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 121, "display_string": "Item Level 121"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/168665?namespace=static-12.0.1_65617-eu"}, "name": "Hidden Bracers", "id": 168665}, "display_string": "Transmogrified to:\\nHidden Bracers", "item_modified_appearance_id": 104604}, "durability": {"value": 55, "display_string": "Durability 55 / 55"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/246639?namespace=static-12.0.1_65617-eu"}, "id": 246639}, "slot": {"type": "HANDS", "name": "Hands"}, "quantity": 1, "context": 177, "bonus_list": [12239, 13671, 12290, 42, 3210, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Ascension Arrestor's Gloves", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/246639?namespace=static-12.0.1_65617-eu"}, "id": 246639}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/2?namespace=static-12.0.1_65617-eu"}, "name": "Leather", "id": 2}, "inventory_type": {"type": "HAND", "name": "Hands"}, "binding": {"type": "TO_ACCOUNT", "name": "Binds to Warband"}, "armor": {"value": 19, "display": {"display_string": "19 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 19, "display": {"display_string": "+19 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 19, "is_negated": true, "display": {"display_string": "+19 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 130, "display": {"display_string": "+130 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 20, "is_equip_bonus": true, "display": {"display_string": "+20 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 18, "is_equip_bonus": true, "display": {"display_string": "+18 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "COMBAT_RATING_SPEED", "name": "Speed"}, "value": 17, "is_equip_bonus": true, "display": {"display_string": "+17 Speed", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 266687, "display_strings": {"header": "Sell Price:", "gold": "26", "silver": "66", "copper": "87"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 121, "display_string": "Item Level 121"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/229299?namespace=static-12.0.1_65617-eu"}, "name": "Ageless Serpent's Handguards", "id": 229299}, "display_string": "Transmogrified to:\\nAgeless Serpent's Handguards", "item_modified_appearance_id": 225995}, "durability": {"value": 55, "display_string": "Durability 55 / 55"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/228840?namespace=static-12.0.1_65617-eu"}, "id": 228840}, "enchantments": [{"display_string": "Enchanted: Cursed Versatility |A:Professions-ChatIcon-Quality-Tier3:20:20|a", "enchantment_id": 7476, "enchantment_slot": {"id": 0, "type": "PERMANENT"}}], "slot": {"type": "FINGER_1", "name": "Ring 1"}, "quantity": 1, "context": 6, "bonus_list": [6652, 10394, 10392, 10356, 11994, 1520, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Faded Championship Ring", "modified_appearance_id": 0, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/228840?namespace=static-12.0.1_65617-eu"}, "id": 228840}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "FINGER", "name": "Finger"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "unique_equipped": "Unique-Equipped", "stats": [{"type": {"type": "STAMINA", "name": "Stamina"}, "value": 72, "display": {"display_string": "+72 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 64, "is_equip_bonus": true, "display": {"display_string": "+64 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 20, "is_equip_bonus": true, "display": {"display_string": "+20 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 346782, "display_strings": {"header": "Sell Price:", "gold": "34", "silver": "67", "copper": "82"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "description": "'I got one more in me' - Unknown", "level": {"value": 111, "display_string": "Item Level 111"}, "is_subclass_hidden": true, "name_description": {"display_string": "Mythic", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/246677?namespace=static-12.0.1_65617-eu"}, "id": 246677}, "slot": {"type": "FINGER_2", "name": "Ring 2"}, "quantity": 1, "context": 177, "bonus_list": [13671, 12290, 6652, 10394, 10392, 3210, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Ascension Arrestor's Band", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/246677?namespace=static-12.0.1_65617-eu"}, "id": 246677}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "FINGER", "name": "Finger"}, "binding": {"type": "TO_ACCOUNT", "name": "Binds to Warband"}, "unique_equipped": "Unique-Equipped", "stats": [{"type": {"type": "STAMINA", "name": "Stamina"}, "value": 97, "display": {"display_string": "+97 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 38, "is_equip_bonus": true, "display": {"display_string": "+38 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 57, "is_equip_bonus": true, "display": {"display_string": "+57 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 330822, "display_strings": {"header": "Sell Price:", "gold": "33", "silver": "8", "copper": "22"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 121, "display_string": "Item Level 121"}, "is_subclass_hidden": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/219308?namespace=static-12.0.1_65617-eu"}, "id": 219308}, "slot": {"type": "TRINKET_1", "name": "Trinket 1"}, "quantity": 1, "context": 35, "bonus_list": [10390, 6652, 10383, 11996, 3170, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Signet of the Priory", "modified_appearance_id": 0, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/219308?namespace=static-12.0.1_65617-eu"}, "id": 219308}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "TRINKET", "name": "Trinket"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "unique_equipped": "Unique-Equipped", "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 24, "display": {"display_string": "+24 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 24, "is_negated": true, "display": {"display_string": "+24 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STRENGTH", "name": "Strength"}, "value": 24, "is_negated": true, "display": {"display_string": "+24 Strength", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}], "spells": [{"spell": {"key": {"href": "https://eu.api.blizzard.com/data/wow/spell/443531?namespace=static-12.0.1_65617-eu"}, "name": "Bolstering Light", "id": 443531}, "description": "Use: Raise your signet to the Light, increasing your highest secondary stat by 163 for 20 sec. Your act inspires nearby signetbearers within your party, granting them 4 of the same stat for 20 sec. (2 Min Cooldown)"}], "sell_price": {"value": 439762, "display_strings": {"header": "Sell Price:", "gold": "43", "silver": "97", "copper": "62"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 118, "display_string": "Item Level 118"}, "is_subclass_hidden": true, "name_description": {"display_string": "Mythic+", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/230186?namespace=static-12.0.1_65617-eu"}, "id": 230186}, "slot": {"type": "TRINKET_2", "name": "Trinket 2"}, "quantity": 1, "context": 5, "bonus_list": [6652, 10355, 11990, 1514, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Mister Pick-Me-Up", "modified_appearance_id": 0, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/230186?namespace=static-12.0.1_65617-eu"}, "id": 230186}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "TRINKET", "name": "Trinket"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "unique_equipped": "Unique-Equipped", "stats": [{"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 21, "is_negated": true, "display": {"display_string": "+21 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}], "spells": [{"spell": {"key": {"href": "https://eu.api.blizzard.com/data/wow/spell/467250?namespace=static-12.0.1_65617-eu"}, "name": "Mister Pick-Me-Up", "id": 467250}, "description": "Equip: Your healing spells and abilities have a chance to summon Mister Pick-Me-Up for 6 sec, firing a healing beam every 2 sec that jumps between 5 injured allies to restore 352 health each.\\r\\n\\r\\nOverhealing from this effect irradiates allies to deal Nature damage to nearby enemies over 1.5 sec, increased by additional overhealing."}], "sell_price": {"value": 453237, "display_strings": {"header": "Sell Price:", "gold": "45", "silver": "32", "copper": "37"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 105, "display_string": "Item Level 105"}, "is_subclass_hidden": true, "name_description": {"display_string": "Heroic", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/199921?namespace=static-12.0.1_65617-eu"}, "id": 199921}, "enchantments": [{"display_string": "Enchanted: Chant of Leeching Fangs |A:Professions-ChatIcon-Quality-Tier3:20:20|a", "enchantment_id": 7409, "enchantment_slot": {"id": 0, "type": "PERMANENT"}}], "slot": {"type": "BACK", "name": "Back"}, "quantity": 1, "context": 16, "bonus_list": [10390, 6652, 11964, 10383, 11989, 10051, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Trashmaster's Mantle", "modified_appearance_id": 182326, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/199921?namespace=static-12.0.1_65617-eu"}, "id": 199921}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/1?namespace=static-12.0.1_65617-eu"}, "name": "Cloth", "id": 1}, "inventory_type": {"type": "CLOAK", "name": "Back"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 12, "display": {"display_string": "12 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 12, "display": {"display_string": "+12 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 12, "is_negated": true, "display": {"display_string": "+12 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STRENGTH", "name": "Strength"}, "value": 12, "is_negated": true, "display": {"display_string": "+12 Strength", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 55, "display": {"display_string": "+55 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 25, "is_equip_bonus": true, "display": {"display_string": "+25 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "spells": [{"spell": {"key": {"href": "https://eu.api.blizzard.com/data/wow/spell/300134?namespace=static-12.0.1_65617-eu"}, "name": "Trashmaster", "id": 300134}, "description": "Equip: Don the mantle of the Trashmaster."}], "sell_price": {"value": 388478, "display_strings": {"header": "Sell Price:", "gold": "38", "silver": "84", "copper": "78"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 104, "display_string": "Item Level 104"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/210381?namespace=static-12.0.1_65617-eu"}, "name": "Crystalline Tender's Shroud", "id": 210381}, "display_string": "Transmogrified to:\\nCrystalline Tender's Shroud", "item_modified_appearance_id": 192997}, "is_subclass_hidden": true, "name_description": {"display_string": "Mythic+", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/222444?namespace=static-12.0.1_65617-eu"}, "id": 222444}, "enchantments": [{"display_string": "Enchanted: Authority of Radiant Power |A:Professions-ChatIcon-Quality-Tier3:20:20|a", "enchantment_id": 7463, "enchantment_slot": {"id": 0, "type": "PERMANENT"}}], "slot": {"type": "MAIN_HAND", "name": "Main Hand"}, "quantity": 1, "context": 13, "bonus_list": [10421, 9633, 8902, 9627, 8792, 12040, 12043], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Charged Hexsword", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/222444?namespace=static-12.0.1_65617-eu"}, "id": 222444}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/2?namespace=static-12.0.1_65617-eu"}, "name": "Weapon", "id": 2}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/2/item-subclass/7?namespace=static-12.0.1_65617-eu"}, "name": "Sword", "id": 7}, "inventory_type": {"type": "WEAPON", "name": "One-Hand"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "weapon": {"damage": {"min_value": 13, "max_value": 23, "display_string": "13 - 23 Damage", "damage_class": {"type": "PHYSICAL", "name": "Physical"}}, "attack_speed": {"value": 2600, "display_string": "Speed 2.60"}, "dps": {"value": 6.9230766, "display_string": "(6.9 damage per second)"}}, "stats": [{"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 72, "is_negated": true, "display": {"display_string": "+72 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 76, "display": {"display_string": "+76 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 12, "is_equip_bonus": true, "display": {"display_string": "+12 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 12, "is_equip_bonus": true, "display": {"display_string": "+12 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1445393, "display_strings": {"header": "Sell Price:", "gold": "144", "silver": "53", "copper": "93"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 117, "display_string": "Item Level 117"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/222444?namespace=static-12.0.1_65617-eu"}, "name": "Charged Hexsword", "id": 222444}, "display_string": "Transmogrified to:\\nCharged Hexsword", "item_modified_appearance_id": 219537}, "durability": {"value": 109, "display_string": "Durability 109 / 110"}, "name_description": {"display_string": "Fortune Crafted", "color": {"r": 25, "g": 255, "b": 25, "a": 1.0}}, "modified_crafting_stat": [{"id": 32, "type": "CRIT_RATING", "name": "Critical Strike"}, {"id": 49, "type": "MASTERY_RATING", "name": "Mastery"}]}], "equipped_item_sets": [{"item_set": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-set/1873?namespace=static-12.0.1_65617-eu"}, "name": "Ageless Serpent's Foresight", "id": 1873}, "items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/229301?namespace=static-12.0.1_65617-eu"}, "name": "Ageless Serpent's Inked Coils", "id": 229301}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/229299?namespace=static-12.0.1_65617-eu"}, "name": "Ageless Serpent's Handguards", "id": 229299}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/229298?namespace=static-12.0.1_65617-eu"}, "name": "Ageless Serpent's Mane", "id": 229298}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/229297?namespace=static-12.0.1_65617-eu"}, "name": "Ageless Serpent's Leggings", "id": 229297}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/229296?namespace=static-12.0.1_65617-eu"}, "name": "Ageless Serpent's Shoulderpads", "id": 229296}, "is_equipped": true}], "effects": [{"display_string": "Set: Each time you take damage you have a chance to activate Luck of the Draw! causing you to cast Fortifying Brew for 6.0 sec. Your damage done is increased by 15% for 8 sec after Luck of the Draw! activates.", "required_count": 2, "is_active": true}, {"display_string": "(4) Set: When you gain  Luck of the Draw!, your next 2 casts of Blackout Kick deal 250% increased damage and incur a 2.0 sec reduced cooldown.", "required_count": 4}], "display_string": "Ageless Serpent's Foresight (2/5)"}]}	2026-02-21 23:42:42.221081+00	2026-02-21 23:27:00.041222+00	1	\N	https://render.worldofwarcraft.com/eu/character/ravencrest/111/173536623-avatar.jpg	1	2026-02-21 23:42:47.695006+00	{"head": {"ilvl": 103, "track": "Adventurer", "item_name": "Waterworks Filtration Mask", "item_id": 234498, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 234498}, "neck": {"ilvl": 103, "track": "Adventurer", "item_name": "Flickering Glowtorc", "item_id": 221103, "quality": "EPIC", "sockets": 2, "enchanted": false, "icon_id": 221103}, "shoulder": {"ilvl": 103, "track": "Adventurer", "item_name": "Ageless Serpent's Shoulderpads", "item_id": 229296, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 229296}, "back": {"ilvl": 104, "track": "Adventurer", "item_name": "Trashmaster's Mantle", "item_id": 199921, "quality": "EPIC", "sockets": 0, "enchanted": true, "icon_id": 199921}, "chest": {"ilvl": 121, "track": "Adventurer", "item_name": "Ascension Arrestor's Doublet", "item_id": 246637, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 246637}, "wrist": {"ilvl": 121, "track": "Adventurer", "item_name": "Ascension Arrestor's Bindings", "item_id": 246644, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 246644}, "hands": {"ilvl": 121, "track": "Adventurer", "item_name": "Ascension Arrestor's Gloves", "item_id": 246639, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 246639}, "waist": {"ilvl": 121, "track": "Adventurer", "item_name": "Ascension Arrestor's Clasp", "item_id": 246643, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 246643}, "legs": {"ilvl": 103, "track": "Adventurer", "item_name": "Ageless Serpent's Leggings", "item_id": 229297, "quality": "EPIC", "sockets": 0, "enchanted": true, "icon_id": 229297}, "feet": {"ilvl": 121, "track": "Adventurer", "item_name": "Ascension Arrestor's Shoes", "item_id": 246638, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 246638}, "ring1": {"ilvl": 111, "track": "Adventurer", "item_name": "Faded Championship Ring", "item_id": 228840, "quality": "EPIC", "sockets": 0, "enchanted": true, "icon_id": 228840}, "ring2": {"ilvl": 121, "track": "Adventurer", "item_name": "Ascension Arrestor's Band", "item_id": 246677, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 246677}, "trinket1": {"ilvl": 118, "track": "Adventurer", "item_name": "Signet of the Priory", "item_id": 219308, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 219308}, "trinket2": {"ilvl": 105, "track": "Adventurer", "item_name": "Mister Pick-Me-Up", "item_id": 230186, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 230186}, "main_hand": {"ilvl": 117, "track": "Adventurer", "item_name": "Charged Hexsword", "item_id": 222444, "quality": "EPIC", "sockets": 0, "enchanted": true, "icon_id": 222444}, "off_hand": {"ilvl": 0, "track": "Adventurer", "item_name": "", "item_id": 0, "quality": "COMMON", "sockets": 0, "enchanted": false, "icon_id": 0}}	\N	0	{"manaforge-omega": {"summary": "", "expansion_id": 10, "total_bosses": 8, "normal_bosses_killed": 0, "heroic_bosses_killed": 0, "mythic_bosses_killed": 0}, "liberation-of-undermine": {"summary": "2/8 M", "expansion_id": 10, "total_bosses": 8, "normal_bosses_killed": 8, "heroic_bosses_killed": 8, "mythic_bosses_killed": 2}, "blackrock-depths": {"summary": "", "expansion_id": 10, "total_bosses": 8, "normal_bosses_killed": 0, "heroic_bosses_killed": 0, "mythic_bosses_killed": 0}, "nerubar-palace": {"summary": "7/8 H", "expansion_id": 10, "total_bosses": 8, "normal_bosses_killed": 7, "heroic_bosses_killed": 7, "mythic_bosses_killed": 0}}	2026-02-21 23:27:01.108192+00
8	Chrobro	Ravencrest	\N	Druid	Guardian	Tank	169.6	{"_links": {"self": {"href": "https://eu.api.blizzard.com/profile/wow/character/ravencrest/chrobro/equipment?namespace=profile-eu"}}, "character": {"key": {"href": "https://eu.api.blizzard.com/profile/wow/character/ravencrest/chrobro?namespace=profile-eu"}, "name": "Chrobro", "id": 117918841, "realm": {"key": {"href": "https://eu.api.blizzard.com/data/wow/realm/554?namespace=dynamic-eu"}, "name": "Ravencrest", "id": 554, "slug": "ravencrest"}}, "equipped_items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237682?namespace=static-12.0.1_65617-eu"}, "id": 237682}, "sockets": [{"socket_type": {"type": "PRISMATIC", "name": "Prismatic Socket"}, "item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/213467?namespace=static-12.0.1_65617-eu"}, "name": "Deadly Sapphire", "id": 213467}, "display_string": "+10 Versatility and +3 Critical Strike", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/213467?namespace=static-12.0.1_65617-eu"}, "id": 213467}}], "slot": {"type": "HEAD", "name": "Head"}, "quantity": 1, "context": 6, "bonus_list": [10356, 12231, 6652, 12676, 12365, 13446, 1540, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Skymane of the Mother Eagle", "modified_appearance_id": 286441, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237682?namespace=static-12.0.1_65617-eu"}, "id": 237682}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/2?namespace=static-12.0.1_65617-eu"}, "name": "Leather", "id": 2}, "inventory_type": {"type": "HEAD", "name": "Head"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 44, "display": {"display_string": "44 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 41, "display": {"display_string": "+41 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 41, "is_negated": true, "display": {"display_string": "+41 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 499, "display": {"display_string": "+499 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 50, "is_equip_bonus": true, "display": {"display_string": "+50 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 20, "is_equip_bonus": true, "display": {"display_string": "+20 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 396312, "display_strings": {"header": "Sell Price:", "gold": "39", "silver": "63", "copper": "12"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/11?namespace=static-12.0.1_65617-eu"}, "name": "Druid", "id": 11}], "display_string": "Classes: Druid"}}, "set": {"item_set": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-set/1921?namespace=static-12.0.1_65617-eu"}, "name": "Ornaments of the Mother Eagle", "id": 1921}, "items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237685?namespace=static-12.0.1_65617-eu"}, "name": "Vest of the Mother Eagle", "id": 237685}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237683?namespace=static-12.0.1_65617-eu"}, "name": "Wings of the Mother Eagle", "id": 237683}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237682?namespace=static-12.0.1_65617-eu"}, "name": "Skymane of the Mother Eagle", "id": 237682}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237681?namespace=static-12.0.1_65617-eu"}, "name": "Breeches of the Mother Eagle", "id": 237681}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237680?namespace=static-12.0.1_65617-eu"}, "name": "Ritual Pauldrons of the Mother Eagle", "id": 237680}, "is_equipped": true}], "effects": [{"display_string": "Set: Damage done increased by 6%.", "required_count": 2, "is_active": true}, {"display_string": "Set: Damage done increased by 10%.\\r\\n", "required_count": 4, "is_active": true}], "display_string": "Ornaments of the Mother Eagle (5/5)"}, "level": {"value": 170, "display_string": "Item Level 170"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/147136?namespace=static-12.0.1_65617-eu"}, "name": "Stormheart Headdress", "id": 147136}, "display_string": "Transmogrified to:\\nStormheart Headdress", "item_modified_appearance_id": 86165}, "durability": {"value": 80, "display_string": "Durability 80 / 100"}, "name_description": {"display_string": "Mythic", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237568?namespace=static-12.0.1_65617-eu"}, "id": 237568}, "sockets": [{"socket_type": {"type": "PRISMATIC", "name": "Prismatic Socket"}, "item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/213743?namespace=static-12.0.1_65617-eu"}, "name": "Culminating Blasphemite", "id": 213743}, "display_string": "+12 Primary Stat and +0.15% Critical Effect per unique Algari gem color", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/213743?namespace=static-12.0.1_65617-eu"}, "id": 213743}}, {"socket_type": {"type": "PRISMATIC", "name": "Prismatic Socket"}, "item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/213470?namespace=static-12.0.1_65617-eu"}, "name": "Quick Sapphire", "id": 213470}, "display_string": "+10 Versatility and +3 Haste", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/213470?namespace=static-12.0.1_65617-eu"}, "id": 213470}}], "slot": {"type": "NECK", "name": "Neck"}, "quantity": 1, "context": 6, "bonus_list": [41, 10356, 10879, 10396, 13446, 1540, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Chrysalis of Sundered Souls", "modified_appearance_id": 0, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237568?namespace=static-12.0.1_65617-eu"}, "id": 237568}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "NECK", "name": "Neck"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "stats": [{"type": {"type": "STAMINA", "name": "Stamina"}, "value": 281, "display": {"display_string": "+281 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 29, "is_equip_bonus": true, "display": {"display_string": "+29 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 120, "is_equip_bonus": true, "display": {"display_string": "+120 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "COMBAT_RATING_LIFESTEAL", "name": "Leech"}, "value": 26, "is_equip_bonus": true, "display": {"display_string": "+26 Leech", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 226019, "display_strings": {"header": "Sell Price:", "gold": "22", "silver": "60", "copper": "19"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 170, "display_string": "Item Level 170"}, "is_subclass_hidden": true, "name_description": {"display_string": "Mythic", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237680?namespace=static-12.0.1_65617-eu"}, "id": 237680}, "slot": {"type": "SHOULDER", "name": "Shoulders"}, "quantity": 1, "context": 6, "bonus_list": [6652, 13446, 10356, 12233, 12675, 1540], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Ritual Pauldrons of the Mother Eagle", "modified_appearance_id": 286417, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237680?namespace=static-12.0.1_65617-eu"}, "id": 237680}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/2?namespace=static-12.0.1_65617-eu"}, "name": "Leather", "id": 2}, "inventory_type": {"type": "SHOULDER", "name": "Shoulder"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 40, "display": {"display_string": "40 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 31, "display": {"display_string": "+31 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 31, "is_negated": true, "display": {"display_string": "+31 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 374, "display": {"display_string": "+374 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 37, "is_equip_bonus": true, "display": {"display_string": "+37 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 16, "is_equip_bonus": true, "display": {"display_string": "+16 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 434713, "display_strings": {"header": "Sell Price:", "gold": "43", "silver": "47", "copper": "13"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/11?namespace=static-12.0.1_65617-eu"}, "name": "Druid", "id": 11}], "display_string": "Classes: Druid"}}, "set": {"item_set": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-set/1921?namespace=static-12.0.1_65617-eu"}, "name": "Ornaments of the Mother Eagle", "id": 1921}, "items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237685?namespace=static-12.0.1_65617-eu"}, "name": "Vest of the Mother Eagle", "id": 237685}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237683?namespace=static-12.0.1_65617-eu"}, "name": "Wings of the Mother Eagle", "id": 237683}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237682?namespace=static-12.0.1_65617-eu"}, "name": "Skymane of the Mother Eagle", "id": 237682}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237681?namespace=static-12.0.1_65617-eu"}, "name": "Breeches of the Mother Eagle", "id": 237681}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237680?namespace=static-12.0.1_65617-eu"}, "name": "Ritual Pauldrons of the Mother Eagle", "id": 237680}, "is_equipped": true}], "effects": [{"display_string": "Set: Damage done increased by 6%.", "required_count": 2, "is_active": true}, {"display_string": "Set: Damage done increased by 10%.\\r\\n", "required_count": 4, "is_active": true}], "display_string": "Ornaments of the Mother Eagle (5/5)"}, "level": {"value": 170, "display_string": "Item Level 170"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/208874?namespace=static-12.0.1_65617-eu"}, "name": "Kaldorei Protector's Mantle", "id": 208874}, "display_string": "Transmogrified to:\\nKaldorei Protector's Mantle\\nKaldorei Protector's Mantle", "item_modified_appearance_id": 190152, "second_item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/208874?namespace=static-12.0.1_65617-eu"}, "name": "Kaldorei Protector's Mantle", "id": 208874}, "second_item_modified_appearance_id": 190152}, "durability": {"value": 79, "display_string": "Durability 79 / 100"}, "name_description": {"display_string": "Mythic", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237685?namespace=static-12.0.1_65617-eu"}, "id": 237685}, "enchantments": [{"display_string": "Enchanted: Crystalline Radiance |A:Professions-ChatIcon-Quality-Tier3:20:20|a", "enchantment_id": 7364, "enchantment_slot": {"id": 0, "type": "PERMANENT"}}], "slot": {"type": "CHEST", "name": "Chest"}, "quantity": 1, "context": 35, "bonus_list": [12229, 10390, 6652, 12676, 13446, 1540, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Vest of the Mother Eagle", "modified_appearance_id": 286477, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237685?namespace=static-12.0.1_65617-eu"}, "id": 237685}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/2?namespace=static-12.0.1_65617-eu"}, "name": "Leather", "id": 2}, "inventory_type": {"type": "CHEST", "name": "Chest"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 58, "display": {"display_string": "58 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 41, "display": {"display_string": "+41 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 41, "is_negated": true, "display": {"display_string": "+41 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 499, "display": {"display_string": "+499 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 23, "is_equip_bonus": true, "display": {"display_string": "+23 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 47, "is_equip_bonus": true, "display": {"display_string": "+47 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 550177, "display_strings": {"header": "Sell Price:", "gold": "55", "silver": "1", "copper": "77"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/11?namespace=static-12.0.1_65617-eu"}, "name": "Druid", "id": 11}], "display_string": "Classes: Druid"}}, "set": {"item_set": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-set/1921?namespace=static-12.0.1_65617-eu"}, "name": "Ornaments of the Mother Eagle", "id": 1921}, "items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237685?namespace=static-12.0.1_65617-eu"}, "name": "Vest of the Mother Eagle", "id": 237685}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237683?namespace=static-12.0.1_65617-eu"}, "name": "Wings of the Mother Eagle", "id": 237683}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237682?namespace=static-12.0.1_65617-eu"}, "name": "Skymane of the Mother Eagle", "id": 237682}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237681?namespace=static-12.0.1_65617-eu"}, "name": "Breeches of the Mother Eagle", "id": 237681}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237680?namespace=static-12.0.1_65617-eu"}, "name": "Ritual Pauldrons of the Mother Eagle", "id": 237680}, "is_equipped": true}], "effects": [{"display_string": "Set: Damage done increased by 6%.", "required_count": 2, "is_active": true}, {"display_string": "Set: Damage done increased by 10%.\\r\\n", "required_count": 4, "is_active": true}], "display_string": "Ornaments of the Mother Eagle (5/5)"}, "level": {"value": 170, "display_string": "Item Level 170"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237973?namespace=static-12.0.1_65617-eu"}, "name": "Void-Scarred Blade's Jerkin", "id": 237973}, "display_string": "Transmogrified to:\\nVoid-Scarred Blade's Jerkin", "item_modified_appearance_id": 287221}, "durability": {"value": 127, "display_string": "Durability 127 / 165"}, "name_description": {"display_string": "Mythic+", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/219331?namespace=static-12.0.1_65617-eu"}, "id": 219331}, "sockets": [{"socket_type": {"type": "PRISMATIC", "name": "Prismatic Socket"}, "item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/213482?namespace=static-12.0.1_65617-eu"}, "name": "Masterful Emerald", "id": 213482}, "display_string": "+10 Haste and +3 Mastery", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/213482?namespace=static-12.0.1_65617-eu"}, "id": 213482}}], "slot": {"type": "WAIST", "name": "Waist"}, "quantity": 1, "context": 13, "bonus_list": [10421, 9633, 8902, 9627, 12053, 11304, 8960, 8793, 12050, 12922, 13468], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Rune-Branded Waistband", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/219331?namespace=static-12.0.1_65617-eu"}, "id": 219331}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/2?namespace=static-12.0.1_65617-eu"}, "name": "Leather", "id": 2}, "inventory_type": {"type": "WAIST", "name": "Waist"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "limit_category": "Unique-Equipped: Embellished (2)", "armor": {"value": 31, "display": {"display_string": "31 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 30, "display": {"display_string": "+30 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 30, "is_negated": true, "display": {"display_string": "+30 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 357, "display": {"display_string": "+357 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 26, "is_equip_bonus": true, "display": {"display_string": "+26 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 26, "is_equip_bonus": true, "display": {"display_string": "+26 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "spells": [{"spell": {"key": {"href": "https://eu.api.blizzard.com/data/wow/spell/457677?namespace=static-12.0.1_65617-eu"}, "name": "Duskthread Lining", "id": 457677}, "description": "Equip: Your gear cools with Woven Duskthread and gains 6 Versatility when over 80% health."}], "sell_price": {"value": 492388, "display_strings": {"header": "Sell Price:", "gold": "49", "silver": "23", "copper": "88"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 167, "display_string": "Item Level 167"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/218059?namespace=static-12.0.1_65617-eu"}, "name": "Dalaran Defender's Buckle", "id": 218059}, "display_string": "Transmogrified to:\\nDalaran Defender's Buckle", "item_modified_appearance_id": 200627}, "durability": {"value": 45, "display_string": "Durability 45 / 55"}, "name_description": {"display_string": "Starlight Crafted", "color": {"r": 25, "g": 255, "b": 25, "a": 1.0}}, "modified_crafting_stat": [{"id": 32, "type": "CRIT_RATING", "name": "Critical Strike"}, {"id": 49, "type": "MASTERY_RATING", "name": "Mastery"}]}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237681?namespace=static-12.0.1_65617-eu"}, "id": 237681}, "enchantments": [{"display_string": "Enchanted: +8 Agility/Strength & +10 Armor |A:Professions-ChatIcon-Quality-Tier3:20:20|a", "source_item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/219908?namespace=static-12.0.1_65617-eu"}, "name": "Defender's Armor Kit", "id": 219908}, "enchantment_id": 7595, "enchantment_slot": {"id": 0, "type": "PERMANENT"}}], "slot": {"type": "LEGS", "name": "Legs"}, "quantity": 1, "context": 35, "bonus_list": [40, 10390, 12232, 12676, 13446, 1540, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Breeches of the Mother Eagle", "modified_appearance_id": 286429, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237681?namespace=static-12.0.1_65617-eu"}, "id": 237681}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/2?namespace=static-12.0.1_65617-eu"}, "name": "Leather", "id": 2}, "inventory_type": {"type": "LEGS", "name": "Legs"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 51, "display": {"display_string": "51 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 41, "display": {"display_string": "+41 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 41, "is_negated": true, "display": {"display_string": "+41 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 499, "display": {"display_string": "+499 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 47, "is_equip_bonus": true, "display": {"display_string": "+47 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 24, "is_equip_bonus": true, "display": {"display_string": "+24 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "COMBAT_RATING_AVOIDANCE", "name": "Avoidance"}, "value": 30, "is_equip_bonus": true, "display": {"display_string": "+30 Avoidance", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 527377, "display_strings": {"header": "Sell Price:", "gold": "52", "silver": "73", "copper": "77"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/11?namespace=static-12.0.1_65617-eu"}, "name": "Druid", "id": 11}], "display_string": "Classes: Druid"}}, "set": {"item_set": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-set/1921?namespace=static-12.0.1_65617-eu"}, "name": "Ornaments of the Mother Eagle", "id": 1921}, "items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237685?namespace=static-12.0.1_65617-eu"}, "name": "Vest of the Mother Eagle", "id": 237685}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237683?namespace=static-12.0.1_65617-eu"}, "name": "Wings of the Mother Eagle", "id": 237683}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237682?namespace=static-12.0.1_65617-eu"}, "name": "Skymane of the Mother Eagle", "id": 237682}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237681?namespace=static-12.0.1_65617-eu"}, "name": "Breeches of the Mother Eagle", "id": 237681}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237680?namespace=static-12.0.1_65617-eu"}, "name": "Ritual Pauldrons of the Mother Eagle", "id": 237680}, "is_equipped": true}], "effects": [{"display_string": "Set: Damage done increased by 6%.", "required_count": 2, "is_active": true}, {"display_string": "Set: Damage done increased by 10%.\\r\\n", "required_count": 4, "is_active": true}], "display_string": "Ornaments of the Mother Eagle (5/5)"}, "level": {"value": 170, "display_string": "Item Level 170"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/116206?namespace=static-12.0.1_65617-eu"}, "name": "Warmage's Legwraps", "id": 116206}, "display_string": "Transmogrified to:\\nWarmage's Legwraps", "item_modified_appearance_id": 66896}, "durability": {"value": 95, "display_string": "Durability 95 / 120"}, "name_description": {"display_string": "Mythic+", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237553?namespace=static-12.0.1_65617-eu"}, "id": 237553}, "enchantments": [{"display_string": "Enchanted: Defender's March |A:Professions-ChatIcon-Quality-Tier3:20:20|a", "enchantment_id": 7424, "enchantment_slot": {"id": 0, "type": "PERMANENT"}}], "slot": {"type": "FEET", "name": "Feet"}, "quantity": 1, "context": 6, "bonus_list": [6652, 12239, 10356, 13446, 1540, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Laboratory Test Slippers", "modified_appearance_id": 285460, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237553?namespace=static-12.0.1_65617-eu"}, "id": 237553}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/2?namespace=static-12.0.1_65617-eu"}, "name": "Leather", "id": 2}, "inventory_type": {"type": "FEET", "name": "Feet"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 36, "display": {"display_string": "36 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 31, "display": {"display_string": "+31 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 31, "is_negated": true, "display": {"display_string": "+31 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 374, "display": {"display_string": "+374 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 16, "is_equip_bonus": true, "display": {"display_string": "+16 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 37, "is_equip_bonus": true, "display": {"display_string": "+37 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 402443, "display_strings": {"header": "Sell Price:", "gold": "40", "silver": "24", "copper": "43"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 170, "display_string": "Item Level 170"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/218787?namespace=static-12.0.1_65617-eu"}, "name": "Toiler's Beige Footwraps", "id": 218787}, "display_string": "Transmogrified to:\\nToiler's Beige Footwraps", "item_modified_appearance_id": 217968}, "durability": {"value": 62, "display_string": "Durability 62 / 80"}, "name_description": {"display_string": "Mythic", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/219334?namespace=static-12.0.1_65617-eu"}, "id": 219334}, "enchantments": [{"display_string": "Enchanted: +72 Avoidance |A:Professions-ChatIcon-Quality-Tier3:20:20|a", "enchantment_id": 7385, "enchantment_slot": {"id": 0, "type": "PERMANENT"}}], "sockets": [{"socket_type": {"type": "PRISMATIC", "name": "Prismatic Socket"}, "item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/213470?namespace=static-12.0.1_65617-eu"}, "name": "Quick Sapphire", "id": 213470}, "display_string": "+10 Versatility and +3 Haste", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/213470?namespace=static-12.0.1_65617-eu"}, "id": 213470}}], "slot": {"type": "WRIST", "name": "Wrist"}, "quantity": 1, "context": 13, "bonus_list": [10421, 9633, 8902, 9627, 12053, 11304, 8960, 8793, 12050, 12922, 13468], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Rune-Branded Armbands", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/219334?namespace=static-12.0.1_65617-eu"}, "id": 219334}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/2?namespace=static-12.0.1_65617-eu"}, "name": "Leather", "id": 2}, "inventory_type": {"type": "WRIST", "name": "Wrist"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "limit_category": "Unique-Equipped: Embellished (2)", "armor": {"value": 27, "display": {"display_string": "27 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 22, "display": {"display_string": "+22 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 22, "is_negated": true, "display": {"display_string": "+22 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 267, "display": {"display_string": "+267 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 20, "is_equip_bonus": true, "display": {"display_string": "+20 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 20, "is_equip_bonus": true, "display": {"display_string": "+20 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "spells": [{"spell": {"key": {"href": "https://eu.api.blizzard.com/data/wow/spell/457677?namespace=static-12.0.1_65617-eu"}, "name": "Duskthread Lining", "id": 457677}, "description": "Equip: Your gear cools with Woven Duskthread and gains 6 Versatility when over 80% health."}], "sell_price": {"value": 497818, "display_strings": {"header": "Sell Price:", "gold": "49", "silver": "78", "copper": "18"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 167, "display_string": "Item Level 167"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/168665?namespace=static-12.0.1_65617-eu"}, "name": "Hidden Bracers", "id": 168665}, "display_string": "Transmogrified to:\\nHidden Bracers", "item_modified_appearance_id": 104604}, "durability": {"value": 44, "display_string": "Durability 44 / 55"}, "name_description": {"display_string": "Starlight Crafted", "color": {"r": 25, "g": 255, "b": 25, "a": 1.0}}, "modified_crafting_stat": [{"id": 40, "type": "VERSATILITY", "name": "Versatility"}, {"id": 49, "type": "MASTERY_RATING", "name": "Mastery"}]}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237683?namespace=static-12.0.1_65617-eu"}, "id": 237683}, "slot": {"type": "HANDS", "name": "Hands"}, "quantity": 1, "context": 6, "bonus_list": [10356, 12230, 6652, 12675, 13446, 1540, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Wings of the Mother Eagle", "modified_appearance_id": 286453, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237683?namespace=static-12.0.1_65617-eu"}, "id": 237683}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/2?namespace=static-12.0.1_65617-eu"}, "name": "Leather", "id": 2}, "inventory_type": {"type": "HAND", "name": "Hands"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 33, "display": {"display_string": "33 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 31, "display": {"display_string": "+31 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 31, "is_negated": true, "display": {"display_string": "+31 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 374, "display": {"display_string": "+374 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 16, "is_equip_bonus": true, "display": {"display_string": "+16 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 37, "is_equip_bonus": true, "display": {"display_string": "+37 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 267227, "display_strings": {"header": "Sell Price:", "gold": "26", "silver": "72", "copper": "27"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/11?namespace=static-12.0.1_65617-eu"}, "name": "Druid", "id": 11}], "display_string": "Classes: Druid"}}, "set": {"item_set": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-set/1921?namespace=static-12.0.1_65617-eu"}, "name": "Ornaments of the Mother Eagle", "id": 1921}, "items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237685?namespace=static-12.0.1_65617-eu"}, "name": "Vest of the Mother Eagle", "id": 237685}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237683?namespace=static-12.0.1_65617-eu"}, "name": "Wings of the Mother Eagle", "id": 237683}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237682?namespace=static-12.0.1_65617-eu"}, "name": "Skymane of the Mother Eagle", "id": 237682}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237681?namespace=static-12.0.1_65617-eu"}, "name": "Breeches of the Mother Eagle", "id": 237681}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237680?namespace=static-12.0.1_65617-eu"}, "name": "Ritual Pauldrons of the Mother Eagle", "id": 237680}, "is_equipped": true}], "effects": [{"display_string": "Set: Damage done increased by 6%.", "required_count": 2, "is_active": true}, {"display_string": "Set: Damage done increased by 10%.\\r\\n", "required_count": 4, "is_active": true}], "display_string": "Ornaments of the Mother Eagle (5/5)"}, "level": {"value": 170, "display_string": "Item Level 170"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/212057?namespace=static-12.0.1_65617-eu"}, "name": "Eviscerators of the Greatlynx", "id": 212057}, "display_string": "Transmogrified to:\\nEviscerators of the Greatlynx", "item_modified_appearance_id": 222107}, "durability": {"value": 45, "display_string": "Durability 45 / 55"}, "name_description": {"display_string": "Mythic", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/221136?namespace=static-12.0.1_65617-eu"}, "id": 221136}, "enchantments": [{"display_string": "Enchanted: +21 Mastery |A:Professions-ChatIcon-Quality-Tier3:20:20|a", "enchantment_id": 7346, "enchantment_slot": {"id": 0, "type": "PERMANENT"}}], "sockets": [{"socket_type": {"type": "PRISMATIC", "name": "Prismatic Socket"}, "item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/213494?namespace=static-12.0.1_65617-eu"}, "name": "Quick Onyx", "id": 213494}, "display_string": "+10 Mastery and +3 Haste", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/213494?namespace=static-12.0.1_65617-eu"}, "id": 213494}}, {"socket_type": {"type": "PRISMATIC", "name": "Prismatic Socket"}, "item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/213485?namespace=static-12.0.1_65617-eu"}, "name": "Versatile Emerald", "id": 213485}, "display_string": "+10 Haste and +3 Versatility", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/213485?namespace=static-12.0.1_65617-eu"}, "id": 213485}}], "slot": {"type": "FINGER_1", "name": "Ring 1"}, "quantity": 1, "context": 35, "bonus_list": [10390, 6652, 10383, 10879, 10396, 13446, 3222, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Devout Zealot's Ring", "modified_appearance_id": 0, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/221136?namespace=static-12.0.1_65617-eu"}, "id": 221136}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "FINGER", "name": "Finger"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "unique_equipped": "Unique-Equipped", "stats": [{"type": {"type": "STAMINA", "name": "Stamina"}, "value": 281, "display": {"display_string": "+281 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 102, "is_equip_bonus": true, "display": {"display_string": "+102 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 47, "is_equip_bonus": true, "display": {"display_string": "+47 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 346243, "display_strings": {"header": "Sell Price:", "gold": "34", "silver": "62", "copper": "43"}}, "requirements": {"level": {"value": 68, "display_string": "Requires Level 68"}}, "level": {"value": 170, "display_string": "Item Level 170"}, "is_subclass_hidden": true, "name_description": {"display_string": "Mythic+", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237567?namespace=static-12.0.1_65617-eu"}, "id": 237567}, "enchantments": [{"display_string": "Enchanted: +21 Mastery |A:Professions-ChatIcon-Quality-Tier3:20:20|a", "enchantment_id": 7346, "enchantment_slot": {"id": 0, "type": "PERMANENT"}}], "sockets": [{"socket_type": {"type": "PRISMATIC", "name": "Prismatic Socket"}, "item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/213473?namespace=static-12.0.1_65617-eu"}, "name": "Masterful Sapphire", "id": 213473}, "display_string": "+10 Versatility and +3 Mastery", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/213473?namespace=static-12.0.1_65617-eu"}, "id": 213473}}, {"socket_type": {"type": "PRISMATIC", "name": "Prismatic Socket"}, "item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/213461?namespace=static-12.0.1_65617-eu"}, "name": "Versatile Ruby", "id": 213461}, "display_string": "+10 Critical Strike and +3 Versatility", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/213461?namespace=static-12.0.1_65617-eu"}, "id": 213461}}], "slot": {"type": "FINGER_2", "name": "Ring 2"}, "quantity": 1, "context": 6, "bonus_list": [6652, 10356, 10879, 10396, 13446, 1540, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Logic Gate: Alpha", "modified_appearance_id": 0, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237567?namespace=static-12.0.1_65617-eu"}, "id": 237567}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "FINGER", "name": "Finger"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "unique_equipped": "Unique-Equipped", "stats": [{"type": {"type": "STAMINA", "name": "Stamina"}, "value": 281, "display": {"display_string": "+281 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 122, "is_equip_bonus": true, "display": {"display_string": "+122 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 27, "is_equip_bonus": true, "display": {"display_string": "+27 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 365026, "display_strings": {"header": "Sell Price:", "gold": "36", "silver": "50", "copper": "26"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 170, "display_string": "Item Level 170"}, "is_subclass_hidden": true, "name_description": {"display_string": "Mythic", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/242401?namespace=static-12.0.1_65617-eu"}, "id": 242401}, "slot": {"type": "TRINKET_1", "name": "Trinket 1"}, "quantity": 1, "context": 6, "bonus_list": [6652, 10356, 13446, 1540, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Brand of Ceaseless Ire", "modified_appearance_id": 0, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/242401?namespace=static-12.0.1_65617-eu"}, "id": 242401}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "TRINKET", "name": "Trinket"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "unique_equipped": "Unique-Equipped", "stats": [{"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 50, "is_equip_bonus": true, "display": {"display_string": "+50 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "spells": [{"spell": {"key": {"href": "https://eu.api.blizzard.com/data/wow/spell/1235225?namespace=static-12.0.1_65617-eu"}, "name": "Brand of Ceaseless Ire", "id": 1235225}, "description": "Equip: Taking damage infuriates you, causing you to absorb 677 damage and deal 1,548 Shadow damage per infuriation split between nearby enemies. Damage increased by 30% per additional enemy, up to 150%.\\r\\n\\r\\nYou may be further infuriated every 15 sec, stacking up to 15 times, but calm quickly upon leaving combat. \\r\\n\\r\\n"}], "sell_price": {"value": 454172, "display_strings": {"header": "Sell Price:", "gold": "45", "silver": "41", "copper": "72"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 170, "display_string": "Item Level 170"}, "is_subclass_hidden": true, "name_description": {"display_string": "Mythic", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/219314?namespace=static-12.0.1_65617-eu"}, "id": 219314}, "slot": {"type": "TRINKET_2", "name": "Trinket 2"}, "quantity": 1, "context": 35, "bonus_list": [10390, 41, 10383, 13446, 3222, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Ara-Kara Sacbrood", "modified_appearance_id": 0, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/219314?namespace=static-12.0.1_65617-eu"}, "id": 219314}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "TRINKET", "name": "Trinket"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "unique_equipped": "Unique-Equipped", "stats": [{"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 50, "is_equip_bonus": true, "display": {"display_string": "+50 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "COMBAT_RATING_LIFESTEAL", "name": "Leech"}, "value": 23, "is_equip_bonus": true, "display": {"display_string": "+23 Leech", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "spells": [{"spell": {"key": {"href": "https://eu.api.blizzard.com/data/wow/spell/443541?namespace=static-12.0.1_65617-eu"}, "name": "Ara-Kara Sacbrood", "id": 443541}, "description": "Equip: Your abilities have a chance to stir the sac, releasing an egg which grants you 15 Agility. Each egg hatches after 1 min, and the new brood attacks your next target, inflicting 1,882 Nature damage over 8 sec."}], "sell_price": {"value": 482680, "display_strings": {"header": "Sell Price:", "gold": "48", "silver": "26", "copper": "80"}}, "requirements": {"level": {"value": 68, "display_string": "Requires Level 68"}}, "level": {"value": 170, "display_string": "Item Level 170"}, "is_subclass_hidden": true, "name_description": {"display_string": "Mythic+", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/235499?namespace=static-12.0.1_65617-eu"}, "id": 235499}, "enchantments": [{"display_string": "Enchanted: Chant of Winged Grace |A:Professions-ChatIcon-Quality-Tier3:20:20|a", "enchantment_id": 7403, "enchantment_slot": {"id": 0, "type": "PERMANENT"}}], "sockets": [{"socket_type": {"type": "FIBER", "name": "Fiber Socket"}, "item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/238045?namespace=static-12.0.1_65617-eu"}, "name": "Pure Chronomantic Fiber", "id": 238045}, "context": 13, "display_string": "Pure Chronomantic Fiber", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/238045?namespace=static-12.0.1_65617-eu"}, "id": 238045}}], "slot": {"type": "BACK", "name": "Back"}, "quantity": 1, "context": 11, "bonus_list": [12401, 9893, 12258], "quality": {"type": "ARTIFACT", "name": "Artifact"}, "name": "Reshii Wraps", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/235499?namespace=static-12.0.1_65617-eu"}, "id": 235499}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/1?namespace=static-12.0.1_65617-eu"}, "name": "Cloth", "id": 1}, "inventory_type": {"type": "CLOAK", "name": "Back"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 23, "display": {"display_string": "23 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 23, "display": {"display_string": "+23 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "STRENGTH", "name": "Strength"}, "value": 23, "is_negated": true, "display": {"display_string": "+23 Strength", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 23, "is_negated": true, "display": {"display_string": "+23 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 281, "display": {"display_string": "+281 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 91, "is_equip_bonus": true, "display": {"display_string": "+91 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "spells": [{"spell": {"key": {"href": "https://eu.api.blizzard.com/data/wow/spell/1217091?namespace=static-12.0.1_65617-eu"}, "name": "Ethereal Energy", "id": 1217091}, "description": "Equip: The wraps attune to your specialization granting you Ethereal Protection:\\r\\n\\r\\nYour spells and abilities have a high chance to coalesce the energy around you, granting you a shield that reduces damage taken by 20% up to 18,125 total damage.\\r\\n\\r\\nUpon falling below 40% health, gain this effect at  500% effectiveness. This effect may only occur once every 6 min.", "display_color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}], "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 170, "display_string": "Item Level 170"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/250104?namespace=static-12.0.1_65617-eu"}, "name": "Soulbinder's Nethermantle", "id": 250104}, "display_string": "Transmogrified to:\\nSoulbinder's Nethermantle", "item_modified_appearance_id": 297790}, "is_subclass_hidden": true, "name_description": {"display_string": "Rank 6", "color": {"r": 0, "g": 255, "b": 255, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237739?namespace=static-12.0.1_65617-eu"}, "id": 237739}, "enchantments": [{"display_string": "Enchanted: Stonebound Artistry |A:Professions-ChatIcon-Quality-Tier3:20:20|a", "enchantment_id": 7445, "enchantment_slot": {"id": 0, "type": "PERMANENT"}}], "slot": {"type": "MAIN_HAND", "name": "Main Hand"}, "quantity": 1, "context": 6, "bonus_list": [40, 10356, 13446, 1540, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Obliteration Beamglaive", "modified_appearance_id": 293132, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237739?namespace=static-12.0.1_65617-eu"}, "id": 237739}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/2?namespace=static-12.0.1_65617-eu"}, "name": "Weapon", "id": 2}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/2/item-subclass/6?namespace=static-12.0.1_65617-eu"}, "name": "Polearm", "id": 6}, "inventory_type": {"type": "TWOHWEAPON", "name": "Two-Hand"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "weapon": {"damage": {"min_value": 77, "max_value": 144, "display_string": "77 - 144 Damage", "damage_class": {"type": "PHYSICAL", "name": "Physical"}}, "attack_speed": {"value": 3600, "display_string": "Speed 3.60"}, "dps": {"value": 30.694443, "display_string": "(30.7 damage per second)"}}, "stats": [{"type": {"type": "AGILITY", "name": "Agility"}, "value": 41, "display": {"display_string": "+41 Agility", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 499, "display": {"display_string": "+499 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 21, "is_equip_bonus": true, "display": {"display_string": "+21 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 50, "is_equip_bonus": true, "display": {"display_string": "+50 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "COMBAT_RATING_AVOIDANCE", "name": "Avoidance"}, "value": 30, "is_equip_bonus": true, "display": {"display_string": "+30 Avoidance", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 960324, "display_strings": {"header": "Sell Price:", "gold": "96", "silver": "3", "copper": "24"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 170, "display_string": "Item Level 170"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237739?namespace=static-12.0.1_65617-eu"}, "name": "Obliteration Beamglaive", "id": 237739}, "display_string": "Transmogrified to:\\nObliteration Beamglaive", "item_modified_appearance_id": 293132}, "durability": {"value": 92, "display_string": "Durability 92 / 120"}, "name_description": {"display_string": "Mythic", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/233289?namespace=static-12.0.1_65617-eu"}, "id": 233289}, "slot": {"type": "TABARD", "name": "Tabard"}, "quantity": 1, "context": 11, "quality": {"type": "RARE", "name": "Rare"}, "name": "Radiant Stalwart's Tabard", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/233289?namespace=static-12.0.1_65617-eu"}, "id": 233289}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "TABARD", "name": "Tabard"}, "binding": {"type": "TO_ACCOUNT", "name": "Binds to Warband"}, "sell_price": {"value": 100000, "display_strings": {"header": "Sell Price:", "gold": "10", "silver": "0", "copper": "0"}}, "level": {"value": 1, "display_string": "Item Level 1"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/218346?namespace=static-12.0.1_65617-eu"}, "name": "Honorary Councilmember's Tabard", "id": 218346}, "display_string": "Transmogrified to:\\nHonorary Councilmember's Tabard", "item_modified_appearance_id": 216822}, "is_subclass_hidden": true}], "equipped_item_sets": [{"item_set": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-set/1921?namespace=static-12.0.1_65617-eu"}, "name": "Ornaments of the Mother Eagle", "id": 1921}, "items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237685?namespace=static-12.0.1_65617-eu"}, "name": "Vest of the Mother Eagle", "id": 237685}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237683?namespace=static-12.0.1_65617-eu"}, "name": "Wings of the Mother Eagle", "id": 237683}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237682?namespace=static-12.0.1_65617-eu"}, "name": "Skymane of the Mother Eagle", "id": 237682}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237681?namespace=static-12.0.1_65617-eu"}, "name": "Breeches of the Mother Eagle", "id": 237681}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237680?namespace=static-12.0.1_65617-eu"}, "name": "Ritual Pauldrons of the Mother Eagle", "id": 237680}, "is_equipped": true}], "effects": [{"display_string": "Set: Damage done increased by 6%.", "required_count": 2, "is_active": true}, {"display_string": "Set: Damage done increased by 10%.\\r\\n", "required_count": 4, "is_active": true}], "display_string": "Ornaments of the Mother Eagle (5/5)"}]}	2026-02-21 23:42:42.221081+00	2026-02-21 16:22:10.570494+00	1	80	https://render.worldofwarcraft.com/eu/character/ravencrest/121/117918841-avatar.jpg	2	2026-02-21 23:42:45.0083+00	{"head": {"ilvl": 170, "track": "Adventurer", "item_name": "Skymane of the Mother Eagle", "item_id": 237682, "quality": "EPIC", "sockets": 1, "enchanted": false, "icon_id": 237682}, "neck": {"ilvl": 170, "track": "Adventurer", "item_name": "Chrysalis of Sundered Souls", "item_id": 237568, "quality": "EPIC", "sockets": 2, "enchanted": false, "icon_id": 237568}, "shoulder": {"ilvl": 170, "track": "Adventurer", "item_name": "Ritual Pauldrons of the Mother Eagle", "item_id": 237680, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 237680}, "back": {"ilvl": 170, "track": "Adventurer", "item_name": "Reshii Wraps", "item_id": 235499, "quality": "ARTIFACT", "sockets": 1, "enchanted": true, "icon_id": 235499}, "chest": {"ilvl": 170, "track": "Adventurer", "item_name": "Vest of the Mother Eagle", "item_id": 237685, "quality": "EPIC", "sockets": 0, "enchanted": true, "icon_id": 237685}, "wrist": {"ilvl": 167, "track": "Adventurer", "item_name": "Rune-Branded Armbands", "item_id": 219334, "quality": "EPIC", "sockets": 1, "enchanted": true, "icon_id": 219334}, "hands": {"ilvl": 170, "track": "Adventurer", "item_name": "Wings of the Mother Eagle", "item_id": 237683, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 237683}, "waist": {"ilvl": 167, "track": "Adventurer", "item_name": "Rune-Branded Waistband", "item_id": 219331, "quality": "EPIC", "sockets": 1, "enchanted": false, "icon_id": 219331}, "legs": {"ilvl": 170, "track": "Adventurer", "item_name": "Breeches of the Mother Eagle", "item_id": 237681, "quality": "EPIC", "sockets": 0, "enchanted": true, "icon_id": 237681}, "feet": {"ilvl": 170, "track": "Adventurer", "item_name": "Laboratory Test Slippers", "item_id": 237553, "quality": "EPIC", "sockets": 0, "enchanted": true, "icon_id": 237553}, "ring1": {"ilvl": 170, "track": "Adventurer", "item_name": "Devout Zealot's Ring", "item_id": 221136, "quality": "EPIC", "sockets": 2, "enchanted": true, "icon_id": 221136}, "ring2": {"ilvl": 170, "track": "Adventurer", "item_name": "Logic Gate: Alpha", "item_id": 237567, "quality": "EPIC", "sockets": 2, "enchanted": true, "icon_id": 237567}, "trinket1": {"ilvl": 170, "track": "Adventurer", "item_name": "Brand of Ceaseless Ire", "item_id": 242401, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 242401}, "trinket2": {"ilvl": 170, "track": "Adventurer", "item_name": "Ara-Kara Sacbrood", "item_id": 219314, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 219314}, "main_hand": {"ilvl": 170, "track": "Adventurer", "item_name": "Obliteration Beamglaive", "item_id": 237739, "quality": "EPIC", "sockets": 0, "enchanted": true, "icon_id": 237739}, "off_hand": {"ilvl": 170, "track": "Adventurer", "item_name": "(2H: Obliteration Beamglaive)", "item_id": 237739, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 0}}	{"strength": 66, "agility": 562, "intellect": 159, "stamina": 7916, "crit_rating": 0, "crit_rating_pct": 41.647186, "haste_rating": 0, "haste_rating_pct": 33.413666, "mastery_rating": 0, "mastery_rating_pct": 23.390371, "versatility": 195.0, "versatility_pct": 13.662406, "armor": 374}	3165.5	{"manaforge-omega": {"summary": "7/8 M", "expansion_id": 10, "total_bosses": 8, "normal_bosses_killed": 8, "heroic_bosses_killed": 8, "mythic_bosses_killed": 7}, "liberation-of-undermine": {"summary": "", "expansion_id": 10, "total_bosses": 8, "normal_bosses_killed": 0, "heroic_bosses_killed": 0, "mythic_bosses_killed": 0}, "blackrock-depths": {"summary": "", "expansion_id": 10, "total_bosses": 8, "normal_bosses_killed": 0, "heroic_bosses_killed": 0, "mythic_bosses_killed": 0}, "nerubar-palace": {"summary": "6/8 H", "expansion_id": 10, "total_bosses": 8, "normal_bosses_killed": 0, "heroic_bosses_killed": 6, "mythic_bosses_killed": 0}}	2026-02-21 22:50:04.899396+00
11	Chiro	Ravencrest	\N	Warrior	Protection	Tank	154.4	{"_links": {"self": {"href": "https://eu.api.blizzard.com/profile/wow/character/ravencrest/chiro/equipment?namespace=profile-eu"}}, "character": {"key": {"href": "https://eu.api.blizzard.com/profile/wow/character/ravencrest/chiro?namespace=profile-eu"}, "name": "Chiro", "id": 175543654, "realm": {"key": {"href": "https://eu.api.blizzard.com/data/wow/realm/554?namespace=dynamic-eu"}, "name": "Ravencrest", "id": 554, "slug": "ravencrest"}}, "equipped_items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237610?namespace=static-12.0.1_65617-eu"}, "id": 237610}, "slot": {"type": "HEAD", "name": "Head"}, "quantity": 1, "context": 108, "bonus_list": [12231, 6652, 12921, 12676, 12353, 1514, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Living Weapon's Faceshield", "modified_appearance_id": 285584, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237610?namespace=static-12.0.1_65617-eu"}, "id": 237610}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/4?namespace=static-12.0.1_65617-eu"}, "name": "Plate", "id": 4}, "inventory_type": {"type": "HEAD", "name": "Head"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 63, "display": {"display_string": "63 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 32, "display": {"display_string": "+32 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 32, "is_negated": true, "display": {"display_string": "+32 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 304, "display": {"display_string": "+304 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 42, "is_equip_bonus": true, "display": {"display_string": "+42 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 18, "is_equip_bonus": true, "display": {"display_string": "+18 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 399769, "display_strings": {"header": "Sell Price:", "gold": "39", "silver": "97", "copper": "69"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/1?namespace=static-12.0.1_65617-eu"}, "name": "Warrior", "id": 1}], "display_string": "Classes: Warrior"}}, "set": {"item_set": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-set/1931?namespace=static-12.0.1_65617-eu"}, "name": "Chains of the Living Weapon", "id": 1931}, "items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237613?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Bulwark", "id": 237613}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237611?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Crushers", "id": 237611}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237610?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Faceshield", "id": 237610}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237609?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Legguards", "id": 237609}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237608?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Ramparts", "id": 237608}, "is_equipped": true}], "effects": [{"display_string": "Set: Damage done increased by 6%.", "required_count": 2, "is_active": true}, {"display_string": "Set: Damage done increased by 10%.\\r\\n", "required_count": 4, "is_active": true}], "display_string": "Chains of the Living Weapon (4/5)"}, "level": {"value": 144, "display_string": "Item Level 144"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237610?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Faceshield", "id": 237610}, "display_string": "Transmogrified to:\\nLiving Weapon's Faceshield", "item_modified_appearance_id": 285584}, "durability": {"value": 100, "display_string": "Durability 100 / 100"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237568?namespace=static-12.0.1_65617-eu"}, "id": 237568}, "sockets": [{"socket_type": {"type": "PRISMATIC", "name": "Prismatic Socket"}, "item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/213743?namespace=static-12.0.1_65617-eu"}, "name": "Culminating Blasphemite", "id": 213743}, "display_string": "+12 Primary Stat and +0.15% Critical Effect per unique Algari gem color", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/213743?namespace=static-12.0.1_65617-eu"}, "id": 213743}}, {"socket_type": {"type": "PRISMATIC", "name": "Prismatic Socket"}, "item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/213485?namespace=static-12.0.1_65617-eu"}, "name": "Versatile Emerald", "id": 213485}, "display_string": "+10 Haste and +3 Versatility", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/213485?namespace=static-12.0.1_65617-eu"}, "id": 213485}}], "slot": {"type": "NECK", "name": "Neck"}, "quantity": 1, "context": 5, "bonus_list": [6652, 10355, 10879, 10396, 12353, 1514, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Chrysalis of Sundered Souls", "modified_appearance_id": 0, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237568?namespace=static-12.0.1_65617-eu"}, "id": 237568}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "NECK", "name": "Neck"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "stats": [{"type": {"type": "STAMINA", "name": "Stamina"}, "value": 171, "display": {"display_string": "+171 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 23, "is_equip_bonus": true, "display": {"display_string": "+23 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 97, "is_equip_bonus": true, "display": {"display_string": "+97 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 221080, "display_strings": {"header": "Sell Price:", "gold": "22", "silver": "10", "copper": "80"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 144, "display_string": "Item Level 144"}, "is_subclass_hidden": true, "name_description": {"display_string": "Heroic", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237608?namespace=static-12.0.1_65617-eu"}, "id": 237608}, "slot": {"type": "SHOULDER", "name": "Shoulders"}, "quantity": 1, "context": 110, "bonus_list": [6652, 12233, 12675, 12353, 1514, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Living Weapon's Ramparts", "modified_appearance_id": 285560, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237608?namespace=static-12.0.1_65617-eu"}, "id": 237608}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/4?namespace=static-12.0.1_65617-eu"}, "name": "Plate", "id": 4}, "inventory_type": {"type": "SHOULDER", "name": "Shoulder"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 58, "display": {"display_string": "58 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 24, "display": {"display_string": "+24 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 24, "is_negated": true, "display": {"display_string": "+24 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 228, "display": {"display_string": "+228 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 31, "is_equip_bonus": true, "display": {"display_string": "+31 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 14, "is_equip_bonus": true, "display": {"display_string": "+14 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 396770, "display_strings": {"header": "Sell Price:", "gold": "39", "silver": "67", "copper": "70"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/1?namespace=static-12.0.1_65617-eu"}, "name": "Warrior", "id": 1}], "display_string": "Classes: Warrior"}}, "set": {"item_set": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-set/1931?namespace=static-12.0.1_65617-eu"}, "name": "Chains of the Living Weapon", "id": 1931}, "items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237613?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Bulwark", "id": 237613}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237611?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Crushers", "id": 237611}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237610?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Faceshield", "id": 237610}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237609?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Legguards", "id": 237609}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237608?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Ramparts", "id": 237608}, "is_equipped": true}], "effects": [{"display_string": "Set: Damage done increased by 6%.", "required_count": 2, "is_active": true}, {"display_string": "Set: Damage done increased by 10%.\\r\\n", "required_count": 4, "is_active": true}], "display_string": "Chains of the Living Weapon (4/5)"}, "level": {"value": 144, "display_string": "Item Level 144"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237608?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Ramparts", "id": 237608}, "display_string": "Transmogrified to:\\nLiving Weapon's Ramparts\\nLiving Weapon's Ramparts", "item_modified_appearance_id": 285560, "second_item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237608?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Ramparts", "id": 237608}, "second_item_modified_appearance_id": 285560}, "durability": {"value": 100, "display_string": "Durability 100 / 100"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237613?namespace=static-12.0.1_65617-eu"}, "id": 237613}, "slot": {"type": "CHEST", "name": "Chest"}, "quantity": 1, "context": 109, "bonus_list": [6652, 12229, 12676, 12297, 1514, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Living Weapon's Bulwark", "modified_appearance_id": 285620, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237613?namespace=static-12.0.1_65617-eu"}, "id": 237613}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/4?namespace=static-12.0.1_65617-eu"}, "name": "Plate", "id": 4}, "inventory_type": {"type": "CHEST", "name": "Chest"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 84, "display": {"display_string": "84 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 32, "display": {"display_string": "+32 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 32, "is_negated": true, "display": {"display_string": "+32 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 304, "display": {"display_string": "+304 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 18, "is_equip_bonus": true, "display": {"display_string": "+18 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 42, "is_equip_bonus": true, "display": {"display_string": "+42 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 539996, "display_strings": {"header": "Sell Price:", "gold": "53", "silver": "99", "copper": "96"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/1?namespace=static-12.0.1_65617-eu"}, "name": "Warrior", "id": 1}], "display_string": "Classes: Warrior"}}, "set": {"item_set": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-set/1931?namespace=static-12.0.1_65617-eu"}, "name": "Chains of the Living Weapon", "id": 1931}, "items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237613?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Bulwark", "id": 237613}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237611?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Crushers", "id": 237611}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237610?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Faceshield", "id": 237610}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237609?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Legguards", "id": 237609}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237608?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Ramparts", "id": 237608}, "is_equipped": true}], "effects": [{"display_string": "Set: Damage done increased by 6%.", "required_count": 2, "is_active": true}, {"display_string": "Set: Damage done increased by 10%.\\r\\n", "required_count": 4, "is_active": true}], "display_string": "Chains of the Living Weapon (4/5)"}, "level": {"value": 144, "display_string": "Item Level 144"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237613?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Bulwark", "id": 237613}, "display_string": "Transmogrified to:\\nLiving Weapon's Bulwark", "item_modified_appearance_id": 285620}, "durability": {"value": 165, "display_string": "Durability 165 / 165"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/222431?namespace=static-12.0.1_65617-eu"}, "id": 222431}, "slot": {"type": "WAIST", "name": "Waist"}, "quantity": 1, "context": 13, "bonus_list": [10421, 9633, 8902, 9627, 8792, 12050, 12053, 12921, 13468], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Everforged Greatbelt", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/222431?namespace=static-12.0.1_65617-eu"}, "id": 222431}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/4?namespace=static-12.0.1_65617-eu"}, "name": "Plate", "id": 4}, "inventory_type": {"type": "WAIST", "name": "Waist"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 69, "display": {"display_string": "69 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 30, "display": {"display_string": "+30 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 30, "is_negated": true, "display": {"display_string": "+30 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 357, "display": {"display_string": "+357 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 26, "is_equip_bonus": true, "display": {"display_string": "+26 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 26, "is_equip_bonus": true, "display": {"display_string": "+26 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 485391, "display_strings": {"header": "Sell Price:", "gold": "48", "silver": "53", "copper": "91"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 167, "display_string": "Item Level 167"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/222431?namespace=static-12.0.1_65617-eu"}, "name": "Everforged Greatbelt", "id": 222431}, "display_string": "Transmogrified to:\\nEverforged Greatbelt", "item_modified_appearance_id": 219524}, "durability": {"value": 55, "display_string": "Durability 55 / 55"}, "name_description": {"display_string": "Starlight Crafted", "color": {"r": 25, "g": 255, "b": 25, "a": 1.0}}, "modified_crafting_stat": [{"id": 40, "type": "VERSATILITY", "name": "Versatility"}, {"id": 49, "type": "MASTERY_RATING", "name": "Mastery"}]}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/222434?namespace=static-12.0.1_65617-eu"}, "id": 222434}, "enchantments": [{"display_string": "Enchanted: +8 Agility/Strength & +8 Stamina |A:Professions-ChatIcon-Quality-Tier3:20:20|a", "source_item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/219911?namespace=static-12.0.1_65617-eu"}, "name": "Stormbound Armor Kit", "id": 219911}, "enchantment_id": 7601, "enchantment_slot": {"id": 0, "type": "PERMANENT"}}], "slot": {"type": "LEGS", "name": "Legs"}, "quantity": 1, "context": 13, "bonus_list": [10421, 9633, 8902, 9627, 8792, 12050, 12053, 11304, 8960, 13468], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Everforged Legplates", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/222434?namespace=static-12.0.1_65617-eu"}, "id": 222434}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/4?namespace=static-12.0.1_65617-eu"}, "name": "Plate", "id": 4}, "inventory_type": {"type": "LEGS", "name": "Legs"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "limit_category": "Unique-Equipped: Embellished (2)", "armor": {"value": 107, "display": {"display_string": "107 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 40, "display": {"display_string": "+40 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 40, "is_negated": true, "display": {"display_string": "+40 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 475, "display": {"display_string": "+475 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 35, "is_equip_bonus": true, "display": {"display_string": "+35 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 35, "is_equip_bonus": true, "display": {"display_string": "+35 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "spells": [{"spell": {"key": {"href": "https://eu.api.blizzard.com/data/wow/spell/457677?namespace=static-12.0.1_65617-eu"}, "name": "Duskthread Lining", "id": 457677}, "description": "Equip: Your gear cools with Woven Duskthread and gains 6 Versatility when over 80% health."}], "sell_price": {"value": 975969, "display_strings": {"header": "Sell Price:", "gold": "97", "silver": "59", "copper": "69"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 167, "display_string": "Item Level 167"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/222434?namespace=static-12.0.1_65617-eu"}, "name": "Everforged Legplates", "id": 222434}, "display_string": "Transmogrified to:\\nEverforged Legplates", "item_modified_appearance_id": 219527}, "durability": {"value": 120, "display_string": "Durability 120 / 120"}, "name_description": {"display_string": "Starlight Crafted", "color": {"r": 25, "g": 255, "b": 25, "a": 1.0}}, "modified_crafting_stat": [{"id": 49, "type": "MASTERY_RATING", "name": "Mastery"}, {"id": 32, "type": "CRIT_RATING", "name": "Critical Strike"}]}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/222429?namespace=static-12.0.1_65617-eu"}, "id": 222429}, "enchantments": [{"display_string": "Enchanted: Defender's March |A:Professions-ChatIcon-Quality-Tier3:20:20|a", "enchantment_id": 7424, "enchantment_slot": {"id": 0, "type": "PERMANENT"}}], "slot": {"type": "FEET", "name": "Feet"}, "quantity": 1, "context": 13, "bonus_list": [10421, 9633, 8902, 9627, 8792, 12050, 12053, 13468], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Everforged Sabatons", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/222429?namespace=static-12.0.1_65617-eu"}, "id": 222429}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/4?namespace=static-12.0.1_65617-eu"}, "name": "Plate", "id": 4}, "inventory_type": {"type": "FEET", "name": "Feet"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 76, "display": {"display_string": "76 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 30, "display": {"display_string": "+30 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 30, "is_negated": true, "display": {"display_string": "+30 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 357, "display": {"display_string": "+357 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 26, "is_equip_bonus": true, "display": {"display_string": "+26 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 26, "is_equip_bonus": true, "display": {"display_string": "+26 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 697954, "display_strings": {"header": "Sell Price:", "gold": "69", "silver": "79", "copper": "54"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 167, "display_string": "Item Level 167"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/222429?namespace=static-12.0.1_65617-eu"}, "name": "Everforged Sabatons", "id": 222429}, "display_string": "Transmogrified to:\\nEverforged Sabatons", "item_modified_appearance_id": 219522}, "durability": {"value": 79, "display_string": "Durability 79 / 80"}, "name_description": {"display_string": "Starlight Crafted", "color": {"r": 25, "g": 255, "b": 25, "a": 1.0}}, "modified_crafting_stat": [{"id": 40, "type": "VERSATILITY", "name": "Versatility"}, {"id": 36, "type": "HASTE_RATING", "name": "Haste"}]}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/222435?namespace=static-12.0.1_65617-eu"}, "id": 222435}, "enchantments": [{"display_string": "Enchanted: +72 Avoidance |A:Professions-ChatIcon-Quality-Tier3:20:20|a", "enchantment_id": 7385, "enchantment_slot": {"id": 0, "type": "PERMANENT"}}], "slot": {"type": "WRIST", "name": "Wrist"}, "quantity": 1, "context": 13, "bonus_list": [10421, 9633, 8902, 9627, 8792, 12050, 12053, 11304, 8960, 12921, 13468], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Everforged Vambraces", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/222435?namespace=static-12.0.1_65617-eu"}, "id": 222435}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/4?namespace=static-12.0.1_65617-eu"}, "name": "Plate", "id": 4}, "inventory_type": {"type": "WRIST", "name": "Wrist"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "limit_category": "Unique-Equipped: Embellished (2)", "armor": {"value": 61, "display": {"display_string": "61 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 22, "display": {"display_string": "+22 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 22, "is_negated": true, "display": {"display_string": "+22 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 267, "display": {"display_string": "+267 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 20, "is_equip_bonus": true, "display": {"display_string": "+20 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 20, "is_equip_bonus": true, "display": {"display_string": "+20 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "spells": [{"spell": {"key": {"href": "https://eu.api.blizzard.com/data/wow/spell/457677?namespace=static-12.0.1_65617-eu"}, "name": "Duskthread Lining", "id": 457677}, "description": "Equip: Your gear cools with Woven Duskthread and gains 6 Versatility when over 80% health."}], "sell_price": {"value": 492583, "display_strings": {"header": "Sell Price:", "gold": "49", "silver": "25", "copper": "83"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 167, "display_string": "Item Level 167"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/222435?namespace=static-12.0.1_65617-eu"}, "name": "Everforged Vambraces", "id": 222435}, "display_string": "Transmogrified to:\\nEverforged Vambraces", "item_modified_appearance_id": 219528}, "durability": {"value": 55, "display_string": "Durability 55 / 55"}, "name_description": {"display_string": "Starlight Crafted", "color": {"r": 25, "g": 255, "b": 25, "a": 1.0}}, "modified_crafting_stat": [{"id": 36, "type": "HASTE_RATING", "name": "Haste"}, {"id": 49, "type": "MASTERY_RATING", "name": "Mastery"}]}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237611?namespace=static-12.0.1_65617-eu"}, "id": 237611}, "slot": {"type": "HANDS", "name": "Hands"}, "quantity": 1, "context": 110, "bonus_list": [6652, 12230, 12675, 12353, 1514, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Living Weapon's Crushers", "modified_appearance_id": 285596, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237611?namespace=static-12.0.1_65617-eu"}, "id": 237611}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/4?namespace=static-12.0.1_65617-eu"}, "name": "Plate", "id": 4}, "inventory_type": {"type": "HAND", "name": "Hands"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 47, "display": {"display_string": "47 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 24, "display": {"display_string": "+24 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 24, "is_negated": true, "display": {"display_string": "+24 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 228, "display": {"display_string": "+228 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "CRIT_RATING", "name": "Critical Strike"}, "value": 15, "is_equip_bonus": true, "display": {"display_string": "+15 Critical Strike", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 30, "is_equip_bonus": true, "display": {"display_string": "+30 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 269554, "display_strings": {"header": "Sell Price:", "gold": "26", "silver": "95", "copper": "54"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}, "playable_classes": {"links": [{"key": {"href": "https://eu.api.blizzard.com/data/wow/playable-class/1?namespace=static-12.0.1_65617-eu"}, "name": "Warrior", "id": 1}], "display_string": "Classes: Warrior"}}, "set": {"item_set": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-set/1931?namespace=static-12.0.1_65617-eu"}, "name": "Chains of the Living Weapon", "id": 1931}, "items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237613?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Bulwark", "id": 237613}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237611?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Crushers", "id": 237611}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237610?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Faceshield", "id": 237610}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237609?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Legguards", "id": 237609}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237608?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Ramparts", "id": 237608}, "is_equipped": true}], "effects": [{"display_string": "Set: Damage done increased by 6%.", "required_count": 2, "is_active": true}, {"display_string": "Set: Damage done increased by 10%.\\r\\n", "required_count": 4, "is_active": true}], "display_string": "Chains of the Living Weapon (4/5)"}, "level": {"value": 144, "display_string": "Item Level 144"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237611?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Crushers", "id": 237611}, "display_string": "Transmogrified to:\\nLiving Weapon's Crushers", "item_modified_appearance_id": 285596}, "durability": {"value": 54, "display_string": "Durability 54 / 55"}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/243046?namespace=static-12.0.1_65617-eu"}, "id": 243046}, "enchantments": [{"display_string": "Enchanted: +21 Critical Strike |A:Professions-ChatIcon-Quality-Tier3:20:20|a", "enchantment_id": 7334, "enchantment_slot": {"id": 0, "type": "PERMANENT"}}], "sockets": [{"socket_type": {"type": "PRISMATIC", "name": "Prismatic Socket"}, "item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/213497?namespace=static-12.0.1_65617-eu"}, "name": "Versatile Onyx", "id": 213497}, "display_string": "+10 Mastery and +3 Versatility", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/213497?namespace=static-12.0.1_65617-eu"}, "id": 213497}}, {"socket_type": {"type": "PRISMATIC", "name": "Prismatic Socket"}, "item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/213461?namespace=static-12.0.1_65617-eu"}, "name": "Versatile Ruby", "id": 213461}, "display_string": "+10 Critical Strike and +3 Versatility", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/213461?namespace=static-12.0.1_65617-eu"}, "id": 213461}}], "slot": {"type": "FINGER_1", "name": "Ring 1"}, "quantity": 1, "context": 81, "bonus_list": [6652, 10354, 10879, 10396, 12297, 1514, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Band of Boundless Hunger", "modified_appearance_id": 0, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/243046?namespace=static-12.0.1_65617-eu"}, "id": 243046}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "FINGER", "name": "Finger"}, "binding": {"type": "TO_ACCOUNT", "name": "Binds to Warband"}, "unique_equipped": "Unique-Equipped", "stats": [{"type": {"type": "STAMINA", "name": "Stamina"}, "value": 171, "display": {"display_string": "+171 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 89, "is_equip_bonus": true, "display": {"display_string": "+89 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 31, "is_equip_bonus": true, "display": {"display_string": "+31 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 334629, "display_strings": {"header": "Sell Price:", "gold": "33", "silver": "46", "copper": "29"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 144, "display_string": "Item Level 144"}, "is_subclass_hidden": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237956?namespace=static-12.0.1_65617-eu"}, "id": 237956}, "enchantments": [{"display_string": "Enchanted: +21 Critical Strike |A:Professions-ChatIcon-Quality-Tier3:20:20|a", "enchantment_id": 7334, "enchantment_slot": {"id": 0, "type": "PERMANENT"}}], "sockets": [{"socket_type": {"type": "PRISMATIC", "name": "Prismatic Socket"}, "item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/213497?namespace=static-12.0.1_65617-eu"}, "name": "Versatile Onyx", "id": 213497}, "display_string": "+10 Mastery and +3 Versatility", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/213497?namespace=static-12.0.1_65617-eu"}, "id": 213497}}, {"socket_type": {"type": "PRISMATIC", "name": "Prismatic Socket"}, "item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/213461?namespace=static-12.0.1_65617-eu"}, "name": "Versatile Ruby", "id": 213461}, "display_string": "+10 Critical Strike and +3 Versatility", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/213461?namespace=static-12.0.1_65617-eu"}, "id": 213461}}], "slot": {"type": "FINGER_2", "name": "Ring 2"}, "quantity": 1, "context": 109, "bonus_list": [6652, 10879, 10396, 12297, 9925, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Void-Scarred Band", "modified_appearance_id": 0, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/237956?namespace=static-12.0.1_65617-eu"}, "id": 237956}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "FINGER", "name": "Finger"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "unique_equipped": "Unique-Equipped", "stats": [{"type": {"type": "STAMINA", "name": "Stamina"}, "value": 171, "display": {"display_string": "+171 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 38, "is_equip_bonus": true, "display": {"display_string": "+38 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 82, "is_equip_bonus": true, "display": {"display_string": "+82 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 344428, "display_strings": {"header": "Sell Price:", "gold": "34", "silver": "44", "copper": "28"}}, "requirements": {"level": {"value": 70, "display_string": "Requires Level 70"}}, "level": {"value": 144, "display_string": "Item Level 144"}, "is_subclass_hidden": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/246824?namespace=static-12.0.1_65617-eu"}, "id": 246824}, "slot": {"type": "TRINKET_1", "name": "Trinket 1"}, "quantity": 1, "context": 138, "bonus_list": [6652, 12353, 1566, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Shadowguard's Twisted Harvester", "modified_appearance_id": 0, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/246824?namespace=static-12.0.1_65617-eu"}, "id": 246824}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "TRINKET", "name": "Trinket"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "unique_equipped": "Unique-Equipped", "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 31, "display": {"display_string": "+31 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "AGILITY", "name": "Agility"}, "value": 31, "is_negated": true, "display": {"display_string": "+31 Agility", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 31, "is_negated": true, "display": {"display_string": "+31 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}], "spells": [{"spell": {"key": {"href": "https://eu.api.blizzard.com/data/wow/spell/1244007?namespace=static-12.0.1_65617-eu"}, "name": "Shadowguard's Twisted Harvester", "id": 1244007}, "description": "Equip: Taking damage has a chance to siphon chaos energies from the Twisting Nether granting you 115  Leech for 10 sec. Dropping below 40% health will unleash the Harvester immediately granting you 347 Leech for 10 sec. Can only occur every 120 sec."}], "sell_price": {"value": 449677, "display_strings": {"header": "Sell Price:", "gold": "44", "silver": "96", "copper": "77"}}, "requirements": {"level": {"value": 68, "display_string": "Requires Level 68"}}, "level": {"value": 144, "display_string": "Item Level 144"}, "is_subclass_hidden": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/240213?namespace=static-12.0.1_65617-eu"}, "id": 240213}, "slot": {"type": "TRINKET_2", "name": "Trinket 2"}, "quantity": 1, "context": 138, "bonus_list": [6652, 12353, 3233, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Veiling Mana Shroud", "modified_appearance_id": 0, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/240213?namespace=static-12.0.1_65617-eu"}, "id": 240213}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "TRINKET", "name": "Trinket"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "unique_equipped": "Unique-Equipped", "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 31, "display": {"display_string": "+31 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "AGILITY", "name": "Agility"}, "value": 31, "is_negated": true, "display": {"display_string": "+31 Agility", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}], "spells": [{"spell": {"key": {"href": "https://eu.api.blizzard.com/data/wow/spell/1231217?namespace=static-12.0.1_65617-eu"}, "name": "Veiling Mana Shroud", "id": 1231217}, "description": "Equip: Taking damage has a chance for the shroud's enchantments to enhance your prowess, granting 115 Versatility for 12 sec.\\r\\n\\r\\n"}], "sell_price": {"value": 476866, "display_strings": {"header": "Sell Price:", "gold": "47", "silver": "68", "copper": "66"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 144, "display_string": "Item Level 144"}, "is_subclass_hidden": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/235499?namespace=static-12.0.1_65617-eu"}, "id": 235499}, "enchantments": [{"display_string": "Enchanted: Chant of Winged Grace |A:Professions-ChatIcon-Quality-Tier3:20:20|a", "enchantment_id": 7403, "enchantment_slot": {"id": 0, "type": "PERMANENT"}}], "sockets": [{"socket_type": {"type": "FIBER", "name": "Fiber Socket"}, "item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/238042?namespace=static-12.0.1_65617-eu"}, "name": "Pure Dexterous Fiber", "id": 238042}, "context": 13, "display_string": "Pure Dexterous Fiber", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/238042?namespace=static-12.0.1_65617-eu"}, "id": 238042}}], "slot": {"type": "BACK", "name": "Back"}, "quantity": 1, "context": 11, "bonus_list": [12401, 9893, 12259], "quality": {"type": "ARTIFACT", "name": "Artifact"}, "name": "Reshii Wraps", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/235499?namespace=static-12.0.1_65617-eu"}, "id": 235499}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/1?namespace=static-12.0.1_65617-eu"}, "name": "Cloth", "id": 1}, "inventory_type": {"type": "CLOAK", "name": "Back"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 23, "display": {"display_string": "23 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 23, "display": {"display_string": "+23 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "AGILITY", "name": "Agility"}, "value": 23, "is_negated": true, "display": {"display_string": "+23 Agility", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 23, "is_negated": true, "display": {"display_string": "+23 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 281, "display": {"display_string": "+281 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 91, "is_equip_bonus": true, "display": {"display_string": "+91 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "spells": [{"spell": {"key": {"href": "https://eu.api.blizzard.com/data/wow/spell/1217091?namespace=static-12.0.1_65617-eu"}, "name": "Ethereal Energy", "id": 1217091}, "description": "Equip: The wraps attune to your specialization granting you Ethereal Protection:\\r\\n\\r\\nYour spells and abilities have a high chance to coalesce the energy around you, granting you a shield that reduces damage taken by 20% up to 18,125 total damage.\\r\\n\\r\\nUpon falling below 40% health, gain this effect at  500% effectiveness. This effect may only occur once every 6 min.", "display_color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}], "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 170, "display_string": "Item Level 170"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/235499?namespace=static-12.0.1_65617-eu"}, "name": "Reshii Wraps", "id": 235499}, "display_string": "Transmogrified to:\\nReshii Wraps", "item_modified_appearance_id": 294870}, "is_subclass_hidden": true, "name_description": {"display_string": "Rank 6", "color": {"r": 0, "g": 255, "b": 255, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/222440?namespace=static-12.0.1_65617-eu"}, "id": 222440}, "enchantments": [{"display_string": "Enchanted: Council's Guile |A:Professions-ChatIcon-Quality-Tier3:20:20|a", "enchantment_id": 7439, "enchantment_slot": {"id": 0, "type": "PERMANENT"}}], "slot": {"type": "MAIN_HAND", "name": "Main Hand"}, "quantity": 1, "context": 13, "bonus_list": [10421, 9633, 8902, 9627, 8792, 12050, 12053, 13468], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Everforged Longsword", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/222440?namespace=static-12.0.1_65617-eu"}, "id": 222440}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/2?namespace=static-12.0.1_65617-eu"}, "name": "Weapon", "id": 2}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/2/item-subclass/7?namespace=static-12.0.1_65617-eu"}, "name": "Sword", "id": 7}, "inventory_type": {"type": "WEAPON", "name": "One-Hand"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "weapon": {"damage": {"min_value": 44, "max_value": 73, "display_string": "44 - 73 Damage", "damage_class": {"type": "PHYSICAL", "name": "Physical"}}, "attack_speed": {"value": 2600, "display_string": "Speed 2.60"}, "dps": {"value": 22.499998, "display_string": "(22.5 damage per second)"}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 20, "display": {"display_string": "+20 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "AGILITY", "name": "Agility"}, "value": 20, "is_negated": true, "display": {"display_string": "+20 Agility", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 238, "display": {"display_string": "+238 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "HASTE_RATING", "name": "Haste"}, "value": 17, "is_equip_bonus": true, "display": {"display_string": "+17 Haste", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 17, "is_equip_bonus": true, "display": {"display_string": "+17 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 1424961, "display_strings": {"header": "Sell Price:", "gold": "142", "silver": "49", "copper": "61"}}, "requirements": {"level": {"value": 80, "display_string": "Requires Level 80"}}, "level": {"value": 167, "display_string": "Item Level 167"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/222440?namespace=static-12.0.1_65617-eu"}, "name": "Everforged Longsword", "id": 222440}, "display_string": "Transmogrified to:\\nEverforged Longsword", "item_modified_appearance_id": 219533}, "durability": {"value": 109, "display_string": "Durability 109 / 110"}, "name_description": {"display_string": "Starlight Crafted", "color": {"r": 25, "g": 255, "b": 25, "a": 1.0}}, "modified_crafting_stat": [{"id": 32, "type": "CRIT_RATING", "name": "Critical Strike"}, {"id": 36, "type": "HASTE_RATING", "name": "Haste"}]}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/221117?namespace=static-12.0.1_65617-eu"}, "id": 221117}, "slot": {"type": "OFF_HAND", "name": "Off Hand"}, "quantity": 1, "context": 35, "bonus_list": [10390, 43, 10383, 13446, 3222, 10255], "quality": {"type": "EPIC", "name": "Epic"}, "name": "Sanctified Priory Wall", "modified_appearance_id": 219069, "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/221117?namespace=static-12.0.1_65617-eu"}, "id": 221117}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/6?namespace=static-12.0.1_65617-eu"}, "name": "Shield", "id": 6}, "inventory_type": {"type": "SHIELD", "name": "Off Hand"}, "binding": {"type": "ON_ACQUIRE", "name": "Binds when picked up"}, "armor": {"value": 379, "display": {"display_string": "379 Armor", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "shield_block": {"value": 947, "display": {"display_string": "947 Block", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, "stats": [{"type": {"type": "STRENGTH", "name": "Strength"}, "value": 20, "display": {"display_string": "+20 Strength", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "INTELLECT", "name": "Intellect"}, "value": 63, "is_negated": true, "display": {"display_string": "+63 Intellect", "color": {"r": 128, "g": 128, "b": 128, "a": 1.0}}}, {"type": {"type": "STAMINA", "name": "Stamina"}, "value": 249, "display": {"display_string": "+249 Stamina", "color": {"r": 255, "g": 255, "b": 255, "a": 1.0}}}, {"type": {"type": "VERSATILITY", "name": "Versatility"}, "value": 14, "is_equip_bonus": true, "display": {"display_string": "+14 Versatility", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "MASTERY_RATING", "name": "Mastery"}, "value": 21, "is_equip_bonus": true, "display": {"display_string": "+21 Mastery", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"type": {"type": "COMBAT_RATING_STURDINESS", "name": "Indestructible"}, "value": 15, "is_equip_bonus": true, "display": {"display_string": "Indestructible", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}], "sell_price": {"value": 505549, "display_strings": {"header": "Sell Price:", "gold": "50", "silver": "55", "copper": "49"}}, "requirements": {"level": {"value": 68, "display_string": "Requires Level 68"}}, "level": {"value": 170, "display_string": "Item Level 170"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/221117?namespace=static-12.0.1_65617-eu"}, "name": "Sanctified Priory Wall", "id": 221117}, "display_string": "Transmogrified to:\\nSanctified Priory Wall", "item_modified_appearance_id": 219069}, "durability": {"value": 120, "display_string": "Durability 120 / 120"}, "name_description": {"display_string": "Mythic+", "color": {"r": 0, "g": 255, "b": 0, "a": 1.0}}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/233289?namespace=static-12.0.1_65617-eu"}, "id": 233289}, "slot": {"type": "TABARD", "name": "Tabard"}, "quantity": 1, "context": 11, "quality": {"type": "RARE", "name": "Rare"}, "name": "Radiant Stalwart's Tabard", "media": {"key": {"href": "https://eu.api.blizzard.com/data/wow/media/item/233289?namespace=static-12.0.1_65617-eu"}, "id": 233289}, "item_class": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4?namespace=static-12.0.1_65617-eu"}, "name": "Armor", "id": 4}, "item_subclass": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-class/4/item-subclass/0?namespace=static-12.0.1_65617-eu"}, "name": "Miscellaneous", "id": 0}, "inventory_type": {"type": "TABARD", "name": "Tabard"}, "binding": {"type": "TO_ACCOUNT", "name": "Binds to Warband"}, "sell_price": {"value": 100000, "display_strings": {"header": "Sell Price:", "gold": "10", "silver": "0", "copper": "0"}}, "level": {"value": 1, "display_string": "Item Level 1"}, "transmog": {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/233289?namespace=static-12.0.1_65617-eu"}, "name": "Radiant Stalwart's Tabard", "id": 233289}, "display_string": "Transmogrified to:\\nRadiant Stalwart's Tabard", "item_modified_appearance_id": 230873}, "is_subclass_hidden": true}], "equipped_item_sets": [{"item_set": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item-set/1931?namespace=static-12.0.1_65617-eu"}, "name": "Chains of the Living Weapon", "id": 1931}, "items": [{"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237613?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Bulwark", "id": 237613}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237611?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Crushers", "id": 237611}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237610?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Faceshield", "id": 237610}, "is_equipped": true}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237609?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Legguards", "id": 237609}}, {"item": {"key": {"href": "https://eu.api.blizzard.com/data/wow/item/237608?namespace=static-12.0.1_65617-eu"}, "name": "Living Weapon's Ramparts", "id": 237608}, "is_equipped": true}], "effects": [{"display_string": "Set: Damage done increased by 6%.", "required_count": 2, "is_active": true}, {"display_string": "Set: Damage done increased by 10%.\\r\\n", "required_count": 4, "is_active": true}], "display_string": "Chains of the Living Weapon (4/5)"}]}	2026-02-21 23:42:42.221081+00	2026-02-21 22:42:23.938967+00	1	\N	https://render.worldofwarcraft.com/eu/character/ravencrest/102/175543654-avatar.jpg	0	2026-02-21 23:42:48.644849+00	{"head": {"ilvl": 144, "track": "Adventurer", "item_name": "Living Weapon's Faceshield", "item_id": 237610, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 237610}, "neck": {"ilvl": 144, "track": "Adventurer", "item_name": "Chrysalis of Sundered Souls", "item_id": 237568, "quality": "EPIC", "sockets": 2, "enchanted": false, "icon_id": 237568}, "shoulder": {"ilvl": 144, "track": "Adventurer", "item_name": "Living Weapon's Ramparts", "item_id": 237608, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 237608}, "back": {"ilvl": 170, "track": "Adventurer", "item_name": "Reshii Wraps", "item_id": 235499, "quality": "ARTIFACT", "sockets": 1, "enchanted": true, "icon_id": 235499}, "chest": {"ilvl": 144, "track": "Adventurer", "item_name": "Living Weapon's Bulwark", "item_id": 237613, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 237613}, "wrist": {"ilvl": 167, "track": "Adventurer", "item_name": "Everforged Vambraces", "item_id": 222435, "quality": "EPIC", "sockets": 0, "enchanted": true, "icon_id": 222435}, "hands": {"ilvl": 144, "track": "Adventurer", "item_name": "Living Weapon's Crushers", "item_id": 237611, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 237611}, "waist": {"ilvl": 167, "track": "Adventurer", "item_name": "Everforged Greatbelt", "item_id": 222431, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 222431}, "legs": {"ilvl": 167, "track": "Adventurer", "item_name": "Everforged Legplates", "item_id": 222434, "quality": "EPIC", "sockets": 0, "enchanted": true, "icon_id": 222434}, "feet": {"ilvl": 167, "track": "Adventurer", "item_name": "Everforged Sabatons", "item_id": 222429, "quality": "EPIC", "sockets": 0, "enchanted": true, "icon_id": 222429}, "ring1": {"ilvl": 144, "track": "Adventurer", "item_name": "Band of Boundless Hunger", "item_id": 243046, "quality": "EPIC", "sockets": 2, "enchanted": true, "icon_id": 243046}, "ring2": {"ilvl": 144, "track": "Adventurer", "item_name": "Void-Scarred Band", "item_id": 237956, "quality": "EPIC", "sockets": 2, "enchanted": true, "icon_id": 237956}, "trinket1": {"ilvl": 144, "track": "Adventurer", "item_name": "Shadowguard's Twisted Harvester", "item_id": 246824, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 246824}, "trinket2": {"ilvl": 144, "track": "Adventurer", "item_name": "Veiling Mana Shroud", "item_id": 240213, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 240213}, "main_hand": {"ilvl": 167, "track": "Adventurer", "item_name": "Everforged Longsword", "item_id": 222440, "quality": "EPIC", "sockets": 0, "enchanted": true, "icon_id": 222440}, "off_hand": {"ilvl": 170, "track": "Adventurer", "item_name": "Sanctified Priory Wall", "item_id": 221117, "quality": "EPIC", "sockets": 0, "enchanted": false, "icon_id": 221117}}	\N	1550.4	{"manaforge-omega": {"summary": "1/8 N", "expansion_id": 10, "total_bosses": 8, "normal_bosses_killed": 1, "heroic_bosses_killed": 0, "mythic_bosses_killed": 0}, "liberation-of-undermine": {"summary": "", "expansion_id": 10, "total_bosses": 8, "normal_bosses_killed": 0, "heroic_bosses_killed": 0, "mythic_bosses_killed": 0}, "blackrock-depths": {"summary": "", "expansion_id": 10, "total_bosses": 8, "normal_bosses_killed": 0, "heroic_bosses_killed": 0, "mythic_bosses_killed": 0}, "nerubar-palace": {"summary": "", "expansion_id": 10, "total_bosses": 8, "normal_bosses_killed": 0, "heroic_bosses_killed": 0, "mythic_bosses_killed": 0}}	2026-02-21 22:51:27.628204+00
\.


--
-- Data for Name: crest_entries; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.crest_entries (id, character_id, crest_type, week_number, collected, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: great_vault_entries; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.great_vault_entries (id, character_id, week_number, raid_lfr, raid_normal, raid_heroic, raid_mythic, m_plus_runs, highest_delve, world_vault, created_at, updated_at) FROM stdin;
1	8	-2	0	0	0	0	[12, 13, 14, 12, 12, 12, 13, 12, 12, 11]	0	\N	2026-02-21 22:50:02.117209+00	2026-02-21 22:50:02.117209+00
2	11	-2	0	0	0	0	[]	0	\N	2026-02-21 22:51:26.811849+00	2026-02-21 23:30:12.070667+00
\.


--
-- Data for Name: guild_members; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.guild_members (character_name, guild_id, bnet_id, rank_id, rank_name, last_sync, created_at, updated_at) FROM stdin;
GuildMaster	1	1	0	Guild Master	2026-02-19 08:16:30.139713+00	2026-02-19 08:16:30.139713+00	2026-02-19 08:16:30.139713+00
Shadowblight	1	1	0	Guild Master	2026-02-19 13:23:13.08636+00	2026-02-19 13:23:13.08636+00	2026-02-19 13:23:13.08636+00
Moonweaver	1	1	0	Guild Master	2026-02-19 13:23:13.08636+00	2026-02-19 13:23:13.08636+00	2026-02-19 13:23:13.08636+00
Blazefury	1	2	2	Raider	2026-02-19 13:23:13.08636+00	2026-02-19 13:23:13.08636+00	2026-02-19 13:23:13.08636+00
Ironforge	1	3	1	Officer	2026-02-19 13:23:13.08636+00	2026-02-19 13:23:13.08636+00	2026-02-19 13:23:13.08636+00
\.


--
-- Data for Name: guild_messages; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.guild_messages (id, guild_id, gm_message, created_by, created_at, updated_at) FROM stdin;
1	1	Make sure to keep track of your weeklies for the first 12 weeks!	1	2026-02-19 08:36:19.021952+00	2026-02-19 08:36:19.021952+00
\.


--
-- Data for Name: guild_permissions; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.guild_permissions (id, guild_id, tool_name, min_rank_id, enabled, created_at, updated_at) FROM stdin;
1	1	progress	9	t	2026-02-19 08:16:30.139713+00	2026-02-20 09:15:57.260928+00
2	1	recruitment	0	t	2026-02-19 08:16:30.139713+00	2026-02-20 09:16:18.816604+00
\.


--
-- Data for Name: guilds; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.guilds (id, name, realm, gm_bnet_id, deleted_at, created_at, updated_at, crest_data, crest_updated_at) FROM stdin;
1	Rebels	Sylvanas	1	\N	2026-02-19 08:16:30.139713+00	2026-02-19 18:50:18.46346+00	\N	\N
\.


--
-- Data for Name: profession_progress; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.profession_progress (id, character_id, profession_name, week_number, weekly_quest, patron_orders, treatise, knowledge_points, concentration, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: recruitment_candidates; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.recruitment_candidates (id, guild_id, candidate_name, realm, region, character_class, role, spec, ilvl, raid_progress, mythic_plus_rating, raider_io_score, source, external_url, rating, notes, status, category_id, contacted, contacted_date, avg_parse_percentile, best_parse_percentile, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: recruitment_categories; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.recruitment_categories (id, guild_id, category_name, custom, display_order, created_at, updated_at) FROM stdin;
1	1	Pending	0	0	2026-02-19 08:29:07.420392+00	2026-02-19 08:29:07.420392+00
2	1	Interested	0	1	2026-02-19 08:29:07.420392+00	2026-02-19 08:29:07.420392+00
3	1	Top Picks	0	2	2026-02-19 08:29:07.420392+00	2026-02-19 08:29:07.420392+00
4	1	Rejected	0	3	2026-02-19 08:29:07.420392+00	2026-02-19 08:29:07.420392+00
5	1	Hired	0	4	2026-02-19 08:29:07.420392+00	2026-02-19 08:29:07.420392+00
\.


--
-- Data for Name: recruitment_history; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.recruitment_history (id, guild_id, candidate_id, contacted_date, method, message, response_received, logged_by_bnet_id, created_at) FROM stdin;
\.


--
-- Data for Name: scan_jobs; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.scan_jobs (id, uuid, guild_id, started_by_bnet_id, config, status, progress, current_step, result_count, error_message, share_token, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: scan_results; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.scan_results (id, scan_job_id, character_name, realm, region, character_class, spec, item_level, mythic_plus_score, raid_progress, recruitment_score, recruitment_signals, profile_url, guild_name, created_at) FROM stdin;
\.


--
-- Data for Name: scheduled_scans; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.scheduled_scans (id, guild_id, name, schedule_expr, config, is_active, next_run_at, last_run_at, last_scan_job_id, discord_webhook_url, created_by_bnet_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: season_config; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.season_config (id, expansion_id, region, week_number, start_date, crest_cap_per_week, created_at) FROM stdin;
\.


--
-- Data for Name: talent_builds; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.talent_builds (id, character_id, category, name, talent_string, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_tracked_characters; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.user_tracked_characters (id, guild_id, bnet_id, character_name, realm, is_main, tracked, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.users (bnet_id, bnet_username, last_login, created_at, updated_at) FROM stdin;
1	TestPlayer#1234	2026-02-19 08:16:23.143013+00	2026-02-19 08:16:23.143013+00	2026-02-19 08:16:23.143013+00
2	Blazefury	2026-02-19 13:23:13.08636+00	2026-02-19 13:23:13.08636+00	2026-02-19 13:23:13.08636+00
3	Ironforge	2026-02-19 13:23:13.08636+00	2026-02-19 13:23:13.08636+00	2026-02-19 13:23:13.08636+00
101260193	Chro#21532	2026-02-21 22:59:56.429094+00	2026-02-21 13:13:46.131687+00	2026-02-21 22:59:56.423571+00
\.


--
-- Data for Name: weekly_targets; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.weekly_targets (id, expansion_id, week, ilvl_target, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: weekly_task_completions; Type: TABLE DATA; Schema: public; Owner: hool
--

COPY public.weekly_task_completions (id, character_id, week_number, task_type, task_id, completed, completed_at) FROM stdin;
6	8	-2	weekly	level_chars	t	2026-02-21 22:43:53.406309+00
7	8	-2	weekly	dmf_xp	t	2026-02-21 22:43:56.803054+00
8	8	-2	weekly	weekly_events	t	2026-02-21 22:44:03.258588+00
9	8	-2	weekly	level_prey	t	2026-02-21 22:44:03.750945+00
10	8	-2	weekly	hold_quests	t	2026-02-21 22:44:04.366828+00
11	11	-2	weekly	level_chars	t	2026-02-21 23:29:57.143178+00
12	11	-2	weekly	dmf_xp	t	2026-02-21 23:29:57.868175+00
13	11	-2	weekly	weekly_events	t	2026-02-21 23:29:59.025602+00
14	11	-2	weekly	level_prey	t	2026-02-21 23:29:59.486438+00
15	11	-2	weekly	hold_quests	t	2026-02-21 23:29:59.914421+00
16	13	-2	weekly	level_chars	t	2026-02-21 23:43:15.372715+00
17	13	-2	weekly	dmf_xp	t	2026-02-21 23:43:16.194328+00
18	13	-2	weekly	weekly_events	t	2026-02-21 23:43:16.749282+00
19	13	-2	weekly	level_prey	t	2026-02-21 23:43:17.402224+00
20	13	-2	weekly	hold_quests	t	2026-02-21 23:43:17.880516+00
\.


--
-- Name: bis_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hool
--

SELECT pg_catalog.setval('public.bis_items_id_seq', 1, false);


--
-- Name: character_professions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hool
--

SELECT pg_catalog.setval('public.character_professions_id_seq', 1, false);


--
-- Name: character_progress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hool
--

SELECT pg_catalog.setval('public.character_progress_id_seq', 15, true);


--
-- Name: crest_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hool
--

SELECT pg_catalog.setval('public.crest_entries_id_seq', 1, false);


--
-- Name: great_vault_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hool
--

SELECT pg_catalog.setval('public.great_vault_entries_id_seq', 2, true);


--
-- Name: guild_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hool
--

SELECT pg_catalog.setval('public.guild_messages_id_seq', 1, true);


--
-- Name: guild_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hool
--

SELECT pg_catalog.setval('public.guild_permissions_id_seq', 4, true);


--
-- Name: guilds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hool
--

SELECT pg_catalog.setval('public.guilds_id_seq', 1, true);


--
-- Name: profession_progress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hool
--

SELECT pg_catalog.setval('public.profession_progress_id_seq', 1, false);


--
-- Name: recruitment_candidates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hool
--

SELECT pg_catalog.setval('public.recruitment_candidates_id_seq', 1, false);


--
-- Name: recruitment_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hool
--

SELECT pg_catalog.setval('public.recruitment_categories_id_seq', 5, true);


--
-- Name: recruitment_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hool
--

SELECT pg_catalog.setval('public.recruitment_history_id_seq', 1, false);


--
-- Name: scan_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hool
--

SELECT pg_catalog.setval('public.scan_jobs_id_seq', 1, false);


--
-- Name: scan_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hool
--

SELECT pg_catalog.setval('public.scan_results_id_seq', 1, false);


--
-- Name: scheduled_scans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hool
--

SELECT pg_catalog.setval('public.scheduled_scans_id_seq', 1, false);


--
-- Name: season_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hool
--

SELECT pg_catalog.setval('public.season_config_id_seq', 1, false);


--
-- Name: talent_builds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hool
--

SELECT pg_catalog.setval('public.talent_builds_id_seq', 1, false);


--
-- Name: user_tracked_characters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hool
--

SELECT pg_catalog.setval('public.user_tracked_characters_id_seq', 1, false);


--
-- Name: users_bnet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hool
--

SELECT pg_catalog.setval('public.users_bnet_id_seq', 1, false);


--
-- Name: weekly_targets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hool
--

SELECT pg_catalog.setval('public.weekly_targets_id_seq', 10, true);


--
-- Name: weekly_task_completions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hool
--

SELECT pg_catalog.setval('public.weekly_task_completions_id_seq', 20, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_progress alembic_version_progress_pkc; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.alembic_version_progress
    ADD CONSTRAINT alembic_version_progress_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version_recruitment alembic_version_recruitment_pkc; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.alembic_version_recruitment
    ADD CONSTRAINT alembic_version_recruitment_pkc PRIMARY KEY (version_num);


--
-- Name: bis_items bis_items_pkey; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.bis_items
    ADD CONSTRAINT bis_items_pkey PRIMARY KEY (id);


--
-- Name: character_professions character_professions_pkey; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.character_professions
    ADD CONSTRAINT character_professions_pkey PRIMARY KEY (id);


--
-- Name: character_progress character_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.character_progress
    ADD CONSTRAINT character_progress_pkey PRIMARY KEY (id);


--
-- Name: crest_entries crest_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.crest_entries
    ADD CONSTRAINT crest_entries_pkey PRIMARY KEY (id);


--
-- Name: great_vault_entries great_vault_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.great_vault_entries
    ADD CONSTRAINT great_vault_entries_pkey PRIMARY KEY (id);


--
-- Name: guild_members guild_members_pkey; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.guild_members
    ADD CONSTRAINT guild_members_pkey PRIMARY KEY (character_name);


--
-- Name: guild_messages guild_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.guild_messages
    ADD CONSTRAINT guild_messages_pkey PRIMARY KEY (id);


--
-- Name: guild_permissions guild_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.guild_permissions
    ADD CONSTRAINT guild_permissions_pkey PRIMARY KEY (id);


--
-- Name: guilds guilds_pkey; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.guilds
    ADD CONSTRAINT guilds_pkey PRIMARY KEY (id);


--
-- Name: profession_progress profession_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.profession_progress
    ADD CONSTRAINT profession_progress_pkey PRIMARY KEY (id);


--
-- Name: recruitment_candidates recruitment_candidates_pkey; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.recruitment_candidates
    ADD CONSTRAINT recruitment_candidates_pkey PRIMARY KEY (id);


--
-- Name: recruitment_categories recruitment_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.recruitment_categories
    ADD CONSTRAINT recruitment_categories_pkey PRIMARY KEY (id);


--
-- Name: recruitment_history recruitment_history_pkey; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.recruitment_history
    ADD CONSTRAINT recruitment_history_pkey PRIMARY KEY (id);


--
-- Name: scan_jobs scan_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.scan_jobs
    ADD CONSTRAINT scan_jobs_pkey PRIMARY KEY (id);


--
-- Name: scan_results scan_results_pkey; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.scan_results
    ADD CONSTRAINT scan_results_pkey PRIMARY KEY (id);


--
-- Name: scheduled_scans scheduled_scans_pkey; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.scheduled_scans
    ADD CONSTRAINT scheduled_scans_pkey PRIMARY KEY (id);


--
-- Name: season_config season_config_pkey; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.season_config
    ADD CONSTRAINT season_config_pkey PRIMARY KEY (id);


--
-- Name: talent_builds talent_builds_pkey; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.talent_builds
    ADD CONSTRAINT talent_builds_pkey PRIMARY KEY (id);


--
-- Name: user_tracked_characters uix_guild_user_character; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.user_tracked_characters
    ADD CONSTRAINT uix_guild_user_character UNIQUE (guild_id, bnet_id, character_name, realm);


--
-- Name: character_professions uq_character_profession; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.character_professions
    ADD CONSTRAINT uq_character_profession UNIQUE (character_id, profession_name);


--
-- Name: crest_entries uq_crest_character_type_week; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.crest_entries
    ADD CONSTRAINT uq_crest_character_type_week UNIQUE (character_id, crest_type, week_number);


--
-- Name: weekly_targets uq_expansion_week; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.weekly_targets
    ADD CONSTRAINT uq_expansion_week UNIQUE (expansion_id, week);


--
-- Name: guild_messages uq_guild_id; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.guild_messages
    ADD CONSTRAINT uq_guild_id UNIQUE (guild_id);


--
-- Name: profession_progress uq_profession_character_name_week; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.profession_progress
    ADD CONSTRAINT uq_profession_character_name_week UNIQUE (character_id, profession_name, week_number);


--
-- Name: season_config uq_season_expansion_region_week; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.season_config
    ADD CONSTRAINT uq_season_expansion_region_week UNIQUE (expansion_id, region, week_number);


--
-- Name: weekly_task_completions uq_task_character_week_type_id; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.weekly_task_completions
    ADD CONSTRAINT uq_task_character_week_type_id UNIQUE (character_id, week_number, task_type, task_id);


--
-- Name: great_vault_entries uq_vault_character_week; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.great_vault_entries
    ADD CONSTRAINT uq_vault_character_week UNIQUE (character_id, week_number);


--
-- Name: user_tracked_characters user_tracked_characters_pkey; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.user_tracked_characters
    ADD CONSTRAINT user_tracked_characters_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (bnet_id);


--
-- Name: weekly_targets weekly_targets_pkey; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.weekly_targets
    ADD CONSTRAINT weekly_targets_pkey PRIMARY KEY (id);


--
-- Name: weekly_task_completions weekly_task_completions_pkey; Type: CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.weekly_task_completions
    ADD CONSTRAINT weekly_task_completions_pkey PRIMARY KEY (id);


--
-- Name: idx_character_user; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX idx_character_user ON public.character_progress USING btree (character_name, realm, user_bnet_id);


--
-- Name: idx_guild_candidate; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX idx_guild_candidate ON public.recruitment_candidates USING btree (guild_id, candidate_name, realm);


--
-- Name: idx_guild_candidate_history; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX idx_guild_candidate_history ON public.recruitment_history USING btree (guild_id, candidate_id);


--
-- Name: idx_guild_category; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX idx_guild_category ON public.recruitment_candidates USING btree (guild_id, category_id);


--
-- Name: idx_guild_category_name; Type: INDEX; Schema: public; Owner: hool
--

CREATE UNIQUE INDEX idx_guild_category_name ON public.recruitment_categories USING btree (guild_id, category_name);


--
-- Name: idx_guild_status; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX idx_guild_status ON public.recruitment_candidates USING btree (guild_id, status);


--
-- Name: ix_bis_items_character_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_bis_items_character_id ON public.bis_items USING btree (character_id);


--
-- Name: ix_bis_items_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_bis_items_id ON public.bis_items USING btree (id);


--
-- Name: ix_character_professions_character_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_character_professions_character_id ON public.character_professions USING btree (character_id);


--
-- Name: ix_character_professions_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_character_professions_id ON public.character_professions USING btree (id);


--
-- Name: ix_character_progress_character_name; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_character_progress_character_name ON public.character_progress USING btree (character_name);


--
-- Name: ix_character_progress_guild_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_character_progress_guild_id ON public.character_progress USING btree (guild_id);


--
-- Name: ix_character_progress_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_character_progress_id ON public.character_progress USING btree (id);


--
-- Name: ix_character_progress_realm; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_character_progress_realm ON public.character_progress USING btree (realm);


--
-- Name: ix_character_progress_user_bnet_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_character_progress_user_bnet_id ON public.character_progress USING btree (user_bnet_id);


--
-- Name: ix_crest_entries_character_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_crest_entries_character_id ON public.crest_entries USING btree (character_id);


--
-- Name: ix_crest_entries_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_crest_entries_id ON public.crest_entries USING btree (id);


--
-- Name: ix_great_vault_entries_character_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_great_vault_entries_character_id ON public.great_vault_entries USING btree (character_id);


--
-- Name: ix_great_vault_entries_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_great_vault_entries_id ON public.great_vault_entries USING btree (id);


--
-- Name: ix_guild_members_bnet_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_guild_members_bnet_id ON public.guild_members USING btree (bnet_id);


--
-- Name: ix_guild_members_character_name; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_guild_members_character_name ON public.guild_members USING btree (character_name);


--
-- Name: ix_guild_members_guild_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_guild_members_guild_id ON public.guild_members USING btree (guild_id);


--
-- Name: ix_guild_messages_guild_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_guild_messages_guild_id ON public.guild_messages USING btree (guild_id);


--
-- Name: ix_guild_messages_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_guild_messages_id ON public.guild_messages USING btree (id);


--
-- Name: ix_guild_permissions_guild_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_guild_permissions_guild_id ON public.guild_permissions USING btree (guild_id);


--
-- Name: ix_guild_permissions_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_guild_permissions_id ON public.guild_permissions USING btree (id);


--
-- Name: ix_guilds_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_guilds_id ON public.guilds USING btree (id);


--
-- Name: ix_guilds_name; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_guilds_name ON public.guilds USING btree (name);


--
-- Name: ix_guilds_realm; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_guilds_realm ON public.guilds USING btree (realm);


--
-- Name: ix_profession_progress_character_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_profession_progress_character_id ON public.profession_progress USING btree (character_id);


--
-- Name: ix_profession_progress_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_profession_progress_id ON public.profession_progress USING btree (id);


--
-- Name: ix_recruitment_candidates_guild_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_recruitment_candidates_guild_id ON public.recruitment_candidates USING btree (guild_id);


--
-- Name: ix_recruitment_candidates_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_recruitment_candidates_id ON public.recruitment_candidates USING btree (id);


--
-- Name: ix_recruitment_categories_guild_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_recruitment_categories_guild_id ON public.recruitment_categories USING btree (guild_id);


--
-- Name: ix_recruitment_categories_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_recruitment_categories_id ON public.recruitment_categories USING btree (id);


--
-- Name: ix_recruitment_history_candidate_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_recruitment_history_candidate_id ON public.recruitment_history USING btree (candidate_id);


--
-- Name: ix_recruitment_history_guild_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_recruitment_history_guild_id ON public.recruitment_history USING btree (guild_id);


--
-- Name: ix_recruitment_history_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_recruitment_history_id ON public.recruitment_history USING btree (id);


--
-- Name: ix_scan_jobs_guild_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_scan_jobs_guild_id ON public.scan_jobs USING btree (guild_id);


--
-- Name: ix_scan_jobs_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_scan_jobs_id ON public.scan_jobs USING btree (id);


--
-- Name: ix_scan_jobs_share_token; Type: INDEX; Schema: public; Owner: hool
--

CREATE UNIQUE INDEX ix_scan_jobs_share_token ON public.scan_jobs USING btree (share_token);


--
-- Name: ix_scan_jobs_status; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_scan_jobs_status ON public.scan_jobs USING btree (status);


--
-- Name: ix_scan_jobs_uuid; Type: INDEX; Schema: public; Owner: hool
--

CREATE UNIQUE INDEX ix_scan_jobs_uuid ON public.scan_jobs USING btree (uuid);


--
-- Name: ix_scan_results_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_scan_results_id ON public.scan_results USING btree (id);


--
-- Name: ix_scan_results_scan_job_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_scan_results_scan_job_id ON public.scan_results USING btree (scan_job_id);


--
-- Name: ix_scheduled_scans_guild_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_scheduled_scans_guild_id ON public.scheduled_scans USING btree (guild_id);


--
-- Name: ix_scheduled_scans_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_scheduled_scans_id ON public.scheduled_scans USING btree (id);


--
-- Name: ix_season_config_expansion_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_season_config_expansion_id ON public.season_config USING btree (expansion_id);


--
-- Name: ix_season_config_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_season_config_id ON public.season_config USING btree (id);


--
-- Name: ix_talent_builds_character_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_talent_builds_character_id ON public.talent_builds USING btree (character_id);


--
-- Name: ix_talent_builds_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_talent_builds_id ON public.talent_builds USING btree (id);


--
-- Name: ix_user_tracked_characters_guild_bnet; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_user_tracked_characters_guild_bnet ON public.user_tracked_characters USING btree (guild_id, bnet_id);


--
-- Name: ix_user_tracked_characters_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_user_tracked_characters_id ON public.user_tracked_characters USING btree (id);


--
-- Name: ix_users_bnet_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_users_bnet_id ON public.users USING btree (bnet_id);


--
-- Name: ix_weekly_targets_expansion_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_weekly_targets_expansion_id ON public.weekly_targets USING btree (expansion_id);


--
-- Name: ix_weekly_targets_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_weekly_targets_id ON public.weekly_targets USING btree (id);


--
-- Name: ix_weekly_task_completions_character_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_weekly_task_completions_character_id ON public.weekly_task_completions USING btree (character_id);


--
-- Name: ix_weekly_task_completions_id; Type: INDEX; Schema: public; Owner: hool
--

CREATE INDEX ix_weekly_task_completions_id ON public.weekly_task_completions USING btree (id);


--
-- Name: bis_items bis_items_character_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.bis_items
    ADD CONSTRAINT bis_items_character_id_fkey FOREIGN KEY (character_id) REFERENCES public.character_progress(id) ON DELETE CASCADE;


--
-- Name: character_professions character_professions_character_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.character_professions
    ADD CONSTRAINT character_professions_character_id_fkey FOREIGN KEY (character_id) REFERENCES public.character_progress(id) ON DELETE CASCADE;


--
-- Name: crest_entries crest_entries_character_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.crest_entries
    ADD CONSTRAINT crest_entries_character_id_fkey FOREIGN KEY (character_id) REFERENCES public.character_progress(id) ON DELETE CASCADE;


--
-- Name: scan_results fk_scan_results_scan_job_id; Type: FK CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.scan_results
    ADD CONSTRAINT fk_scan_results_scan_job_id FOREIGN KEY (scan_job_id) REFERENCES public.scan_jobs(id);


--
-- Name: scheduled_scans fk_scheduled_scans_last_scan_job_id; Type: FK CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.scheduled_scans
    ADD CONSTRAINT fk_scheduled_scans_last_scan_job_id FOREIGN KEY (last_scan_job_id) REFERENCES public.scan_jobs(id);


--
-- Name: great_vault_entries great_vault_entries_character_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.great_vault_entries
    ADD CONSTRAINT great_vault_entries_character_id_fkey FOREIGN KEY (character_id) REFERENCES public.character_progress(id) ON DELETE CASCADE;


--
-- Name: guild_members guild_members_bnet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.guild_members
    ADD CONSTRAINT guild_members_bnet_id_fkey FOREIGN KEY (bnet_id) REFERENCES public.users(bnet_id);


--
-- Name: guild_members guild_members_guild_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.guild_members
    ADD CONSTRAINT guild_members_guild_id_fkey FOREIGN KEY (guild_id) REFERENCES public.guilds(id);


--
-- Name: guild_permissions guild_permissions_guild_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.guild_permissions
    ADD CONSTRAINT guild_permissions_guild_id_fkey FOREIGN KEY (guild_id) REFERENCES public.guilds(id);


--
-- Name: guilds guilds_gm_bnet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.guilds
    ADD CONSTRAINT guilds_gm_bnet_id_fkey FOREIGN KEY (gm_bnet_id) REFERENCES public.users(bnet_id);


--
-- Name: profession_progress profession_progress_character_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.profession_progress
    ADD CONSTRAINT profession_progress_character_id_fkey FOREIGN KEY (character_id) REFERENCES public.character_progress(id) ON DELETE CASCADE;


--
-- Name: talent_builds talent_builds_character_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.talent_builds
    ADD CONSTRAINT talent_builds_character_id_fkey FOREIGN KEY (character_id) REFERENCES public.character_progress(id) ON DELETE CASCADE;


--
-- Name: user_tracked_characters user_tracked_characters_guild_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.user_tracked_characters
    ADD CONSTRAINT user_tracked_characters_guild_id_fkey FOREIGN KEY (guild_id) REFERENCES public.guilds(id) ON DELETE CASCADE;


--
-- Name: weekly_task_completions weekly_task_completions_character_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hool
--

ALTER TABLE ONLY public.weekly_task_completions
    ADD CONSTRAINT weekly_task_completions_character_id_fkey FOREIGN KEY (character_id) REFERENCES public.character_progress(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 9ua7a8OXfRT2PvIBtMtE6gVRIUB3eExNjB9GyiWDfz1ZWfe5Bd3Rxwd0ikSifIz

